# Integração das três partes (estetica + agenda + pagamento)

Projeto-base: **estetica** (cadastro/login). A agenda (`salao-agenda`) e o pagamento (`Pagamento/parte4`) entraram
dentro dele **sem trocar de pacote**: `com.salao.*` é a agenda, `br.com.xptotec.salao.*` é o pagamento,
`br.clinica.*` é o cadastro/login.

## Como rodar

1. MySQL 8 com usuário `root` sem senha (padrão que as três partes já usavam). Se tiver senha, troque em
   `hibernate.cfg.xml` **e** nas variáveis `SALAO_DB_PASS` (agenda) e `DB_PASS` (pagamento).
2. Rode os scripts **nesta ordem** (dentro do banco `salao`, ex.: `mysql -u root salao < sql/02_...`; o 01 cria o banco):
   `01_base_usuario_cliente.sql` → `02_agenda_schema.sql` → `03_pagamento_parte4.sql` → `04_dados_exemplo.sql` (opcional).
3. Tomcat **10.1+** e Java **17** (Eclipse: Maven > Update Project para ele reler o `pom.xml`).
4. Login da recepção (criado na subida da aplicação): `recepcao` / `recepcao123`. Clientes se cadastram pelo site.

## Como as partes se conectam

| Elo | Como ficou |
|---|---|
| Banco | Um só (`salao`, MySQL). O Hibernate do estetica saiu do H2 e passou para o MySQL. |
| Quem é o cliente | `Cliente.id` (estetica) é a chave de `reserva.cliente_id`, `pagamento.cliente_id`, `credito_cliente.cliente_id` e `fila_espera.cliente_id`. |
| Login | O estetica usa JWT; agenda e pagamento usam sessão HTTP. O `AuthServlet` agora também grava na sessão `clienteId`, `usuarioId` (os dois = id do Cliente) e `usuarioPerfil`. O `/logout` encerra a sessão. |
| Reserva → pagamento | A agenda cria a reserva como `AGUARDANDO_PAGAMENTO` e redireciona para `/pagamento?reservaId=ID`. Pago, vira `CONFIRMADA`. |
| Pagamento → agenda | O pagamento lê as reservas da agenda (`reserva` + `item_reserva`) e pede horários livres ao `DisponibilidadeService`. |

Fluxo: login → `reservas?acao=nova` → escolhe serviços/profissional/horário → `/pagamento` (cartão, pode abater crédito) →
reserva `CONFIRMADA` → recepção marca presença / falta (metade retida, metade vira crédito) / atraso > 15 min (vaga liberada, chama a fila).

## O que mudou em cada parte (diffs exatos em `docs/alteracoes-*.diff`)

### Seus arquivos (estetica)
- `pom.xml`, `hibernate.cfg.xml`, `.classpath`, `.settings/*`: Java 17, `jakarta.servlet` 6 + JSTL, MySQL no lugar do H2.
- Servlets e `JwtFilter`: `javax.servlet` → `jakarta.servlet` (Tomcat 10 exige; agenda e pagamento já eram jakarta).
- `Usuario`/`Cliente`: `@Table(name="usuario"/"cliente")` (minúsculo, igual às chaves estrangeiras dos amigos) e `Cliente.id` de `int` para `long` (BIGINT), senão a chave estrangeira BIGINT dos amigos não cria no MySQL. Isso propagou `long` por `ClienteDAO/Service/Servlet`.
- `AuthServlet`: grava a sessão (ponte acima). Novos: `LogoutServlet`, `InicializacaoListener` (cria o usuário `recepcao`).
- `ClienteServlet`: excluir cliente que tem reserva/pagamento agora devolve erro 409 amigável em vez de 500.
- `index.jsp`: links para reservar, minhas reservas, meu crédito e painel da recepção; `sair()` também chama `/logout`.

### Agenda (`com.salao.*`) — 6 arquivos
- `StatusReserva`: +`AGUARDANDO_PAGAMENTO`, `PRESENTE`, `ATRASO_LIBERADO`, `FALTA` (o pagamento grava esses textos em `reserva.status`; sem isso o `valueOf` quebra a tela "Minhas reservas").
- `ReservaService.criar`: reserva nasce `AGUARDANDO_PAGAMENTO` (era `CONFIRMADA`).
- `ReservaServlet`: depois de criar, redireciona para `/pagamento?reservaId=...` (era para `/reservas`).
- `Reserva`, `ReservaService.cancelar`, `ReservaDAO.cancelar`: reserva ainda não paga também pode ser cancelada; `isPagavel()` novo.
- `minhas-reservas.jsp`: botão "Pagar agora".
- Não mudou: `schema.sql`, `ConnectionFactory`, `DisponibilidadeService`, `AgendaDoDia`, `reservar.jsp`, CSS.

### Pagamento (`br.com.xptotec.salao.*`) — 5 arquivos
- `ReservaIntegracaoDAO` (o adaptador que o próprio README deles previa): SQL reescrito para a agenda (`valor_total`, `data_hora`, serviço do primeiro item, nomes dos serviços concatenados, cliente vem de `cliente`); `proximoHorarioLivreHoje` agora chama `DisponibilidadeService` porque não existe tabela `horario`.
- `ReservaResumo`: removido `horarioId` (a agenda não tem horário como entidade).
- `FilaEsperaDAO`: `JOIN usuario` → `JOIN cliente` (nome do cliente na fila).
- `Sessao`: login em `/login.jsp` (o `/login` do estetica só aceita POST), perfil `RECEPCAO` aceito como recepção, e `exigirRecepcao` não depende mais de `usuarioId`.
- `parte4.sql`: as 3 chaves estrangeiras de cliente apontam para `cliente(id)` (era `usuario(id)`).
- Não mudou: services, gateway, models, servlets, JSPs, `Conexao`.

## Pontos que o enunciado não define (decidam em grupo)
- **Cancelar reserva já paga**: hoje cancela sem estorno nem crédito (o README do pagamento já avisava). O enum `ESTORNO` existe, falta a regra.
- **Reserva que nunca é paga** segura o horário até o cliente pagar ou cancelar (não há expiração).
- **Reserva com vários serviços** usa o serviço do 1º item para a fila de espera; as outras filas não são chamadas na falta/atraso.
- O enunciado pede filtros por **especialidade** e profissional; a agenda filtra serviços por nome e escolhe profissional, mas não existe especialidade no modelo.
- Gateway de cartão é simulado (recusa cartão terminado em `0000`).

## O que eu não consegui testar
Sem Maven, Tomcat nem MySQL no ambiente onde montei isso, o projeto **não foi compilado nem executado**. Conferi que todo o código parseia e que as referências entre as classes
dos três módulos resolvem; o que falta é rodar de verdade (ver "Como rodar") e testar o fluxo acima.
