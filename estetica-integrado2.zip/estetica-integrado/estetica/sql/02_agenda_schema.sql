-- Módulo de agenda e reserva (MySQL 8 / InnoDB).
-- As tabelas da seção 1 provavelmente já existem no projeto (são dos colegas):
-- ajuste nomes de tabela/coluna nos DAOs se forem diferentes.

-- ===== 1. Tabelas de apoio (mínimo necessário) =====
CREATE TABLE IF NOT EXISTS cliente (
    id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profissional (
    id    BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome  VARCHAR(120) NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS servico (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome        VARCHAR(120) NOT NULL,
    duracao_min INT NOT NULL,
    preco       DECIMAL(10,2) NOT NULL,
    ativo       BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profissional_servico (
    profissional_id BIGINT NOT NULL,
    servico_id      BIGINT NOT NULL,
    PRIMARY KEY (profissional_id, servico_id),
    FOREIGN KEY (profissional_id) REFERENCES profissional(id),
    FOREIGN KEY (servico_id)      REFERENCES servico(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pacote (
    id    BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome  VARCHAR(120) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pacote_servico (
    pacote_id  BIGINT NOT NULL,
    servico_id BIGINT NOT NULL,
    ordem      INT NOT NULL DEFAULT 0,
    PRIMARY KEY (pacote_id, servico_id),
    FOREIGN KEY (pacote_id)  REFERENCES pacote(id),
    FOREIGN KEY (servico_id) REFERENCES servico(id)
) ENGINE=InnoDB;

-- ===== 2. Tabelas deste módulo =====
-- Janela em que o profissional atende num dia específico.
CREATE TABLE IF NOT EXISTS disponibilidade (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    profissional_id BIGINT NOT NULL,
    dia             DATE   NOT NULL,
    hora_inicio     TIME   NOT NULL,
    hora_fim        TIME   NOT NULL,
    CONSTRAINT fk_disp_prof FOREIGN KEY (profissional_id) REFERENCES profissional(id),
    CONSTRAINT ck_disp_horas CHECK (hora_fim > hora_inicio),
    INDEX idx_disp_prof_dia (profissional_id, dia)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reserva (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id   BIGINT NOT NULL,
    data_hora    DATETIME NOT NULL,                       -- início da reserva
    status       VARCHAR(20) NOT NULL DEFAULT 'CONFIRMADA', -- CONFIRMADA | CANCELADA | CONCLUIDA
    valor_total  DECIMAL(10,2) NOT NULL,
    tipo_escolha VARCHAR(20) NOT NULL,                    -- DISPONIVEL | PREFERENCIA
    criada_em    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reserva_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id),
    INDEX idx_reserva_cliente (cliente_id, data_hora)
) ENGINE=InnoDB;

-- Um item por serviço; guarda início e fim para detectar sobreposição.
CREATE TABLE IF NOT EXISTS item_reserva (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    reserva_id      BIGINT NOT NULL,
    servico_id      BIGINT NOT NULL,
    profissional_id BIGINT NOT NULL,
    inicio          DATETIME NOT NULL,
    fim             DATETIME NOT NULL,
    CONSTRAINT fk_item_reserva  FOREIGN KEY (reserva_id)      REFERENCES reserva(id),
    CONSTRAINT fk_item_servico  FOREIGN KEY (servico_id)      REFERENCES servico(id),
    CONSTRAINT fk_item_prof     FOREIGN KEY (profissional_id) REFERENCES profissional(id),
    CONSTRAINT ck_item_horas    CHECK (fim > inicio),
    INDEX idx_item_prof_inicio (profissional_id, inicio, fim)
) ENGINE=InnoDB;

-- ===== 3. Dados de exemplo para testar =====
-- INSERT INTO cliente (nome) VALUES ('Cliente Teste');
-- INSERT INTO profissional (nome) VALUES ('Ana'), ('Bruno');
-- INSERT INTO servico (nome, duracao_min, preco) VALUES ('Corte', 60, 80.00), ('Escova', 30, 50.00), ('Manicure', 45, 40.00);
-- INSERT INTO profissional_servico VALUES (1,1),(1,2),(2,1),(2,3);
-- INSERT INTO disponibilidade (profissional_id, dia, hora_inicio, hora_fim)
--   VALUES (1, CURDATE() + INTERVAL 1 DAY, '09:00', '18:00'), (2, CURDATE() + INTERVAL 1 DAY, '10:00', '16:00');
