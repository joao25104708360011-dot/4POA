-- =====================================================================
-- DADOS DE EXEMPLO (opcional) para testar a reserva: serviços, profissionais, pacotes e
-- agenda dos próximos 8 dias (hoje + 7). Rode depois de 02 e 03. Rode só uma vez.
-- Clientes NÃO são criados aqui: cadastre pelo site (cadastro.jsp).
-- =====================================================================
USE salao;

INSERT INTO profissional (id, nome) VALUES (1, 'Ana'), (2, 'Bruno'), (3, 'Carla'), (4, 'Diana');

INSERT INTO servico (id, nome, duracao_min, preco) VALUES
    (1, 'Corte feminino',    60,  80.00),
    (2, 'Escova',            30,  50.00),
    (3, 'Manicure',          45,  40.00),
    (4, 'Limpeza de pele',   60, 120.00),
    (5, 'Massagem relaxante',50, 150.00);

-- Salão: Ana (corte, escova), Bruno (corte, manicure). Estética: Carla (limpeza, massagem), Diana (limpeza, manicure).
INSERT INTO profissional_servico (profissional_id, servico_id) VALUES
    (1, 1), (1, 2), (2, 1), (2, 3), (3, 4), (3, 5), (4, 4), (4, 3);

INSERT INTO pacote (id, nome, preco) VALUES (1, 'Dia de noiva', 150.00), (2, 'Spa day', 240.00);
INSERT INTO pacote_servico (pacote_id, servico_id, ordem) VALUES
    (1, 1, 1), (1, 2, 2), (1, 3, 3),
    (2, 4, 1), (2, 5, 2);

INSERT INTO disponibilidade (profissional_id, dia, hora_inicio, hora_fim)
SELECT p.id, CURDATE() + INTERVAL d.n DAY, '09:00:00', '18:00:00'
FROM profissional p
CROSS JOIN (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
            UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7) d;
