-- =====================================================================
-- BASE: banco do projeto e tabelas do cadastro/login (parte do estetica, mapeadas pelo Hibernate)
-- Rode ESTE script primeiro, depois 02, 03 e (opcional) 04.
-- Se a aplicação subir antes, o Hibernate (hbm2ddl=update) cria estas duas tabelas sozinho
-- com a mesma estrutura; o IF NOT EXISTS evita conflito.
-- O usuário "recepcao" é criado pela aplicação na subida (InicializacaoListener).
-- =====================================================================
CREATE DATABASE IF NOT EXISTS salao CHARACTER SET utf8mb4;
USE salao;

CREATE TABLE IF NOT EXISTS usuario (
    id     INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    login  VARCHAR(255) NOT NULL,
    senha  VARCHAR(255) NOT NULL,      -- hash BCrypt
    perfil VARCHAR(255) NOT NULL,      -- CLIENTE | RECEPCAO
    UNIQUE KEY uk_usuario_login (login)
) ENGINE=InnoDB;

-- id é BIGINT para casar com as chaves estrangeiras cliente_id (BIGINT) da agenda e do pagamento.
CREATE TABLE IF NOT EXISTS cliente (
    id         BIGINT       NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(255) NOT NULL,
    telefone   VARCHAR(255) NULL,
    email      VARCHAR(255) NOT NULL,
    usuario_id INT          NOT NULL,
    UNIQUE KEY uk_cliente_email (email),
    UNIQUE KEY uk_cliente_usuario (usuario_id),
    CONSTRAINT fk_cliente_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
) ENGINE=InnoDB;
