-- =====================================================================
-- PARTE 4: Pagamento, falta, crédito e fila de espera  (MySQL 8 / MariaDB)
-- Tabelas assumidas das outras partes:
--   cliente(id, nome, ...)            -> Parte 1 (estetica, mapeada pelo Hibernate)
--   servico(id, nome, ...)            -> Parte 2
--   reserva(id, cliente_id, data_hora, status, valor_total, ...)      -> agenda (sql/02)
--   item_reserva(reserva_id, servico_id, profissional_id, inicio, fim) -> agenda (sql/02)
--   Status de reserva usados aqui: AGUARDANDO_PAGAMENTO, CONFIRMADA, PRESENTE,
--   ATRASO_LIBERADO, FALTA  (ver integracao/StatusReserva.java)
-- =====================================================================

CREATE TABLE pagamento (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    reserva_id        BIGINT        NOT NULL,
    cliente_id        BIGINT        NOT NULL,
    valor             DECIMAL(10,2) NOT NULL,            -- valor total da reserva
    valor_credito     DECIMAL(10,2) NOT NULL DEFAULT 0,  -- parte paga com crédito do cliente
    valor_retido      DECIMAL(10,2) NOT NULL DEFAULT 0,  -- parte retida em caso de falta
    bandeira          VARCHAR(20)   NULL,                -- VISA, MASTERCARD...
    ultimos4          CHAR(4)       NULL,                -- NUNCA guardar o número completo / CVV
    status            VARCHAR(20)   NOT NULL,            -- PENDENTE, APROVADO, RECUSADO, RETIDO_PARCIAL, ESTORNADO
    codigo_transacao  VARCHAR(60)   NULL,
    criado_em         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_pag_reserva (reserva_id),
    INDEX idx_pag_cliente (cliente_id),
    CONSTRAINT fk_pag_reserva FOREIGN KEY (reserva_id) REFERENCES reserva(id),
    CONSTRAINT fk_pag_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id)
);

CREATE TABLE credito_cliente (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id  BIGINT        NOT NULL,
    valor       DECIMAL(10,2) NOT NULL,                  -- valor original do crédito
    origem      VARCHAR(20)   NOT NULL,                  -- FALTA, ESTORNO, AJUSTE
    saldo       DECIMAL(10,2) NOT NULL,                  -- quanto ainda resta
    reserva_id  BIGINT        NULL,
    criado_em   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_cred_cliente (cliente_id),
    CONSTRAINT fk_cred_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id)
);

CREATE TABLE fila_espera (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id  BIGINT      NOT NULL,
    servico_id  BIGINT      NOT NULL,
    data        DATE        NOT NULL,
    ordem       INT         NOT NULL,
    status      VARCHAR(20) NOT NULL,                    -- AGUARDANDO, CHAMADO, ATENDIDO, DESISTIU
    criado_em   TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fila (servico_id, data, status, ordem),
    UNIQUE KEY uk_fila_ordem (servico_id, data, ordem),   -- garante ordem única sob concorrência
    CONSTRAINT fk_fila_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id),
    CONSTRAINT fk_fila_servico FOREIGN KEY (servico_id) REFERENCES servico(id)
);
