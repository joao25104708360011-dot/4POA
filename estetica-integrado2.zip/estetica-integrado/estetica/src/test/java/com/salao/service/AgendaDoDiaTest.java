package com.salao.service;

import com.salao.model.Disponibilidade;
import com.salao.model.ItemReserva;
import com.salao.model.Servico;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AgendaDoDiaTest {

    private static final LocalDate DIA = LocalDate.of(2026, 11, 10);
    private static final long ANA = 1, BRUNO = 2;

    private static LocalDateTime t(String hora) {
        return LocalDateTime.of(DIA, LocalTime.parse(hora));
    }

    private static Disponibilidade janela(long prof, String ini, String fim) {
        return new Disponibilidade(prof, DIA, LocalTime.parse(ini), LocalTime.parse(fim));
    }

    private static ItemReserva ocupado(long prof, String ini, String fim) {
        ItemReserva i = new ItemReserva();
        i.setProfissionalId(prof);
        i.setInicio(t(ini));
        i.setFim(t(fim));
        return i;
    }

    private static Servico servico(long id, int minutos) {
        Servico s = new Servico();
        s.setId(id);
        s.setNome("S" + id);
        s.setDuracaoMinutos(minutos);
        s.setPreco(BigDecimal.TEN);
        return s;
    }

    @Test
    void precisaCaberInteiroNaJanela() {
        AgendaDoDia agenda = new AgendaDoDia(List.of(janela(ANA, "09:00", "12:00")), List.of());
        assertTrue(agenda.livre(ANA, t("09:00"), t("10:00")));
        assertTrue(agenda.livre(ANA, t("11:00"), t("12:00")));   // termina exatamente no fim
        assertFalse(agenda.livre(ANA, t("11:30"), t("12:30")));  // estoura o fim
        assertFalse(agenda.livre(ANA, t("08:30"), t("09:30")));  // começa antes
        assertFalse(agenda.livre(BRUNO, t("09:00"), t("10:00"))); // sem janela
    }

    @Test
    void reservaExistenteBloqueiaSobreposicaoMasNaoEncostar() {
        AgendaDoDia agenda = new AgendaDoDia(
                List.of(janela(ANA, "09:00", "18:00")),
                List.of(ocupado(ANA, "10:00", "11:00")));
        assertFalse(agenda.livre(ANA, t("10:30"), t("11:30")));
        assertFalse(agenda.livre(ANA, t("09:30"), t("10:30")));
        assertFalse(agenda.livre(ANA, t("10:15"), t("10:45"))); // totalmente dentro
        assertTrue(agenda.livre(ANA, t("09:00"), t("10:00")));  // encosta antes
        assertTrue(agenda.livre(ANA, t("11:00"), t("12:00")));  // encosta depois
    }

    @Test
    void encadeiaServicosEMantemOMesmoProfissionalQuandoPossivel() {
        AgendaDoDia agenda = new AgendaDoDia(
                List.of(janela(ANA, "09:00", "18:00"), janela(BRUNO, "09:00", "18:00")), List.of());
        List<Servico> servicos = List.of(servico(10, 60), servico(20, 30));
        Map<Long, List<Long>> candidatos = Map.of(10L, List.of(ANA, BRUNO), 20L, List.of(BRUNO, ANA));

        List<ItemReserva> itens = agenda.alocar(t("09:00"), servicos, candidatos);

        assertNotNull(itens);
        assertEquals(2, itens.size());
        assertEquals(t("09:00"), itens.get(0).getInicio());
        assertEquals(t("10:00"), itens.get(0).getFim());
        assertEquals(t("10:00"), itens.get(1).getInicio());
        assertEquals(t("10:30"), itens.get(1).getFim());
        assertEquals(ANA, itens.get(0).getProfissionalId());
        assertEquals(ANA, itens.get(1).getProfissionalId()); // manteve a Ana, apesar de Bruno ser o 1º da lista
    }

    @Test
    void trocaDeProfissionalQuandoOAnteriorEstaOcupadoNaEtapaSeguinte() {
        AgendaDoDia agenda = new AgendaDoDia(
                List.of(janela(ANA, "09:00", "18:00"), janela(BRUNO, "09:00", "18:00")),
                List.of(ocupado(ANA, "10:00", "11:00")));
        List<Servico> servicos = List.of(servico(10, 60), servico(20, 30));
        Map<Long, List<Long>> candidatos = Map.of(10L, List.of(ANA), 20L, List.of(ANA, BRUNO));

        List<ItemReserva> itens = agenda.alocar(t("09:00"), servicos, candidatos);

        assertNotNull(itens);
        assertEquals(ANA, itens.get(0).getProfissionalId());
        assertEquals(BRUNO, itens.get(1).getProfissionalId());
    }

    @Test
    void recusaQuandoAlgumaEtapaNaoTemProfissionalLivre() {
        AgendaDoDia agenda = new AgendaDoDia(
                List.of(janela(ANA, "09:00", "18:00")),
                List.of(ocupado(ANA, "10:00", "11:00")));
        List<Servico> servicos = List.of(servico(10, 60), servico(20, 30));
        // preferência: só a Ana pode fazer os dois, mas ela está ocupada às 10:00
        Map<Long, List<Long>> candidatos = Map.of(10L, List.of(ANA), 20L, List.of(ANA));

        assertNull(agenda.alocar(t("09:00"), servicos, candidatos));
        assertNotNull(agenda.alocar(t("11:00"), servicos, candidatos));
    }

    @Test
    void doisClientesNaoConseguemOMesmoHorario() {
        // Simula a segunda tentativa depois que a primeira reserva já foi gravada.
        List<Servico> servicos = List.of(servico(10, 60));
        Map<Long, List<Long>> candidatos = Map.of(10L, List.of(ANA));
        List<Disponibilidade> janelas = List.of(janela(ANA, "09:00", "18:00"));

        List<ItemReserva> primeira = new AgendaDoDia(janelas, List.of()).alocar(t("14:00"), servicos, candidatos);
        assertNotNull(primeira);

        List<ItemReserva> segunda = new AgendaDoDia(janelas, primeira).alocar(t("14:00"), servicos, candidatos);
        assertNull(segunda);
    }
}
