<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Serviços</title>
</head>
<body>
<h1>Nossos serviços</h1>

<form action="servicos" method="get">
    <label>Especialidade:</label>
    <select name="especialidadeId">
        <option value="">Todas</option>
        <c:forEach var="e" items="${especialidades}">
            <option value="${e.id}" ${e.id == especialidadeId ? 'selected' : ''}>${e.nome}</option>
        </c:forEach>
    </select>

    <label>Profissional:</label>
    <select name="profissionalId">
        <option value="">Todos</option>
        <c:forEach var="p" items="${profissionais}">
            <option value="${p.id}" ${p.id == profissionalId ? 'selected' : ''}>${p.nome}</option>
        </c:forEach>
    </select>

    <button type="submit">Filtrar</button>
    <a href="servicos">Limpar</a>
</form>

<table border="1" cellpadding="5">
    <tr>
        <th>Serviço</th>
        <th>Especialidade</th>
        <th>Duração</th>
        <th>Preço</th>
    </tr>
    <c:forEach var="s" items="${servicos}">
        <tr>
            <td>${s.nome}</td>
            <td>${s.especialidade.nome}</td>
            <td>${s.duracaoMinutos} min</td>
            <td><fmt:formatNumber value="${s.preco}" type="currency" currencySymbol="R$ "/></td>
        </tr>
    </c:forEach>
    <c:if test="${empty servicos}">
        <tr><td colspan="4">Nenhum serviço encontrado.</td></tr>
    </c:if>
</table>

<h2>Pacotes</h2>
<table border="1" cellpadding="5">
    <tr>
        <th>Pacote</th>
        <th>Serviços</th>
        <th>Duração</th>
        <th>Preço</th>
    </tr>
    <c:forEach var="p" items="${pacotes}">
        <tr>
            <td>${p.nome}</td>
            <td>
                <c:forEach var="i" items="${p.itens}" varStatus="st">
                    ${i.servico.nome}<c:if test="${!st.last}">, </c:if>
                </c:forEach>
            </td>
            <td>${p.duracaoTotal} min</td>
            <td><fmt:formatNumber value="${p.preco}" type="currency" currencySymbol="R$ "/></td>
        </tr>
    </c:forEach>
</table>

<p><a href="${pageContext.request.contextPath}/servicos?acao=admin">Voltar</a></p>

</body>
</html>
