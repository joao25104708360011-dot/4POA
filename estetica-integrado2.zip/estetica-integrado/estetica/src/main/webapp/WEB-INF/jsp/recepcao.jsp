<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="pt_BR"/>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Recepção</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 1000px; margin: 1.5rem auto; padding: 0 1rem; color: #222; }
        h2 { margin-top: 2rem; }
        .ok { background: #e6f6ea; border: 1px solid #9bd3a8; padding: .6rem .8rem; border-radius: 6px; }
        .erro { background: #fdecea; border: 1px solid #f1a9a0; padding: .6rem .8rem; border-radius: 6px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: .45rem; border-bottom: 1px solid #e3e3e3; vertical-align: middle; }
        th { background: #f6f6f6; }
        form.inline { display: inline; }
        button { cursor: pointer; padding: .3rem .7rem; }
        .perigo { color: #a11; }
        .vazio { color: #777; }
        fieldset { border: 1px solid #ddd; border-radius: 8px; }
        fieldset label { margin-right: 1rem; }
        input[type=number] { width: 7rem; padding: .3rem; }
    </style>
</head>
<body>
<h1>Painel da recepção</h1>

<form method="get" action="${ctx}/recepcao">
    <label>Data: <input type="date" name="data" value="${dataIso}"></label>
    <button type="submit">Ver</button>
</form>

<c:if test="${not empty flashOk}"><p class="ok"><c:out value="${flashOk}"/></p></c:if>
<c:if test="${not empty flashErro}"><p class="erro"><c:out value="${flashErro}"/></p></c:if>

<c:if test="${not empty painel}">

    <h2>Aguardando chegada (reservas confirmadas)</h2>
    <c:choose>
        <c:when test="${empty painel.pendentes}"><p class="vazio">Nenhuma reserva pendente.</p></c:when>
        <c:otherwise>
            <table>
                <thead><tr><th>Horário</th><th>Cliente</th><th>Serviço</th><th>Valor</th><th>Ações</th></tr></thead>
                <tbody>
                <c:forEach var="r" items="${painel.pendentes}">
                    <tr>
                        <td><c:out value="${r.inicioFormatado}"/></td>
                        <td><c:out value="${r.nomeCliente}"/></td>
                        <td><c:out value="${r.nomeServico}"/></td>
                        <td><fmt:formatNumber value="${r.valor}" type="currency" currencyCode="BRL"/></td>
                        <td>
                            <form class="inline" method="post" action="${ctx}/recepcao">
                                <input type="hidden" name="acao" value="presenca">
                                <input type="hidden" name="reservaId" value="${r.id}">
                                <button type="submit">Marcar presença</button>
                            </form>
                            <form class="inline" method="post" action="${ctx}/recepcao"
                                  onsubmit="return confirm('Registrar FALTA? O cliente perde metade do valor e a outra metade vira crédito.');">
                                <input type="hidden" name="acao" value="falta">
                                <input type="hidden" name="reservaId" value="${r.id}">
                                <button type="submit" class="perigo">Registrar falta</button>
                            </form>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2>Chegadas (presença marcada)</h2>
    <c:choose>
        <c:when test="${empty painel.chegadas}"><p class="vazio">Nenhuma chegada registrada.</p></c:when>
        <c:otherwise>
            <table>
                <thead><tr><th>Horário</th><th>Cliente</th><th>Serviço</th></tr></thead>
                <tbody>
                <c:forEach var="r" items="${painel.chegadas}">
                    <tr>
                        <td><c:out value="${r.inicioFormatado}"/></td>
                        <td><c:out value="${r.nomeCliente}"/></td>
                        <td><c:out value="${r.nomeServico}"/></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2>Atrasos (mais de 15 min — vaga liberada)</h2>
    <c:choose>
        <c:when test="${empty painel.atrasos}"><p class="vazio">Nenhum atraso.</p></c:when>
        <c:otherwise>
            <table>
                <thead><tr><th>Horário</th><th>Cliente</th><th>Serviço</th><th>Ações</th></tr></thead>
                <tbody>
                <c:forEach var="r" items="${painel.atrasos}">
                    <tr>
                        <td><c:out value="${r.inicioFormatado}"/></td>
                        <td><c:out value="${r.nomeCliente}"/></td>
                        <td><c:out value="${r.nomeServico}"/></td>
                        <td>
                            <form class="inline" method="post" action="${ctx}/recepcao">
                                <input type="hidden" name="acao" value="presenca">
                                <input type="hidden" name="reservaId" value="${r.id}">
                                <button type="submit">Cliente chegou</button>
                            </form>
                            <form class="inline" method="post" action="${ctx}/recepcao"
                                  onsubmit="return confirm('Registrar FALTA? O cliente perde metade do valor e a outra metade vira crédito.');">
                                <input type="hidden" name="acao" value="falta">
                                <input type="hidden" name="reservaId" value="${r.id}">
                                <button type="submit" class="perigo">Registrar falta</button>
                            </form>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2>Faltas</h2>
    <c:choose>
        <c:when test="${empty painel.faltas}"><p class="vazio">Nenhuma falta registrada.</p></c:when>
        <c:otherwise>
            <table>
                <thead><tr><th>Horário</th><th>Cliente</th><th>Serviço</th><th>Valor da reserva</th></tr></thead>
                <tbody>
                <c:forEach var="r" items="${painel.faltas}">
                    <tr>
                        <td><c:out value="${r.inicioFormatado}"/></td>
                        <td><c:out value="${r.nomeCliente}"/></td>
                        <td><c:out value="${r.nomeServico}"/></td>
                        <td><fmt:formatNumber value="${r.valor}" type="currency" currencyCode="BRL"/></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2>Fila de espera</h2>
    <c:choose>
        <c:when test="${empty painel.fila}"><p class="vazio">Ninguém na fila.</p></c:when>
        <c:otherwise>
            <table>
                <thead><tr><th>Serviço</th><th>Ordem</th><th>Cliente</th><th>Status</th><th>Ações</th></tr></thead>
                <tbody>
                <c:forEach var="f" items="${painel.fila}">
                    <tr>
                        <td><c:out value="${f.nomeServico}"/></td>
                        <td><c:out value="${f.ordem}"/></td>
                        <td><c:out value="${f.nomeCliente}"/></td>
                        <td><c:out value="${f.status}"/></td>
                        <td>
                            <form class="inline" method="post" action="${ctx}/fila-espera">
                                <input type="hidden" name="acao" value="atender">
                                <input type="hidden" name="filaId" value="${f.id}">
                                <button type="submit">Atender</button>
                            </form>
                            <form class="inline" method="post" action="${ctx}/fila-espera">
                                <input type="hidden" name="acao" value="desistir">
                                <input type="hidden" name="filaId" value="${f.id}">
                                <button type="submit">Desistiu</button>
                            </form>
                            <form class="inline" method="post" action="${ctx}/fila-espera">
                                <input type="hidden" name="acao" value="chamar">
                                <input type="hidden" name="servicoId" value="${f.servicoId}">
                                <input type="hidden" name="data" value="${painel.data}">
                                <button type="submit">Chamar próximo do serviço</button>
                            </form>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2>Atendimento sem reserva</h2>
    <form method="post" action="${ctx}/recepcao">
        <fieldset>
            <legend>Cliente chegou sem reserva</legend>
            <input type="hidden" name="acao" value="sem-reserva">
            <label>ID do cliente: <input type="number" name="clienteId" min="1" required></label>
            <label>ID do serviço: <input type="number" name="servicoId" min="1" required></label>
            <button type="submit">Verificar horário / entrar na fila</button>
        </fieldset>
    </form>
</c:if>
</body>
</html>
