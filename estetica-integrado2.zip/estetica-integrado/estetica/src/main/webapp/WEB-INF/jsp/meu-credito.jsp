<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="pt_BR"/>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Meu crédito</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 720px; margin: 2rem auto; padding: 0 1rem; color: #222; }
        .saldo { font-size: 2rem; font-weight: 700; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { text-align: left; padding: .5rem; border-bottom: 1px solid #e3e3e3; }
        th { background: #f6f6f6; }
    </style>
</head>
<body>
<h1>Meu crédito</h1>
<p>Saldo disponível:</p>
<p class="saldo"><fmt:formatNumber value="${saldoTotal}" type="currency" currencyCode="BRL"/></p>
<p>O crédito é aplicado automaticamente (do mais antigo ao mais novo) quando você marca "usar meu crédito" no pagamento de uma reserva.</p>

<c:choose>
    <c:when test="${empty creditos}">
        <p>Você ainda não possui créditos.</p>
    </c:when>
    <c:otherwise>
        <table>
            <thead>
            <tr><th>Data</th><th>Origem</th><th>Valor original</th><th>Saldo</th></tr>
            </thead>
            <tbody>
            <c:forEach var="cr" items="${creditos}">
                <tr>
                    <td><c:out value="${cr.criadoEmFormatado}"/></td>
                    <td><c:out value="${cr.origem}"/></td>
                    <td><fmt:formatNumber value="${cr.valor}" type="currency" currencyCode="BRL"/></td>
                    <td><fmt:formatNumber value="${cr.saldo}" type="currency" currencyCode="BRL"/></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </c:otherwise>
</c:choose>
</body>
</html>
