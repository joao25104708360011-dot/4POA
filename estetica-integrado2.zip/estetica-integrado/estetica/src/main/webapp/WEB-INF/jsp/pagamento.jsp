<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="pt_BR"/>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagamento da reserva</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 520px; margin: 2rem auto; padding: 0 1rem; color: #222; }
        .ok { background: #e6f6ea; border: 1px solid #9bd3a8; padding: .6rem .8rem; border-radius: 6px; }
        .erro { background: #fdecea; border: 1px solid #f1a9a0; padding: .6rem .8rem; border-radius: 6px; }
        .card { border: 1px solid #ddd; border-radius: 8px; padding: 1rem; margin: 1rem 0; }
        label { display: block; margin-top: .8rem; font-weight: 600; }
        input[type=text] { width: 100%; padding: .5rem; box-sizing: border-box; }
        .linha { display: flex; gap: .8rem; } .linha > div { flex: 1; }
        button { margin-top: 1.2rem; padding: .7rem 1.2rem; font-size: 1rem; cursor: pointer; }
        small { color: #666; }
    </style>
</head>
<body>
<h1>Pagamento da reserva</h1>

<c:if test="${not empty flashOk}"><p class="ok"><c:out value="${flashOk}"/></p></c:if>
<c:if test="${not empty flashErro}"><p class="erro"><c:out value="${flashErro}"/></p></c:if>

<c:if test="${not empty reserva}">
    <div class="card">
        <strong><c:out value="${reserva.nomeServico}"/></strong><br>
        <c:out value="${reserva.inicioFormatado}"/><br>
        Valor: <strong><fmt:formatNumber value="${reserva.valor}" type="currency" currencyCode="BRL"/></strong><br>
        Status: <c:out value="${reserva.status}"/>
    </div>

    <c:if test="${reserva.status == 'AGUARDANDO_PAGAMENTO'}">
        <form method="post" action="${pageContext.request.contextPath}/pagamento" autocomplete="on">
            <input type="hidden" name="reservaId" value="${reserva.id}">

            <c:if test="${saldoCredito.signum() > 0}">
                <label>
                    <input type="checkbox" name="usarCredito" checked>
                    Usar meu crédito (saldo:
                    <fmt:formatNumber value="${saldoCredito}" type="currency" currencyCode="BRL"/>)
                </label>
            </c:if>

            <label for="nome">Nome no cartão</label>
            <input type="text" id="nome" name="nome" autocomplete="cc-name" required
                   value="<c:out value='${nomeCartao}'/>">

            <label for="numero">Número do cartão de crédito</label>
            <input type="text" id="numero" name="numero" inputmode="numeric" autocomplete="cc-number"
                   maxlength="23" placeholder="0000 0000 0000 0000" required>

            <div class="linha">
                <div>
                    <label for="validade">Validade (MM/AA)</label>
                    <input type="text" id="validade" name="validade" autocomplete="cc-exp"
                           maxlength="5" placeholder="MM/AA" pattern="\d{2}/\d{2}" required>
                </div>
                <div>
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" name="cvv" inputmode="numeric" autocomplete="cc-csc"
                           maxlength="4" required>
                </div>
            </div>

            <small>Aceitamos somente cartão de crédito. Guardamos apenas a bandeira e os 4 últimos dígitos.</small><br>
            <small>Faltou sem avisar? Você perde metade do valor e a outra metade vira crédito para uma próxima reserva.</small>
            <br>
            <button type="submit">Pagar e confirmar reserva</button>
        </form>
    </c:if>
</c:if>

<p><a href="${pageContext.request.contextPath}/meu-credito">Ver meu crédito</a></p>
</body>
</html>
