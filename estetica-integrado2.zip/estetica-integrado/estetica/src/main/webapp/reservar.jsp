<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="pt_BR"/>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reservar horário</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/agenda.css">
</head>
<body>
<main class="container">
    <div class="topo">
        <h1>Reservar horário</h1>
        <a class="botao secundario" href="${pageContext.request.contextPath}/reservas">Minhas reservas</a>
    </div>

    <c:if test="${not empty flash_erro}">
        <div class="alerta erro" role="alert"><c:out value="${flash_erro}"/></div>
    </c:if>

    <form id="form-reserva" method="post" action="${pageContext.request.contextPath}/reservas">
        <input type="hidden" name="acao" value="criar">
        <input type="hidden" name="hora" id="hora">

        <%-- 1. O que fazer --%>
        <section class="passo">
            <h2>1. O que você vai fazer?</h2>
            <div class="opcoes">
                <label><input type="radio" name="modo" value="avulso" checked> Serviços avulsos</label>
                <c:if test="${not empty pacotes}">
                    <label><input type="radio" name="modo" value="pacote"> Pacote</label>
                </c:if>
            </div>

            <fieldset id="grupo-avulso">
                <input type="search" id="filtro" placeholder="Filtrar serviços pelo nome..." autocomplete="off">
                <ul class="lista" id="lista-servicos">
                    <c:forEach var="s" items="${servicos}">
                        <li>
                            <label>
                                <input type="checkbox" name="servicoIds" value="${s.id}"
                                       data-duracao="${s.duracaoMinutos}" data-preco="${s.preco}">
                                <span class="nome"><c:out value="${s.nome}"/></span>
                                <span class="meta">${s.duracaoMinutos} min · <fmt:formatNumber value="${s.preco}" type="currency"/></span>
                            </label>
                        </li>
                    </c:forEach>
                </ul>
                <c:if test="${empty servicos}"><p class="vazio">Nenhum serviço disponível no momento.</p></c:if>
            </fieldset>

            <fieldset id="grupo-pacote" class="oculto" disabled>
                <c:forEach var="p" items="${pacotes}">
                    <label class="cartao">
                        <input type="radio" name="pacoteId" value="${p.id}"
                               data-preco="${p.preco}" data-duracao="${p.duracaoTotal}"
                               data-servicos="${p.servicoIdsCsv}">
                        <span>
                            <strong><c:out value="${p.nome}"/></strong>
                            · <fmt:formatNumber value="${p.preco}" type="currency"/> · ${p.duracaoTotal} min
                            <small>
                                <c:forEach var="s" items="${p.servicos}" varStatus="st"><c:out value="${s.nome}"/><c:if test="${!st.last}">, </c:if></c:forEach>
                            </small>
                        </span>
                    </label>
                </c:forEach>
            </fieldset>
        </section>

        <%-- 2. Quem atende --%>
        <section class="passo">
            <h2>2. Quem vai atender?</h2>
            <div class="opcoes">
                <label><input type="radio" name="tipo" value="DISPONIVEL" checked> Qualquer profissional disponível</label>
                <label><input type="radio" name="tipo" value="PREFERENCIA"> Tenho um profissional de preferência</label>
            </div>
            <div class="profissional oculto" id="bloco-profissional">
                <select name="profissionalId" id="profissional" disabled>
                    <option value="">Escolha os serviços primeiro</option>
                </select>
            </div>
        </section>

        <%-- 3. Dia e horário --%>
        <section class="passo">
            <h2>3. Dia e horário</h2>
            <input type="date" name="data" id="data" min="${hoje}" required>
            <div class="horarios" id="horarios" aria-live="polite">
                <span class="aviso">Escolha os serviços e o dia para ver os horários livres.</span>
            </div>
        </section>

        <%-- 4. Confirmar --%>
        <section class="passo resumo">
            <div>
                <div id="resumo-texto" class="meta">Nenhum serviço selecionado</div>
                <strong id="resumo-total">R$ 0,00</strong>
            </div>
            <button type="submit" class="botao" id="confirmar" disabled>Confirmar reserva</button>
        </section>
    </form>
</main>

<script>
(function () {
    var ctx = '${pageContext.request.contextPath}';
    var form = document.getElementById('form-reserva');
    var campoHora = document.getElementById('hora');
    var campoData = document.getElementById('data');
    var boxHorarios = document.getElementById('horarios');
    var selectProf = document.getElementById('profissional');
    var blocoProf = document.getElementById('bloco-profissional');
    var botao = document.getElementById('confirmar');
    var versaoBusca = 0; // descarta respostas antigas se o cliente mudar a escolha rapidamente

    function modo() { return form.elements['modo'].value; }
    function tipo() { return form.elements['tipo'].value; }

    function moeda(valor) {
        return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    // Serviços efetivamente escolhidos (avulsos marcados, ou os do pacote selecionado).
    function ids() {
        if (modo() === 'pacote') {
            var p = form.querySelector('input[name=pacoteId]:checked');
            return p && p.dataset.servicos ? p.dataset.servicos.split(',') : [];
        }
        return Array.prototype.map.call(
            form.querySelectorAll('input[name=servicoIds]:checked'), function (i) { return i.value; });
    }

    function atualizarResumo() {
        var minutos = 0, total = 0, qtd = 0;
        if (modo() === 'pacote') {
            var p = form.querySelector('input[name=pacoteId]:checked');
            if (p) { minutos = +p.dataset.duracao; total = +p.dataset.preco; qtd = 1; }
        } else {
            form.querySelectorAll('input[name=servicoIds]:checked').forEach(function (i) {
                minutos += +i.dataset.duracao; total += +i.dataset.preco; qtd++;
            });
        }
        document.getElementById('resumo-texto').textContent = qtd === 0
            ? 'Nenhum serviço selecionado'
            : (modo() === 'pacote' ? 'Pacote' : qtd + (qtd === 1 ? ' serviço' : ' serviços')) + ' · ' + minutos + ' min no total';
        document.getElementById('resumo-total').textContent = moeda(total);
    }

    function limparHorario() {
        campoHora.value = '';
        botao.disabled = true;
    }

    function aviso(texto) {
        boxHorarios.innerHTML = '';
        var s = document.createElement('span');
        s.className = 'aviso';
        s.textContent = texto;
        boxHorarios.appendChild(s);
    }

    function consulta(extra) {
        var q = new URLSearchParams(extra || {});
        ids().forEach(function (id) { q.append('servicoIds', id); });
        return q;
    }

    function carregarProfissionais() {
        if (tipo() !== 'PREFERENCIA') { return Promise.resolve(); }
        var lista = ids();
        if (lista.length === 0) {
            selectProf.innerHTML = '<option value="">Escolha os serviços primeiro</option>';
            selectProf.disabled = true;
            return Promise.resolve();
        }
        return fetch(ctx + '/disponibilidade?' + consulta({ acao: 'profissionais' }))
            .then(function (r) { return r.json(); })
            .then(function (j) {
                var anterior = selectProf.value;
                selectProf.innerHTML = '';
                if (!j.profissionais || j.profissionais.length === 0) {
                    selectProf.appendChild(new Option('Nenhum profissional faz todos esses serviços', ''));
                    selectProf.disabled = true;
                    return;
                }
                selectProf.appendChild(new Option('Selecione...', ''));
                j.profissionais.forEach(function (p) {
                    selectProf.appendChild(new Option(p.nome, p.id, false, String(p.id) === anterior));
                });
                selectProf.disabled = false;
            });
    }

    function carregarHorarios() {
        limparHorario();
        var lista = ids();
        if (lista.length === 0 || !campoData.value) {
            aviso('Escolha os serviços e o dia para ver os horários livres.');
            return;
        }
        if (tipo() === 'PREFERENCIA' && !selectProf.value) {
            aviso('Escolha o profissional para ver os horários.');
            return;
        }
        var extra = { data: campoData.value, tipo: tipo() };
        if (tipo() === 'PREFERENCIA') { extra.profissionalId = selectProf.value; }

        var minhaVersao = ++versaoBusca;
        aviso('Buscando horários...');
        fetch(ctx + '/disponibilidade?' + consulta(extra))
            .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, corpo: j }; }); })
            .then(function (res) {
                if (minhaVersao !== versaoBusca) { return; }
                if (!res.ok) { aviso(res.corpo.erro || 'Não foi possível buscar os horários.'); return; }
                if (res.corpo.horarios.length === 0) { aviso('Sem horários livres nesse dia. Tente outra data.'); return; }
                boxHorarios.innerHTML = '';
                res.corpo.horarios.forEach(function (h) {
                    var b = document.createElement('button');
                    b.type = 'button';
                    b.className = 'slot';
                    b.textContent = h;
                    b.addEventListener('click', function () {
                        boxHorarios.querySelectorAll('.slot').forEach(function (s) { s.classList.remove('ativo'); });
                        b.classList.add('ativo');
                        campoHora.value = h;
                        botao.disabled = false;
                    });
                    boxHorarios.appendChild(b);
                });
            })
            .catch(function () { if (minhaVersao === versaoBusca) { aviso('Erro de conexão. Tente novamente.'); } });
    }

    function aoMudarEscolha() {
        atualizarResumo();
        carregarProfissionais().then(carregarHorarios);
    }

    // Filtro por nome
    document.getElementById('filtro').addEventListener('input', function () {
        var termo = this.value.trim().toLowerCase();
        document.querySelectorAll('#lista-servicos li').forEach(function (li) {
            var nome = li.querySelector('.nome').textContent.toLowerCase();
            li.classList.toggle('oculto', termo !== '' && nome.indexOf(termo) === -1);
        });
    });

    // Avulso x pacote: só o grupo visível é enviado (fieldset desabilitado não vai no POST)
    Array.prototype.forEach.call(form.elements['modo'], function (r) {
        r.addEventListener('change', function () {
            var pacote = modo() === 'pacote';
            document.getElementById('grupo-avulso').disabled = pacote;
            document.getElementById('grupo-avulso').classList.toggle('oculto', pacote);
            document.getElementById('grupo-pacote').disabled = !pacote;
            document.getElementById('grupo-pacote').classList.toggle('oculto', !pacote);
            aoMudarEscolha();
        });
    });

    // Livre x preferência
    Array.prototype.forEach.call(form.elements['tipo'], function (r) {
        r.addEventListener('change', function () {
            var preferencia = tipo() === 'PREFERENCIA';
            blocoProf.classList.toggle('oculto', !preferencia);
            selectProf.disabled = !preferencia;
            if (preferencia) { carregarProfissionais().then(carregarHorarios); } else { carregarHorarios(); }
        });
    });

    form.addEventListener('change', function (e) {
        var nome = e.target.name;
        if (nome === 'servicoIds' || nome === 'pacoteId') { aoMudarEscolha(); }
    });
    campoData.addEventListener('change', carregarHorarios);
    selectProf.addEventListener('change', carregarHorarios);

    form.addEventListener('submit', function (e) {
        if (!campoHora.value || ids().length === 0) { e.preventDefault(); }
    });

    atualizarResumo();
})();
</script>
</body>
</html>
