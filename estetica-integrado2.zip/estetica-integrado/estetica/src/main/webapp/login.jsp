<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="caixa">
    <h2>Entrar</h2>

    <form id="formLogin">
        <label>Login</label>
        <input type="text" id="login" required>

        <label>Senha</label>
        <input type="password" id="senha" required>

        <button type="submit">Entrar</button>
    </form>

    <p id="mensagem" class="mensagem"></p>

    <p class="link">Não tem conta? <a href="cadastro.jsp">Cadastre-se</a></p>
</div>

<script>
    document.getElementById('formLogin').addEventListener('submit', async function (e) {
        e.preventDefault();

        const mensagem = document.getElementById('mensagem');

        try {
            const resposta = await fetch('login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    login: document.getElementById('login').value,
                    senha: document.getElementById('senha').value
                })
            });

            const dados = await resposta.json();

            if (resposta.ok) {
                localStorage.setItem('token', dados.token);
                window.location.href = 'index.jsp';
            } else {
                mensagem.className = 'mensagem erro';
                mensagem.textContent = dados.erro;
            }
        } catch (erro) {
            mensagem.className = 'mensagem erro';
            mensagem.textContent = 'Erro de conexão com o servidor.';
        }
    });
</script>

</body>
</html>