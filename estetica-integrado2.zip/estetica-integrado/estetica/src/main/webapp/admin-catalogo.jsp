<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Administração do catálogo</title>
</head>
<body>
<h1>Catálogo do salão</h1>

<c:if test="${not empty sessionScope.erro}">
    <p style="color:red">${sessionScope.erro}</p>
    <c:remove var="erro" scope="session"/>
</c:if>

<h2>Especialidades</h2>
<form action="especialidades" method="post">
    <input type="hidden" name="id" value="${especialidade.id}">
    <input type="text" name="nome" placeholder="Nome" value="${especialidade.nome}" required>
    <button type="submit">Salvar</button>
</form>
<table border="1" cellpadding="5">
    <c:forEach var="e" items="${especialidades}">
        <tr>
            <td>${e.nome}</td>
            <td><a href="servicos?acao=admin&editarEspecialidade=${e.id}">Editar</a></td>
            <td>
                <form action="especialidades" method="post">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${e.id}">
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>

<h2>Profissionais</h2>
<form action="profissionais" method="post">
    <input type="hidden" name="id" value="${profissional.id}">
    <input type="text" name="nome" placeholder="Nome" value="${profissional.nome}" required>
    <input type="text" name="telefone" placeholder="Telefone" value="${profissional.telefone}">
    <select name="especialidadeId" required>
        <c:forEach var="e" items="${especialidades}">
            <option value="${e.id}" ${e.id == profissional.especialidade.id ? 'selected' : ''}>${e.nome}</option>
        </c:forEach>
    </select>
    <button type="submit">Salvar</button>
</form>
<table border="1" cellpadding="5">
    <c:forEach var="p" items="${profissionais}">
        <tr>
            <td>${p.nome}</td>
            <td>${p.telefone}</td>
            <td>${p.especialidade.nome}</td>
            <td><a href="servicos?acao=admin&editarProfissional=${p.id}">Editar</a></td>
            <td>
                <form action="profissionais" method="post">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${p.id}">
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>

<h2>Serviços</h2>
<form action="servicos" method="post">
    <input type="hidden" name="id" value="${servico.id}">
    <input type="text" name="nome" placeholder="Nome" value="${servico.nome}" required>
    <input type="text" name="preco" placeholder="Preço" value="${servico.preco}" required>
    <input type="number" name="duracaoMinutos" placeholder="Duração (min)" value="${servico.duracaoMinutos}" min="1" required>
    <select name="especialidadeId" required>
        <c:forEach var="e" items="${especialidades}">
            <option value="${e.id}" ${e.id == servico.especialidade.id ? 'selected' : ''}>${e.nome}</option>
        </c:forEach>
    </select>
    <button type="submit">Salvar</button>
</form>
<table border="1" cellpadding="5">
    <c:forEach var="s" items="${servicos}">
        <tr>
            <td>${s.nome}</td>
            <td>R$ ${s.preco}</td>
            <td>${s.duracaoMinutos} min</td>
            <td>${s.especialidade.nome}</td>
            <td><a href="servicos?acao=admin&editarServico=${s.id}">Editar</a></td>
            <td>
                <form action="servicos" method="post">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${s.id}">
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>

<h2>Pacotes</h2>
<form action="pacotes" method="post">
    <input type="hidden" name="id" value="${pacote.id}">
    <input type="text" name="nome" placeholder="Nome" value="${pacote.nome}" required>
    <input type="text" name="preco" placeholder="Preço" value="${pacote.preco}" required>
    <p>Serviços do pacote:</p>
    <c:forEach var="s" items="${servicos}">
        <c:set var="marcado" value=""/>
        <c:forEach var="i" items="${pacote.itens}">
            <c:if test="${i.servico.id == s.id}"><c:set var="marcado" value="checked"/></c:if>
        </c:forEach>
        <label><input type="checkbox" name="servicosIds" value="${s.id}" ${marcado}> ${s.nome}</label><br>
    </c:forEach>
    <button type="submit">Salvar</button>
</form>
<table border="1" cellpadding="5">
    <c:forEach var="p" items="${pacotes}">
        <tr>
            <td>${p.nome}</td>
            <td>R$ ${p.preco}</td>
            <td>
                <c:forEach var="i" items="${p.itens}" varStatus="st">
                    ${i.servico.nome}<c:if test="${!st.last}">, </c:if>
                </c:forEach>
            </td>
            <td><a href="servicos?acao=admin&editarPacote=${p.id}">Editar</a></td>
            <td>
                <form action="pacotes" method="post">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${p.id}">
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>

<p><a href="servicos">Ver vitrine</a></p>
</body>
</html>
