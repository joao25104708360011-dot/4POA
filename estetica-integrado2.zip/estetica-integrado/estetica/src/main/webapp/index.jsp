<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Início</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="pagina">

    <div class="topo">
        <h2 id="titulo">Início</h2>
        <button class="vermelho" onclick="sair()">Sair</button>
    </div>

    <p id="mensagem" class="mensagem"></p>

    <div id="areaCliente" class="painel escondido">
        <h3>Reservas</h3>
        <p>
            <a href="reservas?acao=nova">Nova reserva</a> |
            <a href="reservas">Minhas reservas</a> |
            <a href="meu-credito">Meu crédito</a>
        </p>
    </div>

    <div id="areaDados" class="painel escondido">
        <h3>Meus dados</h3>

        <form id="formDados">
            <label>Nome</label>
            <input type="text" id="nome" required>

            <label>E-mail</label>
            <input type="text" id="email" required>

            <label>Telefone</label>
            <input type="text" id="telefone">

            <button type="submit">Salvar</button>
        </form>
    </div>

    <div id="areaRecepcao" class="painel escondido">
        <h3>Recepção</h3>
        <p><a href="recepcao">Abrir painel da recepção (chegadas, faltas e fila de espera)</a></p>

        <h3>Clientes</h3>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Telefone</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody id="tabelaClientes"></tbody>
        </table>
    </div>

</div>

<script>
    const token = localStorage.getItem('token');

    if (!token) {
        sair();
    } else {
        iniciar();
    }

    function sair() {
        localStorage.removeItem('token');
        // encerra também a sessão HTTP usada pelos módulos de agenda e pagamento
        fetch('logout', { method: 'POST' }).finally(function () {
            window.location.href = 'login.jsp';
        });
    }

    function mostrar(texto, tipo) {
        const mensagem = document.getElementById('mensagem');
        mensagem.className = 'mensagem ' + tipo;
        mensagem.textContent = texto;
    }

    function lerPerfil() {
        const corpo = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
        return JSON.parse(atob(corpo)).perfil;
    }

    async function chamar(url, opcoes) {
        opcoes = opcoes || {};
        opcoes.headers = Object.assign({ 'Authorization': 'Bearer ' + token }, opcoes.headers);

        const resposta = await fetch(url, opcoes);

        if (resposta.status === 401) {
            sair();
        }

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.erro);
        }
        return dados;
    }

    async function iniciar() {
        try {
            if (lerPerfil() === 'RECEPCAO') {
                document.getElementById('titulo').textContent = 'Painel da recepção';
                document.getElementById('areaRecepcao').classList.remove('escondido');
                await carregarClientes();
            } else {
                document.getElementById('areaCliente').classList.remove('escondido');
                document.getElementById('areaDados').classList.remove('escondido');
                await carregarMeusDados();
            }
        } catch (erro) {
            mostrar(erro.message, 'erro');
        }
    }

    async function carregarMeusDados() {
        const cliente = await chamar('api/clientes/me');

        document.getElementById('titulo').textContent = 'Olá, ' + cliente.nome;
        document.getElementById('nome').value = cliente.nome;
        document.getElementById('email').value = cliente.email;
        document.getElementById('telefone').value = cliente.telefone || '';
    }

    document.getElementById('formDados').addEventListener('submit', async function (e) {
        e.preventDefault();

        try {
            await chamar('api/clientes/me', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nome: document.getElementById('nome').value,
                    email: document.getElementById('email').value,
                    telefone: document.getElementById('telefone').value
                })
            });

            mostrar('Dados atualizados!', 'ok');
            await carregarMeusDados();
        } catch (erro) {
            mostrar(erro.message, 'erro');
        }
    });

    async function carregarClientes() {
        const clientes = await chamar('api/clientes');

        const tabela = document.getElementById('tabelaClientes');
        tabela.textContent = '';

        clientes.forEach(function (cliente) {
            const linha = document.createElement('tr');

            [cliente.id, cliente.nome, cliente.email, cliente.telefone || ''].forEach(function (valor) {
                const celula = document.createElement('td');
                celula.textContent = valor;
                linha.appendChild(celula);
            });

            const celulaBotao = document.createElement('td');
            const botao = document.createElement('button');
            botao.textContent = 'Excluir';
            botao.addEventListener('click', function () {
                excluir(cliente.id);
            });
            celulaBotao.appendChild(botao);
            linha.appendChild(celulaBotao);

            tabela.appendChild(linha);
        });
    }

    async function excluir(id) {
        if (!confirm('Deseja excluir este cliente?')) {
            return;
        }

        try {
            await chamar('api/clientes/' + id, { method: 'DELETE' });
            mostrar('Cliente removido!', 'ok');
            await carregarClientes();
        } catch (erro) {
            mostrar(erro.message, 'erro');
        }
    }
</script>

</body>
</html>