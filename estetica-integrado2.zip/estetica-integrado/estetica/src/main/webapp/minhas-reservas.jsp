<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="pt_BR"/>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Minhas reservas</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/agenda.css">
</head>
<body>
<main class="container">
    <div class="topo">
        <h1>Minhas reservas</h1>
        <a class="botao" href="${pageContext.request.contextPath}/reservas?acao=nova">Nova reserva</a>
    </div>

    <c:if test="${not empty flash_sucesso}">
        <div class="alerta sucesso" role="status"><c:out value="${flash_sucesso}"/></div>
    </c:if>
    <c:if test="${not empty flash_erro}">
        <div class="alerta erro" role="alert"><c:out value="${flash_erro}"/></div>
    </c:if>

    <c:if test="${empty reservas}">
        <p class="vazio">Você ainda não tem reservas.</p>
    </c:if>

    <c:forEach var="r" items="${reservas}">
        <article class="reserva">
            <header>
                <span class="quando"><c:out value="${r.dataHoraFormatada}"/></span>
                <span class="status ${r.status}"><c:out value="${r.status.rotulo}"/></span>
            </header>

            <ul>
                <c:forEach var="i" items="${r.itens}">
                    <li>
                        <c:out value="${i.inicioFormatado}"/>–<c:out value="${i.fimFormatado}"/>
                        · <c:out value="${i.servicoNome}"/>
                        com <c:out value="${i.profissionalNome}"/>
                    </li>
                </c:forEach>
            </ul>

            <footer>
                <span>
                    <strong><fmt:formatNumber value="${r.valorTotal}" type="currency"/></strong>
                    <span class="meta">· <c:out value="${r.tipoEscolha.rotulo}"/></span>
                </span>

                <c:if test="${r.pagavel}">
                    <a class="botao" href="${pageContext.request.contextPath}/pagamento?reservaId=${r.id}">Pagar agora</a>
                </c:if>

                <c:if test="${r.cancelavel}">
                    <form method="post" action="${pageContext.request.contextPath}/reservas"
                          onsubmit="return confirm('Cancelar esta reserva?');">
                        <input type="hidden" name="acao" value="cancelar">
                        <input type="hidden" name="reservaId" value="${r.id}">
                        <button type="submit" class="botao perigo">Cancelar</button>
                    </form>
                </c:if>
            </footer>
        </article>
    </c:forEach>
</main>
</body>
</html>
