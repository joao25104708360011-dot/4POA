<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="caixa">
    <h2>Criar conta</h2>

    <form id="formCadastro">
        <label>Nome</label>
        <input type="text" id="nome" required>

        <label>E-mail</label>
        <input type="text" id="email" required>

        <label>Telefone</label>
        <input type="text" id="telefone">

        <label>Login</label>
        <input type="text" id="login" required>

        <label>Senha</label>
        <input type="password" id="senha" required>

        <button type="submit">Cadastrar</button>
    </form>

    <p id="mensagem" class="mensagem"></p>

    <p class="link">Já tem conta? <a href="login.jsp">Entrar</a></p>
</div>

<script>
    document.getElementById('formCadastro').addEventListener('submit', async function (e) {
        e.preventDefault();

        const mensagem = document.getElementById('mensagem');

        try {
            const resposta = await fetch('cadastrar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nome: document.getElementById('nome').value,
                    email: document.getElementById('email').value,
                    telefone: document.getElementById('telefone').value,
                    login: document.getElementById('login').value,
                    senha: document.getElementById('senha').value
                })
            });

            const dados = await resposta.json();

            if (resposta.ok) {
                mensagem.className = 'mensagem ok';
                mensagem.textContent = dados.mensagem + ' Redirecionando...';
                setTimeout(function () {
                    window.location.href = 'login.jsp';
                }, 1500);
            } else {
                mensagem.className = 'mensagem erro';
                mensagem.textContent = dados.erro;
            }
        } catch (erro) {
            mensagem.className = 'mensagem erro';
            mensagem.textContent = 'Erro de conexão com o servidor.';
        }
    });
</script>

</body>
</html>