package br.com.xptotec.salao.service;

import br.com.xptotec.salao.dao.FilaEsperaDAO;
import br.com.xptotec.salao.integracao.ReservaIntegracaoDAO;
import br.com.xptotec.salao.integracao.ReservaResumo;
import br.com.xptotec.salao.integracao.StatusReserva;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Regras;
import br.com.xptotec.salao.util.Transacao;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Operações da recepção: marcar presença, falta, atendimento sem reserva e liberar vagas por atraso. */
public class RecepcaoService {

    private static final Logger LOG = Logger.getLogger(RecepcaoService.class.getName());

    private final FaltaService faltaService;
    private final FilaEsperaService filaService;

    public RecepcaoService() {
        this(new FaltaService(), new FilaEsperaService());
    }

    public RecepcaoService(FaltaService faltaService, FilaEsperaService filaService) {
        this.faltaService = faltaService;
        this.filaService = filaService;
    }

    /**
     * Cliente com reserva chegou. Dentro da tolerância (15 min): presença marcada.
     * Passou da tolerância: a vaga é liberada e ele é tratado como chegada com atraso
     * (horário livre hoje, senão fila de espera).
     */
    public ResultadoChegada marcarPresenca(long reservaId) {
        return Transacao.executar(c -> {
            ReservaIntegracaoDAO dao = new ReservaIntegracaoDAO(c);
            ReservaResumo r = dao.buscar(reservaId, true)
                    .orElseThrow(() -> new NegocioException("Reserva não encontrada."));
            boolean jaLiberada = r.is(StatusReserva.ATRASO_LIBERADO);
            if (!r.is(StatusReserva.CONFIRMADA) && !jaLiberada) {
                throw new NegocioException("Reserva não está confirmada (status: " + r.getStatus() + ").");
            }

            LocalDateTime agora = LocalDateTime.now();
            boolean dentroDoPrazo = !jaLiberada
                    && !agora.isAfter(r.getInicio().plusMinutes(Regras.TOLERANCIA_ATRASO_MINUTOS));
            if (dentroDoPrazo) {
                dao.atualizarStatus(reservaId, StatusReserva.PRESENTE);
                return ResultadoChegada.atendimentoNormal();
            }

            if (!jaLiberada) { // primeira vez que percebemos o atraso: libera a vaga
                dao.atualizarStatus(reservaId, StatusReserva.ATRASO_LIBERADO);
                filaService.chamarProximo(c, r.getServicoId(), r.getInicio().toLocalDate());
            }
            return filaService.registrarChegada(c, r.getClienteId(), r.getServicoId(), agora);
        });
    }

    public ResultadoFalta marcarFalta(long reservaId) {
        return faltaService.registrarFalta(reservaId);
    }

    /** Cliente chegou sem reserva: horário livre hoje (marcar na agenda) ou fila de espera. */
    public ResultadoChegada atenderSemReserva(long clienteId, long servicoId) {
        return Transacao.executar(c -> filaService.registrarChegada(c, clienteId, servicoId, LocalDateTime.now()));
    }

    /**
     * Libera as vagas de reservas confirmadas que passaram de 15 minutos sem presença e chama o próximo
     * da fila para cada uma. Chamado periodicamente (AtrasoListener) e ao abrir o painel.
     *
     * @return quantas vagas foram liberadas
     */
    public int liberarVagasAtrasadas() {
        LocalDateTime limite = LocalDateTime.now().minusMinutes(Regras.TOLERANCIA_ATRASO_MINUTOS);
        List<ReservaResumo> candidatas = Transacao.executar(c -> new ReservaIntegracaoDAO(c).listarAtrasadas(limite));
        int liberadas = 0;
        for (ReservaResumo candidata : candidatas) {
            try {
                if (Transacao.executar(c -> liberarVaga(c, candidata.getId()))) {
                    liberadas++;
                }
            } catch (RuntimeException e) {
                LOG.log(Level.WARNING, "Falha ao liberar vaga da reserva " + candidata.getId(), e);
            }
        }
        return liberadas;
    }

    private boolean liberarVaga(Connection c, long reservaId) throws SQLException {
        ReservaIntegracaoDAO dao = new ReservaIntegracaoDAO(c);
        ReservaResumo r = dao.buscar(reservaId, true).orElse(null);
        if (r == null || !r.is(StatusReserva.CONFIRMADA)) {
            return false; // alguém marcou presença/falta nesse meio tempo
        }
        dao.atualizarStatus(reservaId, StatusReserva.ATRASO_LIBERADO);
        filaService.chamarProximo(c, r.getServicoId(), r.getInicio().toLocalDate());
        return true;
    }

    public PainelRecepcao painel(LocalDate dia) {
        return Transacao.executar(c -> {
            PainelRecepcao p = new PainelRecepcao();
            p.setData(dia);
            for (ReservaResumo r : new ReservaIntegracaoDAO(c).listarDoDia(dia)) {
                if (r.is(StatusReserva.CONFIRMADA)) {
                    p.getPendentes().add(r);
                } else if (r.is(StatusReserva.PRESENTE)) {
                    p.getChegadas().add(r);
                } else if (r.is(StatusReserva.ATRASO_LIBERADO)) {
                    p.getAtrasos().add(r);
                } else if (r.is(StatusReserva.FALTA)) {
                    p.getFaltas().add(r);
                }
            }
            p.setFila(new FilaEsperaDAO(c).listarAtivosDoDia(dia));
            return p;
        });
    }
}
