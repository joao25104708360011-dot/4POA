package br.com.xptotec.salao.util;

/** Falha técnica de acesso a dados; a mensagem NÃO deve ser exibida ao usuário. */
public class DaoException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DaoException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
