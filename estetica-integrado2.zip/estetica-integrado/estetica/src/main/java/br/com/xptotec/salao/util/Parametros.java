package br.com.xptotec.salao.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Leitura segura de parâmetros de request. */
public final class Parametros {

    private Parametros() {
    }

    public static long id(String valor) {
        try {
            long v = Long.parseLong(valor == null ? "" : valor.trim());
            if (v <= 0) {
                throw new NumberFormatException();
            }
            return v;
        } catch (NumberFormatException e) {
            throw new NegocioException("Identificador inválido.");
        }
    }

    public static LocalDate dataOuHoje(String valor) {
        if (valor == null || valor.isBlank()) {
            return LocalDate.now();
        }
        try {
            return LocalDate.parse(valor.trim());
        } catch (DateTimeParseException e) {
            throw new NegocioException("Data inválida (use o formato AAAA-MM-DD).");
        }
    }
}
