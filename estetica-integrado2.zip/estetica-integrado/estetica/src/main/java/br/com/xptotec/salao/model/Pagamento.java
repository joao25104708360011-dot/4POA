package br.com.xptotec.salao.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Pagamento de uma reserva. Só cartão de crédito: guardamos apenas bandeira e últimos 4 dígitos
 * (nunca o número completo nem o CVV). Parte do valor pode ter sido paga com crédito do cliente.
 */
public class Pagamento {

    private Long id;
    private long reservaId;
    private long clienteId;
    private BigDecimal valor = BigDecimal.ZERO;
    private BigDecimal valorCredito = BigDecimal.ZERO;
    private BigDecimal valorRetido = BigDecimal.ZERO;
    private String bandeira;
    private String ultimos4;
    private StatusPagamento status;
    private String codigoTransacao;
    private LocalDateTime criadoEm;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public long getReservaId() { return reservaId; }
    public void setReservaId(long reservaId) { this.reservaId = reservaId; }
    public long getClienteId() { return clienteId; }
    public void setClienteId(long clienteId) { this.clienteId = clienteId; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public BigDecimal getValorCredito() { return valorCredito; }
    public void setValorCredito(BigDecimal valorCredito) { this.valorCredito = valorCredito; }
    public BigDecimal getValorRetido() { return valorRetido; }
    public void setValorRetido(BigDecimal valorRetido) { this.valorRetido = valorRetido; }
    public String getBandeira() { return bandeira; }
    public void setBandeira(String bandeira) { this.bandeira = bandeira; }
    public String getUltimos4() { return ultimos4; }
    public void setUltimos4(String ultimos4) { this.ultimos4 = ultimos4; }
    public StatusPagamento getStatus() { return status; }
    public void setStatus(StatusPagamento status) { this.status = status; }
    public String getCodigoTransacao() { return codigoTransacao; }
    public void setCodigoTransacao(String codigoTransacao) { this.codigoTransacao = codigoTransacao; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }

    /** Parte efetivamente cobrada no cartão. */
    public BigDecimal getValorCartao() {
        return valor.subtract(valorCredito);
    }
}
