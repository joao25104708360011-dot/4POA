package br.com.xptotec.salao.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** O que aconteceu quando um cliente chegou na recepção. */
public class ResultadoChegada {

    public enum Tipo {
        /** Chegou dentro do prazo, presença marcada. */
        ATENDIMENTO_NORMAL,
        /** Sem reserva/atrasado, mas existe horário livre hoje: remarcar na agenda (Parte 3). */
        HORARIO_DISPONIVEL,
        /** Sem reserva/atrasado e sem horário: entrou na fila de espera. */
        ENTROU_NA_FILA
    }

    private final Tipo tipo;
    private final LocalDateTime horario;
    private final int posicaoFila;

    private ResultadoChegada(Tipo tipo, LocalDateTime horario, int posicaoFila) {
        this.tipo = tipo;
        this.horario = horario;
        this.posicaoFila = posicaoFila;
    }

    public static ResultadoChegada atendimentoNormal() {
        return new ResultadoChegada(Tipo.ATENDIMENTO_NORMAL, null, 0);
    }

    public static ResultadoChegada horarioDisponivel(LocalDateTime horario) {
        return new ResultadoChegada(Tipo.HORARIO_DISPONIVEL, horario, 0);
    }

    public static ResultadoChegada naFila(int posicao) {
        return new ResultadoChegada(Tipo.ENTROU_NA_FILA, null, posicao);
    }

    public Tipo getTipo() { return tipo; }
    public LocalDateTime getHorario() { return horario; }
    public int getPosicaoFila() { return posicaoFila; }

    /** Mensagem pronta para a recepção. */
    public String getMensagem() {
        return switch (tipo) {
            case ATENDIMENTO_NORMAL -> "Presença registrada. Cliente pode ser atendido.";
            case HORARIO_DISPONIVEL -> "Há horário livre hoje às "
                    + horario.format(DateTimeFormatter.ofPattern("HH:mm"))
                    + ". Marque o horário para o cliente na agenda.";
            case ENTROU_NA_FILA -> "Sem horário disponível. Cliente entrou na fila de espera (posição "
                    + posicaoFila + ").";
        };
    }
}
