package br.com.xptotec.salao.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Constantes das regras do minimundo (um só lugar para ajustar). */
public final class Regras {

    /** Tolerância de atraso: após isso a vaga é liberada para a fila de espera. */
    public static final int TOLERANCIA_ATRASO_MINUTOS = 15;

    /** Em caso de falta, o cliente perde metade do valor; a outra metade vira crédito. */
    public static final BigDecimal FRACAO_RETIDA_FALTA = new BigDecimal("0.50");

    private Regras() {
    }

    public static BigDecimal valorRetidoNaFalta(BigDecimal valorReserva) {
        return valorReserva.multiply(FRACAO_RETIDA_FALTA).setScale(2, RoundingMode.HALF_UP);
    }
}
