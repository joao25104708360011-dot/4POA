package br.com.xptotec.salao.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/** Entrada na fila de espera (cliente, serviço, data, ordem, status). */
public class FilaEspera {

    private Long id;
    private long clienteId;
    private long servicoId;
    private LocalDate data;
    private int ordem;
    private StatusFila status;
    private LocalDateTime criadoEm;

    // preenchidos só nas listagens (JOIN) para exibição
    private String nomeCliente;
    private String nomeServico;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public long getClienteId() { return clienteId; }
    public void setClienteId(long clienteId) { this.clienteId = clienteId; }
    public long getServicoId() { return servicoId; }
    public void setServicoId(long servicoId) { this.servicoId = servicoId; }
    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }
    public int getOrdem() { return ordem; }
    public void setOrdem(int ordem) { this.ordem = ordem; }
    public StatusFila getStatus() { return status; }
    public void setStatus(StatusFila status) { this.status = status; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
    public String getNomeServico() { return nomeServico; }
    public void setNomeServico(String nomeServico) { this.nomeServico = nomeServico; }
}
