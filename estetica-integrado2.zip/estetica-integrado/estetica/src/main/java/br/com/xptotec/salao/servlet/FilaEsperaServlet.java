package br.com.xptotec.salao.servlet;

import br.com.xptotec.salao.model.FilaEspera;
import br.com.xptotec.salao.service.FilaEsperaService;
import br.com.xptotec.salao.util.DaoException;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Parametros;
import br.com.xptotec.salao.util.Sessao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Ações sobre a fila de espera (restritas à recepção): chamar próximo, atender, desistir.
 * A entrada na fila acontece pelo RecepcaoServlet (chegada sem reserva / atrasada).
 * A visualização da fila fica no painel da recepção.
 */
@WebServlet("/fila-espera")
public class FilaEsperaServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = Logger.getLogger(FilaEsperaServlet.class.getName());

    private final transient FilaEsperaService filaService = new FilaEsperaService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendRedirect(req.getContextPath() + "/recepcao");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirRecepcao(req, resp)) {
            return;
        }
        String acao = req.getParameter("acao");
        try {
            switch (acao == null ? "" : acao) {
                case "chamar" -> {
                    long servicoId = Parametros.id(req.getParameter("servicoId"));
                    LocalDate data = Parametros.dataOuHoje(req.getParameter("data"));
                    Optional<FilaEspera> chamado = filaService.chamarProximo(servicoId, data);
                    if (chamado.isPresent()) {
                        Sessao.flashOk(req, "Próximo da fila chamado (ordem " + chamado.get().getOrdem() + ").");
                    } else {
                        Sessao.flashErro(req, "Não há ninguém aguardando na fila deste serviço.");
                    }
                }
                case "atender" -> {
                    filaService.marcarAtendido(Parametros.id(req.getParameter("filaId")));
                    Sessao.flashOk(req, "Atendimento da fila registrado.");
                }
                case "desistir" -> {
                    filaService.desistir(Parametros.id(req.getParameter("filaId")));
                    Sessao.flashOk(req, "Cliente removido da fila.");
                }
                default -> Sessao.flashErro(req, "Ação inválida.");
            }
        } catch (NegocioException e) {
            Sessao.flashErro(req, e.getMessage());
        } catch (DaoException e) {
            LOG.log(Level.SEVERE, "Erro na fila de espera", e);
            Sessao.flashErro(req, "Erro interno ao atualizar a fila.");
        }
        resp.sendRedirect(req.getContextPath() + "/recepcao");
    }
}
