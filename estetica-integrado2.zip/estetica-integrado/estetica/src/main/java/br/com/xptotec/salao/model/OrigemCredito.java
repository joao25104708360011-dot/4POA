package br.com.xptotec.salao.model;

public enum OrigemCredito {
    /** Metade devolvida como crédito após falta. */
    FALTA,
    ESTORNO,
    AJUSTE
}
