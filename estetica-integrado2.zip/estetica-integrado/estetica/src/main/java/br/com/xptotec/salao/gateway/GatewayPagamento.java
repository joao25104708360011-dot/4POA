package br.com.xptotec.salao.gateway;

import br.com.xptotec.salao.util.Cartao;
import java.math.BigDecimal;

/**
 * Contrato com a operadora de cartão. Em produção, implemente com o provedor escolhido
 * (e prefira tokenização no navegador para o número do cartão nem passar pelo servidor).
 */
public interface GatewayPagamento {

    ResultadoCobranca cobrar(BigDecimal valor, Cartao cartao);

    final class ResultadoCobranca {
        private final boolean aprovado;
        private final String codigo;
        private final String motivo;

        private ResultadoCobranca(boolean aprovado, String codigo, String motivo) {
            this.aprovado = aprovado;
            this.codigo = codigo;
            this.motivo = motivo;
        }

        public static ResultadoCobranca aprovado(String codigo) {
            return new ResultadoCobranca(true, codigo, null);
        }

        public static ResultadoCobranca recusado(String motivo) {
            return new ResultadoCobranca(false, null, motivo);
        }

        public boolean isAprovado() { return aprovado; }
        public String getCodigo() { return codigo; }
        public String getMotivo() { return motivo; }
    }
}
