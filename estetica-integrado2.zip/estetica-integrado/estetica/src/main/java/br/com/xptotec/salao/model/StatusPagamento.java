package br.com.xptotec.salao.model;

public enum StatusPagamento {
    PENDENTE,
    APROVADO,
    RECUSADO,
    /** Cliente faltou: metade retida, metade virou crédito. */
    RETIDO_PARCIAL,
    ESTORNADO
}
