package br.com.xptotec.salao.service;

import br.com.xptotec.salao.model.FilaEspera;
import java.math.BigDecimal;

/** Resultado do registro de uma falta. */
public class ResultadoFalta {

    private final BigDecimal valorRetido;
    private final BigDecimal creditoGerado;
    private final FilaEspera clienteChamado; // null se a fila estava vazia

    public ResultadoFalta(BigDecimal valorRetido, BigDecimal creditoGerado, FilaEspera clienteChamado) {
        this.valorRetido = valorRetido;
        this.creditoGerado = creditoGerado;
        this.clienteChamado = clienteChamado;
    }

    public BigDecimal getValorRetido() { return valorRetido; }
    public BigDecimal getCreditoGerado() { return creditoGerado; }
    public FilaEspera getClienteChamado() { return clienteChamado; }
}
