package br.com.xptotec.salao.dao;

import br.com.xptotec.salao.model.Pagamento;
import br.com.xptotec.salao.model.StatusPagamento;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

public class PagamentoDAO {

    private final Connection c;

    public PagamentoDAO(Connection c) {
        this.c = c;
    }

    public long inserir(Pagamento p) throws SQLException {
        String sql = "INSERT INTO pagamento (reserva_id, cliente_id, valor, valor_credito, valor_retido, "
                + "bandeira, ultimos4, status, codigo_transacao) VALUES (?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, p.getReservaId());
            ps.setLong(2, p.getClienteId());
            ps.setBigDecimal(3, p.getValor());
            ps.setBigDecimal(4, p.getValorCredito());
            ps.setBigDecimal(5, p.getValorRetido());
            ps.setString(6, p.getBandeira());
            ps.setString(7, p.getUltimos4());
            ps.setString(8, p.getStatus().name());
            ps.setString(9, p.getCodigoTransacao());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                long id = rs.getLong(1);
                p.setId(id);
                return id;
            }
        }
    }

    public Optional<Pagamento> buscarAprovadoPorReserva(long reservaId, boolean paraAtualizar) throws SQLException {
        String sql = "SELECT * FROM pagamento WHERE reserva_id = ? AND status = 'APROVADO'"
                + (paraAtualizar ? " FOR UPDATE" : "");
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, reservaId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
            }
        }
    }

    public void marcarRetidoParcial(long pagamentoId, BigDecimal valorRetido) throws SQLException {
        String sql = "UPDATE pagamento SET status = 'RETIDO_PARCIAL', valor_retido = ? WHERE id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setBigDecimal(1, valorRetido);
            ps.setLong(2, pagamentoId);
            ps.executeUpdate();
        }
    }

    private Pagamento mapear(ResultSet rs) throws SQLException {
        Pagamento p = new Pagamento();
        p.setId(rs.getLong("id"));
        p.setReservaId(rs.getLong("reserva_id"));
        p.setClienteId(rs.getLong("cliente_id"));
        p.setValor(rs.getBigDecimal("valor"));
        p.setValorCredito(rs.getBigDecimal("valor_credito"));
        p.setValorRetido(rs.getBigDecimal("valor_retido"));
        p.setBandeira(rs.getString("bandeira"));
        p.setUltimos4(rs.getString("ultimos4"));
        p.setStatus(StatusPagamento.valueOf(rs.getString("status")));
        p.setCodigoTransacao(rs.getString("codigo_transacao"));
        p.setCriadoEm(rs.getTimestamp("criado_em").toLocalDateTime());
        return p;
    }
}
