package br.com.xptotec.salao.gateway;

import br.com.xptotec.salao.util.Cartao;
import br.com.xptotec.salao.util.CartaoUtil;
import java.math.BigDecimal;
import java.util.UUID;

/**
 * Gateway de teste: aprova tudo, exceto cartões cujo número termina em 0000 (simula recusa).
 * Substituir por integração real antes de ir para produção.
 */
public class GatewaySimulado implements GatewayPagamento {

    @Override
    public ResultadoCobranca cobrar(BigDecimal valor, Cartao cartao) {
        if ("0000".equals(CartaoUtil.ultimos4(cartao.getNumero()))) {
            return ResultadoCobranca.recusado("cartão recusado pela operadora");
        }
        return ResultadoCobranca.aprovado("SIM-" + UUID.randomUUID());
    }
}
