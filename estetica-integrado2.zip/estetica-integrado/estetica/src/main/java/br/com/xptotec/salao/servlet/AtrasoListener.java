package br.com.xptotec.salao.servlet;

import br.com.xptotec.salao.service.RecepcaoService;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A cada minuto libera as vagas de reservas com mais de 15 minutos de atraso e chama o próximo da fila.
 * (A regra em si está em RecepcaoService.liberarVagasAtrasadas.)
 */
@WebListener
public class AtrasoListener implements ServletContextListener {

    private static final Logger LOG = Logger.getLogger(AtrasoListener.class.getName());

    private ScheduledExecutorService executor;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        RecepcaoService service = new RecepcaoService();
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "liberar-vagas-atrasadas");
            t.setDaemon(true);
            return t;
        });
        executor.scheduleWithFixedDelay(() -> {
            try {
                int n = service.liberarVagasAtrasadas();
                if (n > 0) {
                    LOG.info(n + " vaga(s) liberada(s) por atraso.");
                }
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Falha na rotina de atrasos", e);
            }
        }, 1, 1, TimeUnit.MINUTES);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (executor != null) {
            executor.shutdownNow();
        }
    }
}
