package br.com.xptotec.salao.service;

import br.com.xptotec.salao.integracao.ReservaResumo;
import br.com.xptotec.salao.model.FilaEspera;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Dados do painel da recepção: chegadas, faltas e fila. */
public class PainelRecepcao {

    private LocalDate data;
    private List<ReservaResumo> pendentes = new ArrayList<>();   // confirmadas, ainda sem presença
    private List<ReservaResumo> chegadas = new ArrayList<>();    // presença marcada
    private List<ReservaResumo> atrasos = new ArrayList<>();     // vaga liberada por atraso
    private List<ReservaResumo> faltas = new ArrayList<>();
    private List<FilaEspera> fila = new ArrayList<>();

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }
    public List<ReservaResumo> getPendentes() { return pendentes; }
    public List<ReservaResumo> getChegadas() { return chegadas; }
    public List<ReservaResumo> getAtrasos() { return atrasos; }
    public List<ReservaResumo> getFaltas() { return faltas; }
    public List<FilaEspera> getFila() { return fila; }
    public void setFila(List<FilaEspera> fila) { this.fila = fila; }
}
