package br.com.xptotec.salao.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Crédito do cliente (cliente, valor, origem, saldo). Cada linha é um "lote" consumido em ordem FIFO. */
public class CreditoCliente {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private Long id;
    private long clienteId;
    private BigDecimal valor;
    private OrigemCredito origem;
    private BigDecimal saldo;
    private Long reservaId;
    private LocalDateTime criadoEm;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public long getClienteId() { return clienteId; }
    public void setClienteId(long clienteId) { this.clienteId = clienteId; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public OrigemCredito getOrigem() { return origem; }
    public void setOrigem(OrigemCredito origem) { this.origem = origem; }
    public BigDecimal getSaldo() { return saldo; }
    public void setSaldo(BigDecimal saldo) { this.saldo = saldo; }
    public Long getReservaId() { return reservaId; }
    public void setReservaId(Long reservaId) { this.reservaId = reservaId; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }

    public String getCriadoEmFormatado() {
        return criadoEm == null ? "" : criadoEm.format(FMT);
    }
}
