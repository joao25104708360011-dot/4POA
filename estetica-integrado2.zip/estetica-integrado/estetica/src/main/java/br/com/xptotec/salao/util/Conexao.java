package br.com.xptotec.salao.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Fábrica de conexões da Parte 4.
 *
 * INTEGRAÇÃO: se a Parte 1 já tiver uma ConnectionFactory/DataSource, troque o corpo de
 * {@link #get()} para delegar a ela. O resto da Parte 4 só depende deste método.
 */
public final class Conexao {

    private static final String URL = env("DB_URL",
            "jdbc:mysql://localhost:3306/salao?serverTimezone=America/Sao_Paulo");
    private static final String USER = env("DB_USER", "root");
    private static final String PASS = env("DB_PASS", "");

    private Conexao() {
    }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    private static String env(String chave, String padrao) {
        String v = System.getenv(chave);
        return (v == null || v.isBlank()) ? padrao : v;
    }
}
