package br.com.xptotec.salao.dao;

import br.com.xptotec.salao.model.CreditoCliente;
import br.com.xptotec.salao.model.OrigemCredito;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CreditoClienteDAO {

    private final Connection c;

    public CreditoClienteDAO(Connection c) {
        this.c = c;
    }

    public long inserir(CreditoCliente cr) throws SQLException {
        String sql = "INSERT INTO credito_cliente (cliente_id, valor, origem, saldo, reserva_id) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, cr.getClienteId());
            ps.setBigDecimal(2, cr.getValor());
            ps.setString(3, cr.getOrigem().name());
            ps.setBigDecimal(4, cr.getSaldo());
            if (cr.getReservaId() == null) {
                ps.setNull(5, java.sql.Types.BIGINT);
            } else {
                ps.setLong(5, cr.getReservaId());
            }
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                long id = rs.getLong(1);
                cr.setId(id);
                return id;
            }
        }
    }

    public List<CreditoCliente> listarPorCliente(long clienteId) throws SQLException {
        return consultar("SELECT * FROM credito_cliente WHERE cliente_id = ? ORDER BY criado_em DESC, id DESC",
                clienteId);
    }

    /** Lotes com saldo, do mais antigo ao mais novo, travados para consumo (FIFO). */
    public List<CreditoCliente> listarComSaldoParaConsumo(long clienteId) throws SQLException {
        return consultar("SELECT * FROM credito_cliente WHERE cliente_id = ? AND saldo > 0 "
                + "ORDER BY criado_em, id FOR UPDATE", clienteId);
    }

    public BigDecimal saldoTotal(long clienteId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(saldo), 0) FROM credito_cliente WHERE cliente_id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, clienteId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getBigDecimal(1);
            }
        }
    }

    public void atualizarSaldo(long id, BigDecimal novoSaldo) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE credito_cliente SET saldo = ? WHERE id = ?")) {
            ps.setBigDecimal(1, novoSaldo);
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    private List<CreditoCliente> consultar(String sql, long clienteId) throws SQLException {
        List<CreditoCliente> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, clienteId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(mapear(rs));
                }
            }
        }
        return out;
    }

    private CreditoCliente mapear(ResultSet rs) throws SQLException {
        CreditoCliente cr = new CreditoCliente();
        cr.setId(rs.getLong("id"));
        cr.setClienteId(rs.getLong("cliente_id"));
        cr.setValor(rs.getBigDecimal("valor"));
        cr.setOrigem(OrigemCredito.valueOf(rs.getString("origem")));
        cr.setSaldo(rs.getBigDecimal("saldo"));
        long reserva = rs.getLong("reserva_id");
        cr.setReservaId(rs.wasNull() ? null : reserva);
        cr.setCriadoEm(rs.getTimestamp("criado_em").toLocalDateTime());
        return cr;
    }
}
