package br.com.xptotec.salao.model;

public enum StatusFila {
    AGUARDANDO,
    CHAMADO,
    ATENDIDO,
    DESISTIU
}
