package br.com.xptotec.salao.service;

import br.com.xptotec.salao.dao.PagamentoDAO;
import br.com.xptotec.salao.gateway.GatewayPagamento;
import br.com.xptotec.salao.gateway.GatewayPagamento.ResultadoCobranca;
import br.com.xptotec.salao.gateway.GatewaySimulado;
import br.com.xptotec.salao.integracao.ReservaIntegracaoDAO;
import br.com.xptotec.salao.integracao.ReservaResumo;
import br.com.xptotec.salao.integracao.StatusReserva;
import br.com.xptotec.salao.model.Pagamento;
import br.com.xptotec.salao.model.StatusPagamento;
import br.com.xptotec.salao.util.Cartao;
import br.com.xptotec.salao.util.CartaoUtil;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Transacao;
import java.math.BigDecimal;

/**
 * Cobra a reserva. Pagamento exclusivamente por cartão de crédito (o cliente pode abater o crédito
 * que já possui). Guarda apenas bandeira e últimos 4 dígitos.
 */
public class PagamentoService {

    private final GatewayPagamento gateway;
    private final CreditoService creditoService;

    public PagamentoService() {
        this(new GatewaySimulado(), new CreditoService());
    }

    public PagamentoService(GatewayPagamento gateway, CreditoService creditoService) {
        this.gateway = gateway;
        this.creditoService = creditoService;
    }

    /** Reserva do próprio cliente (para montar a tela de pagamento). */
    public ReservaResumo consultarReserva(long reservaId, long clienteId) {
        return Transacao.executar(c -> {
            ReservaResumo r = new ReservaIntegracaoDAO(c).buscar(reservaId, false)
                    .orElseThrow(() -> new NegocioException("Reserva não encontrada."));
            if (r.getClienteId() != clienteId) {
                throw new NegocioException("Reserva não encontrada."); // não revela reservas de terceiros
            }
            return r;
        });
    }

    /**
     * Cobra a reserva (AGUARDANDO_PAGAMENTO -> CONFIRMADA). Tudo na mesma transação: se o cartão for
     * recusado, o crédito eventualmente consumido volta automaticamente (rollback).
     */
    public Pagamento pagarReserva(long reservaId, long clienteId, Cartao cartao, boolean usarCredito) {
        return Transacao.executar(c -> {
            ReservaIntegracaoDAO reservaDao = new ReservaIntegracaoDAO(c);
            PagamentoDAO pagamentoDao = new PagamentoDAO(c);

            ReservaResumo reserva = reservaDao.buscar(reservaId, true)
                    .orElseThrow(() -> new NegocioException("Reserva não encontrada."));
            if (reserva.getClienteId() != clienteId) {
                throw new NegocioException("Reserva não encontrada.");
            }
            if (!reserva.is(StatusReserva.AGUARDANDO_PAGAMENTO)
                    || pagamentoDao.buscarAprovadoPorReserva(reservaId, false).isPresent()) {
                throw new NegocioException("Esta reserva não está aguardando pagamento.");
            }

            BigDecimal valor = reserva.getValor();
            BigDecimal usadoDoCredito = BigDecimal.ZERO;
            if (usarCredito) {
                BigDecimal saldo = creditoService.saldoTotal(c, clienteId);
                usadoDoCredito = saldo.min(valor);
                if (usadoDoCredito.signum() > 0) {
                    creditoService.consumir(c, clienteId, usadoDoCredito);
                }
            }
            BigDecimal noCartao = valor.subtract(usadoDoCredito);

            Pagamento p = new Pagamento();
            p.setReservaId(reservaId);
            p.setClienteId(clienteId);
            p.setValor(valor);
            p.setValorCredito(usadoDoCredito);
            p.setStatus(StatusPagamento.APROVADO);

            if (noCartao.signum() > 0) {
                validarCartao(cartao);
                ResultadoCobranca res = gateway.cobrar(noCartao, cartao);
                if (!res.isAprovado()) {
                    throw new NegocioException("Pagamento recusado: " + res.getMotivo() + ".");
                }
                p.setBandeira(CartaoUtil.bandeira(cartao.getNumero()));
                p.setUltimos4(CartaoUtil.ultimos4(cartao.getNumero()));
                p.setCodigoTransacao(res.getCodigo());
            } else {
                p.setCodigoTransacao("CREDITO-" + reservaId); // quitado só com crédito, sem cobrança no cartão
            }

            pagamentoDao.inserir(p);
            reservaDao.atualizarStatus(reservaId, StatusReserva.CONFIRMADA);
            return p;
        });
    }

    private void validarCartao(Cartao cartao) {
        if (cartao == null || cartao.getNome().isBlank()) {
            throw new NegocioException("Informe o nome impresso no cartão.");
        }
        if (!CartaoUtil.numeroValido(cartao.getNumero())) {
            throw new NegocioException("Número de cartão inválido.");
        }
        if (!CartaoUtil.validadeValida(cartao.getValidade())) {
            throw new NegocioException("Validade inválida ou vencida (use MM/AA).");
        }
        String bandeira = CartaoUtil.bandeira(cartao.getNumero());
        if (!CartaoUtil.cvvValido(cartao.getCvv(), bandeira)) {
            throw new NegocioException("Código de segurança (CVV) inválido.");
        }
    }
}
