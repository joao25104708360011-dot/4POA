package br.com.xptotec.salao.util;

import java.time.YearMonth;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Validações e identificação de bandeira. Só guardamos bandeira + últimos 4 dígitos. */
public final class CartaoUtil {

    private static final Pattern VALIDADE = Pattern.compile("^(\\d{2})/(\\d{2})$");

    private CartaoUtil() {
    }

    public static String digitos(String s) {
        return s == null ? "" : s.replaceAll("\\D", "");
    }

    /** Algoritmo de Luhn + tamanho 13..19. */
    public static boolean numeroValido(String numero) {
        String n = digitos(numero);
        if (n.length() < 13 || n.length() > 19) {
            return false;
        }
        int soma = 0;
        boolean dobrar = false;
        for (int i = n.length() - 1; i >= 0; i--) {
            int d = n.charAt(i) - '0';
            if (dobrar) {
                d *= 2;
                if (d > 9) {
                    d -= 9;
                }
            }
            soma += d;
            dobrar = !dobrar;
        }
        return soma % 10 == 0;
    }

    /** Formato MM/AA e não vencido (vale até o fim do mês de validade). */
    public static boolean validadeValida(String validade) {
        if (validade == null) {
            return false;
        }
        Matcher m = VALIDADE.matcher(validade.trim());
        if (!m.matches()) {
            return false;
        }
        int mes = Integer.parseInt(m.group(1));
        int ano = 2000 + Integer.parseInt(m.group(2));
        if (mes < 1 || mes > 12) {
            return false;
        }
        return !YearMonth.of(ano, mes).isBefore(YearMonth.now());
    }

    public static boolean cvvValido(String cvv, String bandeira) {
        String c = digitos(cvv);
        return "AMEX".equals(bandeira) ? c.length() == 4 : c.length() == 3;
    }

    public static String bandeira(String numero) {
        String n = digitos(numero);
        if (n.matches("^(636368|438935|504175|451416|636297|506699|5067\\d{2}|4576\\d{2}|4011\\d{2}).*")) {
            return "ELO";
        }
        if (n.matches("^(606282|3841).*")) {
            return "HIPERCARD";
        }
        if (n.matches("^3[47].*")) {
            return "AMEX";
        }
        if (n.matches("^(36|38|30[0-5]).*")) {
            return "DINERS";
        }
        if (n.startsWith("4")) {
            return "VISA";
        }
        if (n.matches("^(5[1-5]|222[1-9]|22[3-9]\\d|2[3-6]\\d{2}|27[01]\\d|2720).*")) {
            return "MASTERCARD";
        }
        return "OUTRA";
    }

    public static String ultimos4(String numero) {
        String n = digitos(numero);
        return n.length() <= 4 ? n : n.substring(n.length() - 4);
    }
}
