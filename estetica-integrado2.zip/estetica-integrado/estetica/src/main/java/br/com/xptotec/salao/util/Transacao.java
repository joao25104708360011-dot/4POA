package br.com.xptotec.salao.util;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Executa um bloco de trabalho em uma única transação (commit no sucesso, rollback em qualquer erro).
 * Os services usam isto para que, por exemplo, "registrar falta + gerar crédito + chamar a fila"
 * aconteçam de forma atômica.
 */
public final class Transacao {

    @FunctionalInterface
    public interface Trabalho<T> {
        T executar(Connection c) throws Exception;
    }

    private Transacao() {
    }

    public static <T> T executar(Trabalho<T> trabalho) {
        try (Connection c = Conexao.get()) {
            c.setAutoCommit(false);
            try {
                T resultado = trabalho.executar(c);
                c.commit();
                return resultado;
            } catch (Exception e) {
                try {
                    c.rollback();
                } catch (SQLException ignorada) {
                    // já estamos tratando um erro maior
                }
                if (e instanceof RuntimeException re) {
                    throw re;
                }
                throw new DaoException("Erro de acesso a dados", e);
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao abrir/fechar conexão", e);
        }
    }
}
