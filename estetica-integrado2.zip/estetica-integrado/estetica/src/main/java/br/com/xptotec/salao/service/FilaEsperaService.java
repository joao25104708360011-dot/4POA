package br.com.xptotec.salao.service;

import br.com.xptotec.salao.dao.FilaEsperaDAO;
import br.com.xptotec.salao.integracao.ReservaIntegracaoDAO;
import br.com.xptotec.salao.model.FilaEspera;
import br.com.xptotec.salao.model.StatusFila;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Transacao;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Fila de espera:
 *  - o cliente ENTRA quando chega sem reserva ou atrasado e não há horário livre;
 *  - o próximo é CHAMADO quando alguém falta ou passa de 15 minutos de atraso.
 */
public class FilaEsperaService {

    // ---- entrada na fila ----

    /**
     * Cliente chegou sem reserva (ou atrasado): se houver horário livre hoje, orienta a marcar;
     * caso contrário entra na fila.
     */
    public ResultadoChegada registrarChegada(Connection c, long clienteId, long servicoId, LocalDateTime agora)
            throws SQLException {
        Optional<LocalDateTime> livre = new ReservaIntegracaoDAO(c).proximoHorarioLivreHoje(servicoId, agora);
        if (livre.isPresent()) {
            return ResultadoChegada.horarioDisponivel(livre.get());
        }
        FilaEspera f = entrarNaFila(c, clienteId, servicoId, agora.toLocalDate());
        return ResultadoChegada.naFila(new FilaEsperaDAO(c).posicao(f));
    }

    public FilaEspera entrarNaFila(Connection c, long clienteId, long servicoId, LocalDate data)
            throws SQLException {
        FilaEsperaDAO dao = new FilaEsperaDAO(c);
        if (dao.existeAtivo(clienteId, servicoId, data)) {
            throw new NegocioException("O cliente já está na fila de espera deste serviço hoje.");
        }
        return dao.inserirNoFim(clienteId, servicoId, data);
    }

    // ---- chamada ----

    /**
     * Chama o primeiro da fila do serviço/dia (AGUARDANDO -> CHAMADO).
     * Usado quando alguém falta ou passa de 15 minutos de atraso. Vazio se não há ninguém esperando.
     */
    public Optional<FilaEspera> chamarProximo(Connection c, long servicoId, LocalDate data) throws SQLException {
        FilaEsperaDAO dao = new FilaEsperaDAO(c);
        Optional<FilaEspera> proximo = dao.buscarProximoAguardando(servicoId, data);
        if (proximo.isPresent()) {
            dao.atualizarStatus(proximo.get().getId(), StatusFila.CHAMADO);
            proximo.get().setStatus(StatusFila.CHAMADO);
        }
        return proximo;
    }

    /** Chamada manual pela recepção (ex.: o chamado anterior desistiu). */
    public Optional<FilaEspera> chamarProximo(long servicoId, LocalDate data) {
        return Transacao.executar(c -> chamarProximo(c, servicoId, data));
    }

    // ---- desfechos ----

    public void marcarAtendido(long filaId) {
        Transacao.executar(c -> {
            FilaEsperaDAO dao = new FilaEsperaDAO(c);
            FilaEspera f = dao.buscarPorId(filaId, true)
                    .orElseThrow(() -> new NegocioException("Item da fila não encontrado."));
            if (f.getStatus() != StatusFila.CHAMADO && f.getStatus() != StatusFila.AGUARDANDO) {
                throw new NegocioException("Este item da fila já foi finalizado.");
            }
            dao.atualizarStatus(filaId, StatusFila.ATENDIDO);
            return null;
        });
    }

    public void desistir(long filaId) {
        Transacao.executar(c -> {
            FilaEsperaDAO dao = new FilaEsperaDAO(c);
            FilaEspera f = dao.buscarPorId(filaId, true)
                    .orElseThrow(() -> new NegocioException("Item da fila não encontrado."));
            if (f.getStatus() != StatusFila.CHAMADO && f.getStatus() != StatusFila.AGUARDANDO) {
                throw new NegocioException("Este item da fila já foi finalizado.");
            }
            dao.atualizarStatus(filaId, StatusFila.DESISTIU);
            return null;
        });
    }

    // ---- consultas ----

    public List<FilaEspera> listarDoDia(LocalDate data) {
        return Transacao.executar(c -> new FilaEsperaDAO(c).listarAtivosDoDia(data));
    }
}
