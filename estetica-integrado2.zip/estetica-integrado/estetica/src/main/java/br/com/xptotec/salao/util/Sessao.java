package br.com.xptotec.salao.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Ponte com a autenticação da Parte 1.
 *
 * INTEGRAÇÃO: ajuste as constantes abaixo para os nomes que a Parte 1 realmente grava na sessão
 * (ou, se ela tiver um filtro de autorização, remova os métodos exigir*). Perfis assumidos:
 * CLIENTE, RECEPCIONISTA, ADMIN.
 */
public final class Sessao {

    public static final String ATTR_USUARIO_ID = "usuarioId";
    public static final String ATTR_PERFIL = "usuarioPerfil";
    public static final String URL_LOGIN = "/login.jsp";

    private static final String FLASH_OK = "flashOk";
    private static final String FLASH_ERRO = "flashErro";

    private Sessao() {
    }

    public static Long usuarioId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) {
            return null;
        }
        Object v = s.getAttribute(ATTR_USUARIO_ID);
        return v instanceof Number n ? Long.valueOf(n.longValue()) : null;
    }

    public static boolean ehRecepcao(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        Object p = s == null ? null : s.getAttribute(ATTR_PERFIL);
        return "RECEPCAO".equals(p) || "RECEPCIONISTA".equals(p) || "ADMIN".equals(p);
    }

    /** @return true se pode continuar; false se já respondeu (redirect para login). */
    public static boolean exigirLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (usuarioId(req) == null) {
            resp.sendRedirect(req.getContextPath() + URL_LOGIN);
            return false;
        }
        return true;
    }

    /** @return true se pode continuar; false se já respondeu (login ou 403). */
    public static boolean exigirRecepcao(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // A recepção não é um Cliente, então não tem "usuarioId" na sessão: o que vale é o perfil.
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute(ATTR_PERFIL) == null) {
            resp.sendRedirect(req.getContextPath() + URL_LOGIN);
            return false;
        }
        if (!ehRecepcao(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Acesso restrito à recepção.");
            return false;
        }
        return true;
    }

    // ---- mensagens de uma só exibição (Post/Redirect/Get) ----

    public static void flashOk(HttpServletRequest req, String msg) {
        req.getSession().setAttribute(FLASH_OK, msg);
    }

    public static void flashErro(HttpServletRequest req, String msg) {
        req.getSession().setAttribute(FLASH_ERRO, msg);
    }

    /** Move as mensagens da sessão para o request (e as remove da sessão). */
    public static void transferirFlash(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) {
            return;
        }
        for (String k : new String[] {FLASH_OK, FLASH_ERRO}) {
            Object v = s.getAttribute(k);
            if (v != null) {
                req.setAttribute(k, v);
                s.removeAttribute(k);
            }
        }
    }
}
