package br.com.xptotec.salao.util;

/** Violação de regra de negócio; a mensagem pode ser exibida ao usuário. */
public class NegocioException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public NegocioException(String mensagem) {
        super(mensagem);
    }
}
