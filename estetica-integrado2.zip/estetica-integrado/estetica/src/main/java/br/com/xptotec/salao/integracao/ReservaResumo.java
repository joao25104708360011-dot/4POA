package br.com.xptotec.salao.integracao;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Visão mínima da reserva (Parte 3) de que a Parte 4 precisa. */
public class ReservaResumo {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private long id;
    private long clienteId;
    private long servicoId;
    private LocalDateTime inicio;
    private BigDecimal valor;
    private String status;
    private String nomeCliente;
    private String nomeServico;

    public boolean is(StatusReserva s) {
        return s.name().equals(status);
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getClienteId() { return clienteId; }
    public void setClienteId(long clienteId) { this.clienteId = clienteId; }
    public long getServicoId() { return servicoId; }
    public void setServicoId(long servicoId) { this.servicoId = servicoId; }
    public LocalDateTime getInicio() { return inicio; }
    public void setInicio(LocalDateTime inicio) { this.inicio = inicio; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
    public String getNomeServico() { return nomeServico; }
    public void setNomeServico(String nomeServico) { this.nomeServico = nomeServico; }

    public String getInicioFormatado() {
        return inicio == null ? "" : inicio.format(FMT);
    }
}
