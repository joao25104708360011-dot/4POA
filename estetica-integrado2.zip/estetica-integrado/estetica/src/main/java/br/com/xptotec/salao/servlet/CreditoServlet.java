package br.com.xptotec.salao.servlet;

import br.com.xptotec.salao.service.CreditoService;
import br.com.xptotec.salao.util.Sessao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** "Meu crédito": saldo e histórico do cliente logado. */
@WebServlet("/meu-credito")
public class CreditoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final transient CreditoService creditoService = new CreditoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirLogin(req, resp)) {
            return;
        }
        long clienteId = Sessao.usuarioId(req);
        req.setAttribute("saldoTotal", creditoService.saldoTotal(clienteId));
        req.setAttribute("creditos", creditoService.listar(clienteId));
        req.getRequestDispatcher("/WEB-INF/jsp/meu-credito.jsp").forward(req, resp);
    }
}
