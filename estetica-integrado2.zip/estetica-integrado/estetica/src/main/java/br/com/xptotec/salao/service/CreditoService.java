package br.com.xptotec.salao.service;

import br.com.xptotec.salao.dao.CreditoClienteDAO;
import br.com.xptotec.salao.model.CreditoCliente;
import br.com.xptotec.salao.model.OrigemCredito;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Transacao;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/** Crédito do cliente: gerado na falta (metade do valor) e consumido em pagamentos futuros (FIFO). */
public class CreditoService {

    // ---- consultas (abrem a própria transação) ----

    public BigDecimal saldoTotal(long clienteId) {
        return Transacao.executar(c -> saldoTotal(c, clienteId));
    }

    public List<CreditoCliente> listar(long clienteId) {
        return Transacao.executar(c -> new CreditoClienteDAO(c).listarPorCliente(clienteId));
    }

    // ---- operações que participam de uma transação maior ----

    public BigDecimal saldoTotal(Connection c, long clienteId) throws SQLException {
        return new CreditoClienteDAO(c).saldoTotal(clienteId);
    }

    public CreditoCliente gerar(Connection c, long clienteId, BigDecimal valor, OrigemCredito origem,
            Long reservaId) throws SQLException {
        if (valor == null || valor.signum() <= 0) {
            throw new NegocioException("O valor do crédito deve ser positivo.");
        }
        CreditoCliente cr = new CreditoCliente();
        cr.setClienteId(clienteId);
        cr.setValor(valor);
        cr.setSaldo(valor);
        cr.setOrigem(origem);
        cr.setReservaId(reservaId);
        new CreditoClienteDAO(c).inserir(cr);
        return cr;
    }

    /** Consome {@code valor} dos lotes mais antigos primeiro. Falha se o saldo for insuficiente. */
    public void consumir(Connection c, long clienteId, BigDecimal valor) throws SQLException {
        if (valor == null || valor.signum() <= 0) {
            throw new NegocioException("O valor a consumir deve ser positivo.");
        }
        CreditoClienteDAO dao = new CreditoClienteDAO(c);
        BigDecimal restante = valor;
        for (CreditoCliente lote : dao.listarComSaldoParaConsumo(clienteId)) {
            if (restante.signum() == 0) {
                break;
            }
            BigDecimal usar = lote.getSaldo().min(restante);
            dao.atualizarSaldo(lote.getId(), lote.getSaldo().subtract(usar));
            restante = restante.subtract(usar);
        }
        if (restante.signum() > 0) {
            throw new NegocioException("Saldo de crédito insuficiente.");
        }
    }
}
