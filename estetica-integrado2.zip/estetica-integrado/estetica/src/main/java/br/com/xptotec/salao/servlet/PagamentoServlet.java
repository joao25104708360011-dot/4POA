package br.com.xptotec.salao.servlet;

import br.com.xptotec.salao.integracao.ReservaResumo;
import br.com.xptotec.salao.service.CreditoService;
import br.com.xptotec.salao.service.PagamentoService;
import br.com.xptotec.salao.util.Cartao;
import br.com.xptotec.salao.util.DaoException;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Parametros;
import br.com.xptotec.salao.util.Sessao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Tela de pagamento da reserva (somente cartão de crédito). Use SEMPRE por HTTPS. */
@WebServlet("/pagamento")
public class PagamentoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = Logger.getLogger(PagamentoServlet.class.getName());
    private static final String VIEW = "/WEB-INF/jsp/pagamento.jsp";

    private final transient PagamentoService pagamentoService = new PagamentoService();
    private final transient CreditoService creditoService = new CreditoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirLogin(req, resp)) {
            return;
        }
        Sessao.transferirFlash(req);
        exibir(req, resp, null);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirLogin(req, resp)) {
            return;
        }
        try {
            long reservaId = Parametros.id(req.getParameter("reservaId"));
            Cartao cartao = new Cartao(req.getParameter("numero"), req.getParameter("nome"),
                    req.getParameter("validade"), req.getParameter("cvv"));
            boolean usarCredito = "on".equals(req.getParameter("usarCredito"));

            pagamentoService.pagarReserva(reservaId, Sessao.usuarioId(req), cartao, usarCredito);

            Sessao.flashOk(req, "Pagamento aprovado! Sua reserva está confirmada.");
            resp.sendRedirect(req.getContextPath() + "/pagamento?reservaId=" + reservaId);
        } catch (NegocioException e) {
            exibir(req, resp, e.getMessage());
        } catch (DaoException e) {
            LOG.log(Level.SEVERE, "Erro ao processar pagamento", e); // nunca logar dados do cartão
            exibir(req, resp, "Não foi possível processar o pagamento agora. Tente novamente.");
        }
    }

    private void exibir(HttpServletRequest req, HttpServletResponse resp, String erro)
            throws ServletException, IOException {
        long clienteId = Sessao.usuarioId(req);
        try {
            long reservaId = Parametros.id(req.getParameter("reservaId"));
            ReservaResumo reserva = pagamentoService.consultarReserva(reservaId, clienteId);
            req.setAttribute("reserva", reserva);
            req.setAttribute("saldoCredito", creditoService.saldoTotal(clienteId));
        } catch (NegocioException e) {
            erro = erro == null ? e.getMessage() : erro;
        }
        if (erro != null) {
            req.setAttribute("flashErro", erro);
        }
        // o número do cartão e o CVV nunca voltam para a página
        req.setAttribute("nomeCartao", req.getParameter("nome"));
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
