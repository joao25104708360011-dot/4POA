package br.com.xptotec.salao.integracao;

/**
 * Status de reserva usados/gravados pela Parte 4.
 * INTEGRAÇÃO: alinhar os nomes com a Parte 3 (Agenda e reserva). A coluna reserva.status é texto.
 */
public enum StatusReserva {
    AGUARDANDO_PAGAMENTO,
    CONFIRMADA,
    /** Cliente chegou no prazo e foi marcado na recepção. */
    PRESENTE,
    /** Passou de 15 min de atraso: vaga liberada para a fila de espera. */
    ATRASO_LIBERADO,
    FALTA,
    CONCLUIDA,
    CANCELADA
}
