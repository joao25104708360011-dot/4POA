package br.com.xptotec.salao.servlet;

import br.com.xptotec.salao.service.PainelRecepcao;
import br.com.xptotec.salao.service.RecepcaoService;
import br.com.xptotec.salao.service.ResultadoChegada;
import br.com.xptotec.salao.service.ResultadoFalta;
import br.com.xptotec.salao.util.DaoException;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Parametros;
import br.com.xptotec.salao.util.Sessao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Painel da recepção: chegadas, faltas, fila; marcar presença, falta e atendimento sem reserva. */
@WebServlet("/recepcao")
public class RecepcaoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = Logger.getLogger(RecepcaoServlet.class.getName());
    private static final Locale PT_BR = Locale.of("pt", "BR");

    private final transient RecepcaoService recepcaoService = new RecepcaoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirRecepcao(req, resp)) {
            return;
        }
        Sessao.transferirFlash(req);
        try {
            LocalDate dia = Parametros.dataOuHoje(req.getParameter("data"));
            recepcaoService.liberarVagasAtrasadas(); // garante o painel em dia mesmo sem o agendador
            PainelRecepcao painel = recepcaoService.painel(dia);
            req.setAttribute("painel", painel);
            req.setAttribute("dataIso", dia.toString());
        } catch (NegocioException e) {
            req.setAttribute("flashErro", e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/jsp/recepcao.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sessao.exigirRecepcao(req, resp)) {
            return;
        }
        String acao = req.getParameter("acao");
        try {
            switch (acao == null ? "" : acao) {
                case "presenca" -> {
                    ResultadoChegada r = recepcaoService.marcarPresenca(Parametros.id(req.getParameter("reservaId")));
                    Sessao.flashOk(req, r.getMensagem());
                }
                case "falta" -> {
                    ResultadoFalta f = recepcaoService.marcarFalta(Parametros.id(req.getParameter("reservaId")));
                    NumberFormat moeda = NumberFormat.getCurrencyInstance(PT_BR);
                    String msg = "Falta registrada. Retido: " + moeda.format(f.getValorRetido())
                            + " | Crédito gerado: " + moeda.format(f.getCreditoGerado()) + ".";
                    if (f.getClienteChamado() != null) {
                        msg += " Próximo da fila chamado (ordem " + f.getClienteChamado().getOrdem() + ").";
                    }
                    Sessao.flashOk(req, msg);
                }
                case "sem-reserva" -> {
                    ResultadoChegada r = recepcaoService.atenderSemReserva(
                            Parametros.id(req.getParameter("clienteId")),
                            Parametros.id(req.getParameter("servicoId")));
                    Sessao.flashOk(req, r.getMensagem());
                }
                default -> Sessao.flashErro(req, "Ação inválida.");
            }
        } catch (NegocioException e) {
            Sessao.flashErro(req, e.getMessage());
        } catch (DaoException e) {
            LOG.log(Level.SEVERE, "Erro na recepção", e);
            Sessao.flashErro(req, "Erro interno ao processar a operação.");
        }
        resp.sendRedirect(req.getContextPath() + "/recepcao");
    }
}
