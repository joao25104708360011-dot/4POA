package br.com.xptotec.salao.service;

import br.com.xptotec.salao.dao.PagamentoDAO;
import br.com.xptotec.salao.integracao.ReservaIntegracaoDAO;
import br.com.xptotec.salao.integracao.ReservaResumo;
import br.com.xptotec.salao.integracao.StatusReserva;
import br.com.xptotec.salao.model.FilaEspera;
import br.com.xptotec.salao.model.OrigemCredito;
import br.com.xptotec.salao.model.Pagamento;
import br.com.xptotec.salao.util.NegocioException;
import br.com.xptotec.salao.util.Regras;
import br.com.xptotec.salao.util.Transacao;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Regra de não comparecimento: o cliente PERDE METADE do valor da reserva e a outra metade vira
 * CRÉDITO. A vaga é oferecida ao primeiro da fila de espera.
 */
public class FaltaService {

    private final CreditoService creditoService;
    private final FilaEsperaService filaService;

    public FaltaService() {
        this(new CreditoService(), new FilaEsperaService());
    }

    public FaltaService(CreditoService creditoService, FilaEsperaService filaService) {
        this.creditoService = creditoService;
        this.filaService = filaService;
    }

    public ResultadoFalta registrarFalta(long reservaId) {
        return Transacao.executar(c -> registrarFalta(c, reservaId));
    }

    ResultadoFalta registrarFalta(Connection c, long reservaId) throws SQLException {
        ReservaIntegracaoDAO reservaDao = new ReservaIntegracaoDAO(c);
        PagamentoDAO pagamentoDao = new PagamentoDAO(c);

        ReservaResumo reserva = reservaDao.buscar(reservaId, true)
                .orElseThrow(() -> new NegocioException("Reserva não encontrada."));

        // Só vale falta para quem está confirmado (ou teve a vaga liberada por atraso) e não compareceu.
        if (!reserva.is(StatusReserva.CONFIRMADA) && !reserva.is(StatusReserva.ATRASO_LIBERADO)) {
            throw new NegocioException("Não é possível registrar falta: reserva com status "
                    + reserva.getStatus() + ".");
        }

        Pagamento pagamento = pagamentoDao.buscarAprovadoPorReserva(reservaId, true)
                .orElseThrow(() -> new NegocioException("Reserva sem pagamento aprovado."));

        BigDecimal retido = Regras.valorRetidoNaFalta(pagamento.getValor());
        BigDecimal credito = pagamento.getValor().subtract(retido); // evita perder centavo no arredondamento

        pagamentoDao.marcarRetidoParcial(pagamento.getId(), retido);
        if (credito.signum() > 0) {
            creditoService.gerar(c, reserva.getClienteId(), credito, OrigemCredito.FALTA, reservaId);
        }
        reservaDao.atualizarStatus(reservaId, StatusReserva.FALTA);

        // Se a vaga já tinha sido liberada por atraso, o próximo da fila já foi chamado naquele momento.
        FilaEspera chamado = null;
        if (reserva.is(StatusReserva.CONFIRMADA)) {
            chamado = filaService.chamarProximo(c, reserva.getServicoId(), reserva.getInicio().toLocalDate())
                    .orElse(null);
        }
        return new ResultadoFalta(retido, credito, chamado);
    }
}
