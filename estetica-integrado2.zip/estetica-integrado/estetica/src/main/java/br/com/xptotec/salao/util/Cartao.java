package br.com.xptotec.salao.util;

/**
 * Dados do cartão, usados APENAS em memória durante a cobrança.
 * Nunca persistir, nunca logar. O toString é mascarado de propósito.
 */
public final class Cartao {

    private final String numero;
    private final String nome;
    private final String validade; // MM/AA
    private final String cvv;

    public Cartao(String numero, String nome, String validade, String cvv) {
        this.numero = CartaoUtil.digitos(numero);
        this.nome = nome == null ? "" : nome.trim();
        this.validade = validade == null ? "" : validade.trim();
        this.cvv = CartaoUtil.digitos(cvv);
    }

    public String getNumero() {
        return numero;
    }

    public String getNome() {
        return nome;
    }

    public String getValidade() {
        return validade;
    }

    public String getCvv() {
        return cvv;
    }

    @Override
    public String toString() {
        return "Cartao[final " + CartaoUtil.ultimos4(numero) + "]";
    }
}
