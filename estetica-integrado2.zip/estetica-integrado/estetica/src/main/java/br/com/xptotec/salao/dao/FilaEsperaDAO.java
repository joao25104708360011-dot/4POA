package br.com.xptotec.salao.dao;

import br.com.xptotec.salao.model.FilaEspera;
import br.com.xptotec.salao.model.StatusFila;
import br.com.xptotec.salao.util.NegocioException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FilaEsperaDAO {

    private final Connection c;

    public FilaEsperaDAO(Connection c) {
        this.c = c;
    }

    /** Insere no fim da fila do serviço/dia. Tenta de novo se outra transação pegou a mesma ordem. */
    public FilaEspera inserirNoFim(long clienteId, long servicoId, LocalDate data) throws SQLException {
        String sql = "INSERT INTO fila_espera (cliente_id, servico_id, data, ordem, status) VALUES (?,?,?,?,?)";
        for (int tentativa = 0; tentativa < 3; tentativa++) {
            int ordem = proximaOrdem(servicoId, data);
            try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setLong(1, clienteId);
                ps.setLong(2, servicoId);
                ps.setDate(3, Date.valueOf(data));
                ps.setInt(4, ordem);
                ps.setString(5, StatusFila.AGUARDANDO.name());
                ps.executeUpdate();
                FilaEspera f = new FilaEspera();
                f.setClienteId(clienteId);
                f.setServicoId(servicoId);
                f.setData(data);
                f.setOrdem(ordem);
                f.setStatus(StatusFila.AGUARDANDO);
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    rs.next();
                    f.setId(rs.getLong(1));
                }
                return f;
            } catch (SQLIntegrityConstraintViolationException concorrencia) {
                // outra inserção ficou com essa ordem; recalcula e tenta novamente
            }
        }
        throw new NegocioException("A fila está muito movimentada agora. Tente novamente.");
    }

    private int proximaOrdem(long servicoId, LocalDate data) throws SQLException {
        String sql = "SELECT COALESCE(MAX(ordem), 0) + 1 FROM fila_espera WHERE servico_id = ? AND data = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, servicoId);
            ps.setDate(2, Date.valueOf(data));
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    /** O cliente já está esperando (ou foi chamado) para esse serviço nesse dia? */
    public boolean existeAtivo(long clienteId, long servicoId, LocalDate data) throws SQLException {
        String sql = "SELECT 1 FROM fila_espera WHERE cliente_id = ? AND servico_id = ? AND data = ? "
                + "AND status IN ('AGUARDANDO','CHAMADO') LIMIT 1";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, clienteId);
            ps.setLong(2, servicoId);
            ps.setDate(3, Date.valueOf(data));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Primeiro AGUARDANDO por ordem, travado para evitar chamar a mesma pessoa duas vezes. */
    public Optional<FilaEspera> buscarProximoAguardando(long servicoId, LocalDate data) throws SQLException {
        String sql = "SELECT * FROM fila_espera WHERE servico_id = ? AND data = ? AND status = 'AGUARDANDO' "
                + "ORDER BY ordem LIMIT 1 FOR UPDATE";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, servicoId);
            ps.setDate(2, Date.valueOf(data));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
            }
        }
    }

    public Optional<FilaEspera> buscarPorId(long id, boolean paraAtualizar) throws SQLException {
        String sql = "SELECT * FROM fila_espera WHERE id = ?" + (paraAtualizar ? " FOR UPDATE" : "");
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
            }
        }
    }

    public void atualizarStatus(long id, StatusFila status) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE fila_espera SET status = ? WHERE id = ?")) {
            ps.setString(1, status.name());
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    /** Posição (1 = próximo) entre os que ainda aguardam no mesmo serviço/dia. */
    public int posicao(FilaEspera f) throws SQLException {
        String sql = "SELECT COUNT(*) + 1 FROM fila_espera WHERE servico_id = ? AND data = ? "
                + "AND status = 'AGUARDANDO' AND ordem < ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, f.getServicoId());
            ps.setDate(2, Date.valueOf(f.getData()));
            ps.setInt(3, f.getOrdem());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    /** Fila ativa (aguardando/chamado) do dia, com nomes para exibição. */
    public List<FilaEspera> listarAtivosDoDia(LocalDate data) throws SQLException {
        String sql = "SELECT f.*, u.nome AS nome_cliente, s.nome AS nome_servico "
                + "FROM fila_espera f "
                + "JOIN cliente u ON u.id = f.cliente_id "
                + "JOIN servico s ON s.id = f.servico_id "
                + "WHERE f.data = ? AND f.status IN ('AGUARDANDO','CHAMADO') "
                + "ORDER BY f.servico_id, f.ordem";
        List<FilaEspera> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(data));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    FilaEspera f = mapear(rs);
                    f.setNomeCliente(rs.getString("nome_cliente"));
                    f.setNomeServico(rs.getString("nome_servico"));
                    out.add(f);
                }
            }
        }
        return out;
    }

    private FilaEspera mapear(ResultSet rs) throws SQLException {
        FilaEspera f = new FilaEspera();
        f.setId(rs.getLong("id"));
        f.setClienteId(rs.getLong("cliente_id"));
        f.setServicoId(rs.getLong("servico_id"));
        f.setData(rs.getDate("data").toLocalDate());
        f.setOrdem(rs.getInt("ordem"));
        f.setStatus(StatusFila.valueOf(rs.getString("status")));
        f.setCriadoEm(rs.getTimestamp("criado_em").toLocalDateTime());
        return f;
    }
}
