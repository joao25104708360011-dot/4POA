package br.com.xptotec.salao.integracao;

import br.com.xptotec.salao.util.NegocioException;
import com.salao.model.TipoEscolha;
import com.salao.service.DisponibilidadeService;
import com.salao.service.ReservaException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * ADAPTADOR entre o pagamento e as tabelas da agenda (reserva, item_reserva, servico) e do cadastro (cliente).
 *
 * INTEGRADO com a agenda: lê reserva(id, cliente_id, data_hora, status, valor_total), item_reserva e servico,
 * e o nome do cliente vem da tabela cliente (e não mais de usuario). A agenda não tem tabela "horario":
 * o horário livre é calculado pelo DisponibilidadeService. Uma reserva pode ter vários serviços; aqui
 * "servico_id" é o do primeiro item (usado para a fila de espera) e "nome_servico" lista todos.
 * Se os nomes de tabela/coluna da equipe forem diferentes, ajuste APENAS este arquivo
 * (ou troque por chamadas aos DAOs da Parte 3).
 * Requer MySQL 8 (FOR UPDATE OF).
 */
public class ReservaIntegracaoDAO {

    private static final String SELECT_BASE =
            "SELECT r.id, r.cliente_id, "
                    + "(SELECT ir.servico_id FROM item_reserva ir WHERE ir.reserva_id = r.id "
                    + "ORDER BY ir.inicio, ir.id LIMIT 1) AS servico_id, "
                    + "r.valor_total AS valor, r.status, r.data_hora AS inicio, "
                    + "u.nome AS nome_cliente, "
                    + "(SELECT GROUP_CONCAT(s.nome ORDER BY ir.inicio, ir.id SEPARATOR ' + ') FROM item_reserva ir "
                    + "JOIN servico s ON s.id = ir.servico_id WHERE ir.reserva_id = r.id) AS nome_servico "
                    + "FROM reserva r "
                    + "JOIN cliente u ON u.id = r.cliente_id ";

    private final Connection c;

    public ReservaIntegracaoDAO(Connection c) {
        this.c = c;
    }

    public Optional<ReservaResumo> buscar(long reservaId, boolean paraAtualizar) throws SQLException {
        String sql = SELECT_BASE + "WHERE r.id = ?" + (paraAtualizar ? " FOR UPDATE OF r" : "");
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, reservaId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
            }
        }
    }

    public void atualizarStatus(long reservaId, StatusReserva novo) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE reserva SET status = ? WHERE id = ?")) {
            ps.setString(1, novo.name());
            ps.setLong(2, reservaId);
            ps.executeUpdate();
        }
    }

    public List<ReservaResumo> listarDoDia(LocalDate dia) throws SQLException {
        String sql = SELECT_BASE + "WHERE r.data_hora >= ? AND r.data_hora < ? ORDER BY r.data_hora, r.id";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(dia.atStartOfDay()));
            ps.setTimestamp(2, Timestamp.valueOf(dia.plusDays(1).atStartOfDay()));
            return lista(ps);
        }
    }

    /** Reservas confirmadas cujo início é anterior ao limite (ex.: agora - 15 min) e sem presença marcada. */
    public List<ReservaResumo> listarAtrasadas(LocalDateTime limite) throws SQLException {
        String sql = SELECT_BASE + "WHERE r.status = 'CONFIRMADA' AND r.data_hora < ? ORDER BY r.data_hora";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(limite));
            return lista(ps);
        }
    }

    /**
     * Próximo horário livre do serviço ainda hoje (a partir de agora). Vazio = não há horário.
     * Delega à agenda (DisponibilidadeService), que considera janelas dos profissionais e reservas existentes.
     */
    public Optional<LocalDateTime> proximoHorarioLivreHoje(long servicoId, LocalDateTime agora) throws SQLException {
        try {
            List<LocalTime> livres = new DisponibilidadeService().horariosLivres(
                    agora.toLocalDate(), List.of(servicoId), TipoEscolha.DISPONIVEL, null);
            return livres.isEmpty()
                    ? Optional.empty()
                    : Optional.of(LocalDateTime.of(agora.toLocalDate(), livres.get(0)));
        } catch (ReservaException e) {
            throw new NegocioException(e.getMessage());
        }
    }

    private List<ReservaResumo> lista(PreparedStatement ps) throws SQLException {
        List<ReservaResumo> out = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(mapear(rs));
            }
        }
        return out;
    }

    private ReservaResumo mapear(ResultSet rs) throws SQLException {
        ReservaResumo r = new ReservaResumo();
        r.setId(rs.getLong("id"));
        r.setClienteId(rs.getLong("cliente_id"));
        r.setServicoId(rs.getLong("servico_id"));
        r.setValor(rs.getBigDecimal("valor"));
        r.setStatus(rs.getString("status"));
        r.setInicio(rs.getTimestamp("inicio").toLocalDateTime());
        r.setNomeCliente(rs.getString("nome_cliente"));
        r.setNomeServico(rs.getString("nome_servico"));
        return r;
    }
}
