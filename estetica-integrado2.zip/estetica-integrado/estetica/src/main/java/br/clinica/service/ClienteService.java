package br.clinica.service;

import java.util.List;
import br.clinica.model.Cliente;

public interface ClienteService {

	void cadastrar(Cliente cliente);

	void atualizar(Cliente cliente);

	boolean deletar(long id);

	Cliente buscarPorLogin(String login);

	List<Cliente> listarTodos();
}