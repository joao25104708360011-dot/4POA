package br.clinica.servlet;

import java.io.IOException;
import java.util.Collections;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import br.clinica.dao.UsuarioDAO;
import br.clinica.dao.UsuarioDAOImpl;
import br.clinica.model.Cliente;
import br.clinica.model.Usuario;
import br.clinica.service.ClienteService;
import br.clinica.service.ClienteServiceImpl;

@WebServlet("/cadastrar")
public class CadastroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
	private ClienteService clienteService = new ClienteServiceImpl();
	private Gson gson = new Gson();

	private static class Dados {
		String login;
		String senha;
		String nome;
		String email;
		String telefone;
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		req.setCharacterEncoding("UTF-8");

		Dados dados;
		try {
			dados = gson.fromJson(req.getReader(), Dados.class);
		} catch (JsonSyntaxException e) {
			dados = null;
		}

		if (dados == null || vazio(dados.login) || vazio(dados.senha)) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "Informe login e senha.");
			return;
		}

		if (dados.senha.length() < 6) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "A senha deve ter pelo menos 6 caracteres.");
			return;
		}

		String login = dados.login.trim();

		if (usuarioDAO.buscarPorLogin(login) != null) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "Este login já está em uso.");
			return;
		}

		Usuario usuario = new Usuario();
		usuario.modificarLogin(login);
		usuario.modificarSenha(BCrypt.hashpw(dados.senha, BCrypt.gensalt()));
		usuario.modificarPerfil("CLIENTE");

		Cliente cliente = new Cliente();
		cliente.modificarNome(dados.nome);
		cliente.modificarEmail(dados.email);
		cliente.modificarTelefone(dados.telefone);
		cliente.modificarUsuario(usuario);

		try {
			clienteService.cadastrar(cliente);
			responder(resp, HttpServletResponse.SC_CREATED, Collections.singletonMap("mensagem", "Cadastro realizado!"));
		} catch (IllegalArgumentException e) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
		}
	}

	private boolean vazio(String texto) {
		return texto == null || texto.trim().isEmpty();
	}

	private void responder(HttpServletResponse resp, int status, Object conteudo) throws IOException {
		resp.setStatus(status);
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().print(gson.toJson(conteudo));
	}

	private void erro(HttpServletResponse resp, int status, String mensagem) throws IOException {
		responder(resp, status, Collections.singletonMap("erro", mensagem));
	}
}