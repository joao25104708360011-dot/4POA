package br.clinica.servlet;

import java.io.IOException;
import java.util.Collections;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import br.clinica.model.Cliente;
import br.clinica.model.Usuario;
import br.clinica.security.JwtUtil;
import br.clinica.service.AuthService;
import br.clinica.service.AuthServiceImpl;
import br.clinica.service.ClienteService;
import br.clinica.service.ClienteServiceImpl;

@WebServlet("/login")
public class AuthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AuthService authService = new AuthServiceImpl();
	private ClienteService clienteService = new ClienteServiceImpl();
	private Gson gson = new Gson();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		req.setCharacterEncoding("UTF-8");

		Usuario dados;
		try {
			dados = gson.fromJson(req.getReader(), Usuario.class);
		} catch (JsonSyntaxException e) {
			dados = null;
		}

		if (dados == null) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "Informe login e senha.");
			return;
		}

		try {
			String token = authService.autenticar(dados.pegarLogin(), dados.pegarSenha());
			criarSessao(req, token);
			responder(resp, HttpServletResponse.SC_OK, Collections.singletonMap("token", token));
		} catch (IllegalArgumentException e) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
		} catch (SecurityException e) {
			erro(resp, HttpServletResponse.SC_UNAUTHORIZED, e.getMessage());
		}
	}

	/**
	 * Ponte com os módulos de agenda e pagamento: eles identificam o usuário pela sessão HTTP
	 * (e não pelo token JWT), então o login também grava na sessão:
	 *  - "clienteId"     (Long) -> lido pelo ReservaServlet (agenda)
	 *  - "usuarioId"     (Long) -> lido pelo Sessao do pagamento (mesmo valor: id do Cliente)
	 *  - "usuarioPerfil" (String, CLIENTE ou RECEPCAO) -> lido pelo Sessao do pagamento
	 * A recepção não tem registro em Cliente, por isso não recebe clienteId/usuarioId.
	 */
	private void criarSessao(HttpServletRequest req, String token) {
		HttpSession antiga = req.getSession(false);
		if (antiga != null) {
			antiga.invalidate();
		}
		HttpSession sessao = req.getSession(true);

		sessao.setAttribute("usuarioPerfil", JwtUtil.obterPerfil(token));

		Cliente cliente = clienteService.buscarPorLogin(JwtUtil.obterLogin(token));
		if (cliente != null) {
			Long id = Long.valueOf(cliente.pegarId());
			sessao.setAttribute("clienteId", id);
			sessao.setAttribute("usuarioId", id);
		}
	}

	private void responder(HttpServletResponse resp, int status, Object conteudo) throws IOException {
		resp.setStatus(status);
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().print(gson.toJson(conteudo));
	}

	private void erro(HttpServletResponse resp, int status, String mensagem) throws IOException {
		responder(resp, status, Collections.singletonMap("erro", mensagem));
	}
}