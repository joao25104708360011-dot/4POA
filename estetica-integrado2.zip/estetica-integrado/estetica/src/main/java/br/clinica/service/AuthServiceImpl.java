package br.clinica.service;

import org.mindrot.jbcrypt.BCrypt;

import br.clinica.dao.UsuarioDAO;
import br.clinica.dao.UsuarioDAOImpl;
import br.clinica.model.Usuario;
import br.clinica.security.JwtUtil;

public class AuthServiceImpl implements AuthService {

	private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

	@Override
	public String autenticar(String login, String senha) {
		if (login == null || login.trim().isEmpty() || senha == null || senha.isEmpty()) {
			throw new IllegalArgumentException("Informe login e senha.");
		}

		Usuario usuario = usuarioDAO.buscarPorLogin(login.trim());

		if (usuario == null || !BCrypt.checkpw(senha, usuario.pegarSenha())) {
			throw new SecurityException("Login ou senha inválidos.");
		}

		return JwtUtil.gerarToken(usuario.pegarLogin(), usuario.pegarPerfil());
	}
}