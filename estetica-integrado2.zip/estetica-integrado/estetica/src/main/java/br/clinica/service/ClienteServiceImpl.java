package br.clinica.service;

import java.util.List;

import br.clinica.dao.ClienteDAO;
import br.clinica.dao.ClienteDAOImpl;
import br.clinica.model.Cliente;

public class ClienteServiceImpl implements ClienteService {

	private ClienteDAO clienteDAO = new ClienteDAOImpl();

	@Override
	public void cadastrar(Cliente cliente) {
		validar(cliente);

		if (clienteDAO.buscarPorEmail(cliente.pegarEmail()) != null) {
			throw new IllegalArgumentException("Este e-mail já está em uso.");
		}

		clienteDAO.cadastrar(cliente);
	}

	@Override
	public void atualizar(Cliente cliente) {
		validar(cliente);

		Cliente outro = clienteDAO.buscarPorEmail(cliente.pegarEmail());
		if (outro != null && outro.pegarId() != cliente.pegarId()) {
			throw new IllegalArgumentException("Este e-mail já está em uso.");
		}

		clienteDAO.atualizar(cliente);
	}

	@Override
	public boolean deletar(long id) {
		if (id <= 0) {
			throw new IllegalArgumentException("ID inválido.");
		}
		return clienteDAO.deletar(id);
	}

	@Override
	public Cliente buscarPorLogin(String login) {
		return clienteDAO.buscarPorLogin(login);
	}

	@Override
	public List<Cliente> listarTodos() {
		return clienteDAO.listarTodos();
	}

	private void validar(Cliente cliente) {
		if (cliente.pegarNome() == null || cliente.pegarNome().trim().isEmpty()) {
			throw new IllegalArgumentException("Informe o nome.");
		}
		if (cliente.pegarEmail() == null || !cliente.pegarEmail().contains("@")) {
			throw new IllegalArgumentException("Informe um e-mail válido.");
		}

		cliente.modificarNome(cliente.pegarNome().trim());
		cliente.modificarEmail(cliente.pegarEmail().trim().toLowerCase());
	}
}