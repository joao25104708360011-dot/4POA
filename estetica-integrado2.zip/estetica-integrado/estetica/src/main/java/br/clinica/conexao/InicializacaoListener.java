package br.clinica.conexao;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.mindrot.jbcrypt.BCrypt;
import br.clinica.model.Usuario;

/**
 * Na subida da aplicação cria o usuário da recepção, caso ainda não exista.
 * (O cadastro pelo site só cria clientes, e a recepção precisa de um login para usar o painel.)
 *
 * Login: recepcao   Senha inicial: recepcao123   -> troque antes de usar fora da faculdade.
 */
@WebListener
public class InicializacaoListener implements ServletContextListener {

	private static final String LOGIN = "recepcao";
	private static final String SENHA_INICIAL = "recepcao123";

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		Transaction tx = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Usuario existente = session.createQuery("from Usuario where login = :login", Usuario.class)
					.setParameter("login", LOGIN)
					.uniqueResult();
			if (existente != null) {
				return;
			}
			tx = session.beginTransaction();
			Usuario recepcao = new Usuario();
			recepcao.modificarLogin(LOGIN);
			recepcao.modificarSenha(BCrypt.hashpw(SENHA_INICIAL, BCrypt.gensalt()));
			recepcao.modificarPerfil("RECEPCAO");
			session.save(recepcao);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}
	}
}
