package br.clinica.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import br.clinica.conexao.HibernateUtil;
import br.clinica.model.Cliente;

public class ClienteDAOImpl implements ClienteDAO {

	@Override
	public void cadastrar(Cliente cliente) {
		Transaction tx = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			tx = session.beginTransaction();
			session.save(cliente.pegarUsuario());
			session.save(cliente);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}
	}

	@Override
	public void atualizar(Cliente cliente) {
		Transaction tx = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			tx = session.beginTransaction();
			session.update(cliente);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}
	}

	@Override
	public boolean deletar(long id) {
		Transaction tx = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Cliente cliente = session.get(Cliente.class, id);
			if (cliente == null) {
				return false;
			}
			tx = session.beginTransaction();
			session.delete(cliente);
			session.delete(cliente.pegarUsuario());
			tx.commit();
			return true;
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}
	}

	@Override
	public Cliente buscarPorEmail(String email) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("from Cliente where email = :email", Cliente.class)
					.setParameter("email", email)
					.uniqueResult();
		}
	}

	@Override
	public Cliente buscarPorLogin(String login) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("from Cliente where usuario.login = :login", Cliente.class)
					.setParameter("login", login)
					.uniqueResult();
		}
	}

	@Override
	public List<Cliente> listarTodos() {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("from Cliente order by id", Cliente.class).list();
		}
	}
}