package br.clinica.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usuario")
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(nullable = false, unique = true)
	private String login;

	@Column(nullable = false)
	private String senha;

	@Column(nullable = false)
	private String perfil;

	public int pegarId() {
		return id;
	}

	public String pegarLogin() {
		return login;
	}

	public void modificarLogin(String login) {
		this.login = login;
	}

	public String pegarSenha() {
		return senha;
	}

	public void modificarSenha(String senha) {
		this.senha = senha;
	}

	public String pegarPerfil() {
		return perfil;
	}

	public void modificarPerfil(String perfil) {
		this.perfil = perfil;
	}
}