package br.clinica.dao;

import java.util.List;
import br.clinica.model.Cliente;

public interface ClienteDAO {

	void cadastrar(Cliente cliente);

	void atualizar(Cliente cliente);

	boolean deletar(long id);

	Cliente buscarPorEmail(String email);

	Cliente buscarPorLogin(String login);

	List<Cliente> listarTodos();
}