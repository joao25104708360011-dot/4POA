package br.clinica.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.PersistenceException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import br.clinica.model.Cliente;
import br.clinica.service.ClienteService;
import br.clinica.service.ClienteServiceImpl;

@WebServlet("/api/clientes/*")
public class ClienteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ClienteService clienteService = new ClienteServiceImpl();
	private Gson gson = new Gson();

	private static class Dados {
		String nome;
		String telefone;
		String email;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String caminho = req.getPathInfo();

		if (caminho == null || caminho.equals("/")) {
			if (!ehRecepcao(req)) {
				erro(resp, HttpServletResponse.SC_FORBIDDEN, "Sem permissão.");
				return;
			}
			List<Map<String, Object>> lista = new ArrayList<>();
			for (Cliente cliente : clienteService.listarTodos()) {
				lista.add(montarDados(cliente));
			}
			responder(resp, HttpServletResponse.SC_OK, lista);

		} else if (caminho.equals("/me")) {
			Cliente cliente = buscarClienteLogado(req);
			if (cliente == null) {
				erro(resp, HttpServletResponse.SC_NOT_FOUND, "Cliente não encontrado.");
				return;
			}
			responder(resp, HttpServletResponse.SC_OK, montarDados(cliente));

		} else {
			erro(resp, HttpServletResponse.SC_NOT_FOUND, "Rota não encontrada.");
		}
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		if (!"/me".equals(req.getPathInfo())) {
			erro(resp, HttpServletResponse.SC_NOT_FOUND, "Rota não encontrada.");
			return;
		}

		Cliente cliente = buscarClienteLogado(req);
		if (cliente == null) {
			erro(resp, HttpServletResponse.SC_NOT_FOUND, "Cliente não encontrado.");
			return;
		}

		req.setCharacterEncoding("UTF-8");

		Dados dados;
		try {
			dados = gson.fromJson(req.getReader(), Dados.class);
		} catch (JsonSyntaxException e) {
			dados = null;
		}

		if (dados == null) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "Dados inválidos.");
			return;
		}

		cliente.modificarNome(dados.nome);
		cliente.modificarEmail(dados.email);
		cliente.modificarTelefone(dados.telefone);

		try {
			clienteService.atualizar(cliente);
			responder(resp, HttpServletResponse.SC_OK, Collections.singletonMap("mensagem", "Dados atualizados!"));
		} catch (IllegalArgumentException e) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
		}
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		if (!ehRecepcao(req)) {
			erro(resp, HttpServletResponse.SC_FORBIDDEN, "Sem permissão.");
			return;
		}

		String caminho = req.getPathInfo();
		if (caminho == null || caminho.equals("/")) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "Informe o ID na URL.");
			return;
		}

		try {
			long id = Long.parseLong(caminho.substring(1));

			if (clienteService.deletar(id)) {
				responder(resp, HttpServletResponse.SC_OK, Collections.singletonMap("mensagem", "Cliente removido!"));
			} else {
				erro(resp, HttpServletResponse.SC_NOT_FOUND, "Cliente não encontrado.");
			}
		} catch (IllegalArgumentException e) {
			erro(resp, HttpServletResponse.SC_BAD_REQUEST, "ID inválido.");
		} catch (PersistenceException e) {
			// há reservas, pagamentos, crédito ou fila apontando para este cliente (chaves estrangeiras)
			erro(resp, HttpServletResponse.SC_CONFLICT, "Não é possível excluir: o cliente possui reservas, pagamentos ou crédito.");
		}
	}

	private boolean ehRecepcao(HttpServletRequest req) {
		return "RECEPCAO".equals(req.getAttribute("perfilUsuario"));
	}

	private Cliente buscarClienteLogado(HttpServletRequest req) {
		String login = (String) req.getAttribute("usuarioLogado");
		return clienteService.buscarPorLogin(login);
	}

	private Map<String, Object> montarDados(Cliente cliente) {
		Map<String, Object> dados = new LinkedHashMap<>();
		dados.put("id", cliente.pegarId());
		dados.put("nome", cliente.pegarNome());
		dados.put("telefone", cliente.pegarTelefone());
		dados.put("email", cliente.pegarEmail());
		return dados;
	}

	private void responder(HttpServletResponse resp, int status, Object conteudo) throws IOException {
		resp.setStatus(status);
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().print(gson.toJson(conteudo));
	}

	private void erro(HttpServletResponse resp, int status, String mensagem) throws IOException {
		responder(resp, status, Collections.singletonMap("erro", mensagem));
	}
}