package br.clinica.dao;

import org.hibernate.Session;

import br.clinica.conexao.HibernateUtil;
import br.clinica.model.Usuario;

public class UsuarioDAOImpl implements UsuarioDAO {

	@Override
	public Usuario buscarPorLogin(String login) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("from Usuario where login = :login", Usuario.class)
					.setParameter("login", login)
					.uniqueResult();
		}
	}
}