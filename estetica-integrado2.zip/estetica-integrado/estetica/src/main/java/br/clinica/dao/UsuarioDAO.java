package br.clinica.dao;

import br.clinica.model.Usuario;

public interface UsuarioDAO {

	Usuario buscarPorLogin(String login);
}