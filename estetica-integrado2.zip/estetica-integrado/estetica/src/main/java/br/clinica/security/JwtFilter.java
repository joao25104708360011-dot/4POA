package br.clinica.security;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter("/api/*")
public class JwtFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;

		String cabecalho = req.getHeader("Authorization");

		if (cabecalho != null && cabecalho.startsWith("Bearer ")) {
			String token = cabecalho.substring(7);

			if (JwtUtil.validarToken(token)) {
				req.setAttribute("usuarioLogado", JwtUtil.obterLogin(token));
				req.setAttribute("perfilUsuario", JwtUtil.obterPerfil(token));
				chain.doFilter(request, response);
				return;
			}
		}

		resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().print("{\"erro\": \"Faça login para continuar.\"}");
	}
}