package br.clinica.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cliente")
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false)
	private String nome;

	private String telefone;

	@Column(nullable = false, unique = true)
	private String email;

	@OneToOne
	@JoinColumn(nullable = false, unique = true)
	private Usuario usuario;

	public long pegarId() {
		return id;
	}

	public String pegarNome() {
		return nome;
	}

	public void modificarNome(String nome) {
		this.nome = nome;
	}

	public String pegarTelefone() {
		return telefone;
	}

	public void modificarTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String pegarEmail() {
		return email;
	}

	public void modificarEmail(String email) {
		this.email = email;
	}

	public Usuario pegarUsuario() {
		return usuario;
	}

	public void modificarUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}