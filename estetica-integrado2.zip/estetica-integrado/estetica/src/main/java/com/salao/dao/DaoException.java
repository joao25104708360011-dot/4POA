package com.salao.dao;

/** Falha inesperada de banco de dados (diferente de uma regra de negócio, que é ReservaException). */
public class DaoException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DaoException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
