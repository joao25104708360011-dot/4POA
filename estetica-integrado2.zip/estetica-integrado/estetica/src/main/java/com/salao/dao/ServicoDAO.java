package com.salao.dao;

import com.salao.model.Servico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Só as consultas que a agenda precisa. Se o colega dos serviços já tem um DAO,
 * mantenha o dele e adapte as chamadas nos services.
 */
public class ServicoDAO {
    private final Connection conn;

    public ServicoDAO(Connection conn) {
        this.conn = conn;
    }

    /** Retorna null se não existir ou estiver inativo. */
    public Servico buscarPorId(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, nome, duracao_min, preco FROM servico WHERE id = ? AND ativo = TRUE")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    public List<Servico> listarAtivos() throws SQLException {
        List<Servico> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, nome, duracao_min, preco FROM servico WHERE ativo = TRUE ORDER BY nome");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    /** Serviços de um pacote, na ordem em que serão executados. */
    public List<Servico> listarPorPacote(long pacoteId) throws SQLException {
        List<Servico> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT s.id, s.nome, s.duracao_min, s.preco FROM servico s "
                        + "JOIN pacote_servico ps ON ps.servico_id = s.id "
                        + "WHERE ps.pacote_id = ? AND s.ativo = TRUE ORDER BY ps.ordem, s.id")) {
            ps.setLong(1, pacoteId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    private Servico mapear(ResultSet rs) throws SQLException {
        Servico s = new Servico();
        s.setId(rs.getLong("id"));
        s.setNome(rs.getString("nome"));
        s.setDuracaoMinutos(rs.getInt("duracao_min"));
        s.setPreco(rs.getBigDecimal("preco"));
        return s;
    }
}
