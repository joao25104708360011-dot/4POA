package com.salao.servlet;

import com.salao.model.Reserva;
import com.salao.model.TipoEscolha;
import com.salao.service.CatalogoService;
import com.salao.service.ReservaException;
import com.salao.service.ReservaService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * GET  /reservas             -> minhas-reservas.jsp
 * GET  /reservas?acao=nova   -> reservar.jsp
 * POST /reservas  acao=criar    -> cria a reserva (AGUARDANDO_PAGAMENTO) e redireciona para /pagamento
 * POST /reservas  acao=cancelar -> cancela a reserva
 *
 * O cliente logado vem do atributo de sessão "clienteId" (Long). Ajuste CHAVE_CLIENTE e
 * URL_LOGIN para o que o módulo de login do projeto usa.
 */
@WebServlet("/reservas")
public class ReservaServlet extends HttpServlet {

    private static final String CHAVE_CLIENTE = "clienteId";
    private static final String URL_LOGIN = "/login.jsp";

    private final ReservaService reservaService = new ReservaService();
    private final CatalogoService catalogoService = new CatalogoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long clienteId = clienteLogado(req, resp);
        if (clienteId == null) {
            return;
        }
        recuperarMensagens(req);

        if ("nova".equals(req.getParameter("acao"))) {
            req.setAttribute("servicos", catalogoService.listarServicos());
            req.setAttribute("pacotes", catalogoService.listarPacotes());
            req.setAttribute("hoje", LocalDate.now().toString());
            req.getRequestDispatcher("/reservar.jsp").forward(req, resp);
        } else {
            req.setAttribute("reservas", reservaService.listarMinhasReservas(clienteId));
            req.getRequestDispatcher("/minhas-reservas.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        Long clienteId = clienteLogado(req, resp);
        if (clienteId == null) {
            return;
        }

        String acao = req.getParameter("acao");
        String voltarPara = "/reservas";
        try {
            if ("cancelar".equals(acao)) {
                long reservaId = Parametros.longObrigatorio(req.getParameter("reservaId"), "Reserva inválida.");
                reservaService.cancelar(reservaId, clienteId);
                mensagem(req, "sucesso", "Reserva cancelada.");
            } else if ("criar".equals(acao)) {
                voltarPara = "/reservas?acao=nova"; // se falhar, volta para o formulário
                Reserva reserva = criar(req, clienteId);
                voltarPara = "/pagamento?reservaId=" + reserva.getId(); // módulo de pagamento
            } else {
                throw new ReservaException("Ação inválida.");
            }
        } catch (ReservaException e) {
            mensagem(req, "erro", e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + voltarPara); // Post/Redirect/Get
    }

    private Reserva criar(HttpServletRequest req, long clienteId) throws ReservaException {
        LocalDate dia = Parametros.data(req.getParameter("data"));
        LocalTime hora = Parametros.hora(req.getParameter("hora"));
        TipoEscolha tipo = TipoEscolha.deTexto(req.getParameter("tipo"));
        Long profissionalId = Parametros.longOuNulo(req.getParameter("profissionalId"));

        String pacote = req.getParameter("pacoteId");
        if (pacote != null && !pacote.isBlank()) {
            long pacoteId = Parametros.longObrigatorio(pacote, "Pacote inválido.");
            return reservaService.criarComPacote(clienteId, dia, hora, pacoteId, tipo, profissionalId);
        } else {
            List<Long> servicoIds = Parametros.ids(req.getParameterValues("servicoIds"));
            return reservaService.criarComServicos(clienteId, dia, hora, servicoIds, tipo, profissionalId);
        }
    }

    /** Devolve o id do cliente ou, se não houver login, redireciona e devolve null. */
    private Long clienteLogado(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession sessao = req.getSession(false);
        Object id = sessao == null ? null : sessao.getAttribute(CHAVE_CLIENTE);
        if (id instanceof Long clienteId) {
            return clienteId;
        }
        resp.sendRedirect(req.getContextPath() + URL_LOGIN);
        return null;
    }

    // Mensagens de uma requisição para a próxima (necessário por causa do redirect).
    private void mensagem(HttpServletRequest req, String tipo, String texto) {
        req.getSession().setAttribute("flash_" + tipo, texto);
    }

    private void recuperarMensagens(HttpServletRequest req) {
        HttpSession sessao = req.getSession();
        for (String tipo : new String[]{"sucesso", "erro"}) {
            Object texto = sessao.getAttribute("flash_" + tipo);
            if (texto != null) {
                req.setAttribute("flash_" + tipo, texto);
                sessao.removeAttribute("flash_" + tipo);
            }
        }
    }
}
