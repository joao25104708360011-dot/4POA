package com.salao.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Reserva {
    private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm");

    private long id;
    private long clienteId;
    private LocalDateTime dataHora;
    private StatusReserva status = StatusReserva.CONFIRMADA;
    private BigDecimal valorTotal = BigDecimal.ZERO;
    private TipoEscolha tipoEscolha = TipoEscolha.DISPONIVEL;
    private List<ItemReserva> itens = new ArrayList<>();

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getClienteId() { return clienteId; }
    public void setClienteId(long clienteId) { this.clienteId = clienteId; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    public StatusReserva getStatus() { return status; }
    public void setStatus(StatusReserva status) { this.status = status; }

    public BigDecimal getValorTotal() { return valorTotal; }
    public void setValorTotal(BigDecimal valorTotal) { this.valorTotal = valorTotal; }

    public TipoEscolha getTipoEscolha() { return tipoEscolha; }
    public void setTipoEscolha(TipoEscolha tipoEscolha) { this.tipoEscolha = tipoEscolha; }

    public List<ItemReserva> getItens() { return itens; }
    public void setItens(List<ItemReserva> itens) { this.itens = itens; }

    public String getDataHoraFormatada() {
        return dataHora == null ? "" : dataHora.format(DATA_HORA);
    }

    /** A JSP só mostra o botão "Cancelar" quando isto for true. */
    public boolean isCancelavel() {
        return (status == StatusReserva.CONFIRMADA || status == StatusReserva.AGUARDANDO_PAGAMENTO)
                && dataHora != null && dataHora.isAfter(LocalDateTime.now());
    }

    /** A JSP só mostra o link "Pagar agora" quando isto for true. */
    public boolean isPagavel() {
        return status == StatusReserva.AGUARDANDO_PAGAMENTO && dataHora != null && dataHora.isAfter(LocalDateTime.now());
    }
}
