package com.salao.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/** Conjunto de serviços vendido por um preço fechado. Versão mínima para a agenda. */
public class Pacote {
    private long id;
    private String nome;
    private BigDecimal preco;
    private List<Servico> servicos = new ArrayList<>();

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }

    public List<Servico> getServicos() { return servicos; }
    public void setServicos(List<Servico> servicos) { this.servicos = servicos; }

    public int getDuracaoTotal() {
        return servicos.stream().mapToInt(Servico::getDuracaoMinutos).sum();
    }

    /** "1,3,5" - a JSP usa para pedir os horários do pacote ao DisponibilidadeServlet. */
    public String getServicoIdsCsv() {
        return servicos.stream().map(s -> String.valueOf(s.getId())).collect(Collectors.joining(","));
    }
}
