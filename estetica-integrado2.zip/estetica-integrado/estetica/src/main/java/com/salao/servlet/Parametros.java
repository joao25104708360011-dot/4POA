package com.salao.servlet;

import com.salao.service.ReservaException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/** Leitura segura de parâmetros de formulário: valor inválido vira uma mensagem amigável. */
final class Parametros {
    private Parametros() {
    }

    static List<Long> ids(String[] valores) throws ReservaException {
        List<Long> ids = new ArrayList<>();
        if (valores != null) {
            for (String v : valores) {
                ids.add(longObrigatorio(v, "Serviço inválido."));
            }
        }
        return ids;
    }

    static long longObrigatorio(String valor, String mensagem) throws ReservaException {
        try {
            return Long.parseLong(valor.trim());
        } catch (NumberFormatException | NullPointerException e) {
            throw new ReservaException(mensagem);
        }
    }

    static Long longOuNulo(String valor) throws ReservaException {
        return valor == null || valor.isBlank() ? null : longObrigatorio(valor, "Valor inválido.");
    }

    static LocalDate data(String valor) throws ReservaException {
        try {
            return LocalDate.parse(valor);
        } catch (DateTimeParseException | NullPointerException e) {
            throw new ReservaException("Data inválida.");
        }
    }

    static LocalTime hora(String valor) throws ReservaException {
        try {
            return LocalTime.parse(valor);
        } catch (DateTimeParseException | NullPointerException e) {
            throw new ReservaException("Escolha um horário.");
        }
    }

    /** Escapa texto para colocar dentro de uma string JSON. */
    static String jsonTexto(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }
}
