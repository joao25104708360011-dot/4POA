package com.salao.model;

import java.time.LocalDate;
import java.time.LocalTime;

/** Janela em que um profissional atende em um dia (ex.: Ana, 10/11, 09:00 às 18:00). */
public class Disponibilidade {
    private long id;
    private long profissionalId;
    private LocalDate dia;
    private LocalTime horaInicio;
    private LocalTime horaFim;

    public Disponibilidade() {
    }

    public Disponibilidade(long profissionalId, LocalDate dia, LocalTime horaInicio, LocalTime horaFim) {
        this.profissionalId = profissionalId;
        this.dia = dia;
        this.horaInicio = horaInicio;
        this.horaFim = horaFim;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getProfissionalId() { return profissionalId; }
    public void setProfissionalId(long profissionalId) { this.profissionalId = profissionalId; }

    public LocalDate getDia() { return dia; }
    public void setDia(LocalDate dia) { this.dia = dia; }

    public LocalTime getHoraInicio() { return horaInicio; }
    public void setHoraInicio(LocalTime horaInicio) { this.horaInicio = horaInicio; }

    public LocalTime getHoraFim() { return horaFim; }
    public void setHoraFim(LocalTime horaFim) { this.horaFim = horaFim; }
}
