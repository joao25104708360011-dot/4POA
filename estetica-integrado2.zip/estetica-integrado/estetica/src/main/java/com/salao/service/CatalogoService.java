package com.salao.service;

import com.salao.dao.DaoException;
import com.salao.dao.PacoteDAO;
import com.salao.dao.ServicoDAO;
import com.salao.model.Pacote;
import com.salao.model.Servico;
import com.salao.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/** Serviços e pacotes que a tela de reserva oferece. Se os colegas já têm isso, use o deles. */
public class CatalogoService {

    public List<Servico> listarServicos() {
        try (Connection conn = ConnectionFactory.getConnection()) {
            return new ServicoDAO(conn).listarAtivos();
        } catch (SQLException e) {
            throw new DaoException("Erro ao listar serviços", e);
        }
    }

    public List<Pacote> listarPacotes() {
        try (Connection conn = ConnectionFactory.getConnection()) {
            return new PacoteDAO(conn).listarAtivos();
        } catch (SQLException e) {
            throw new DaoException("Erro ao listar pacotes", e);
        }
    }
}
