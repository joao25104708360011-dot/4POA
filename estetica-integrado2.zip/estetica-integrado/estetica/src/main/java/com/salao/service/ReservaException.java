package com.salao.service;

/** Regra de negócio violada. A mensagem é segura para mostrar ao cliente. */
public class ReservaException extends Exception {
    private static final long serialVersionUID = 1L;

    public ReservaException(String mensagem) {
        super(mensagem);
    }
}
