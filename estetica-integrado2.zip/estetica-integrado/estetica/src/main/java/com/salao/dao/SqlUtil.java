package com.salao.dao;

import java.util.Collections;

final class SqlUtil {
    private SqlUtil() {
    }

    /** "?,?,?" para montar cláusulas IN (...). */
    static String placeholders(int quantidade) {
        return String.join(",", Collections.nCopies(quantidade, "?"));
    }
}
