package com.salao.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Um serviço dentro de uma reserva, com o profissional e o intervalo em que será feito. */
public class ItemReserva {
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");

    private long id;
    private long reservaId;
    private long servicoId;
    private long profissionalId;
    private LocalDateTime inicio;
    private LocalDateTime fim;

    // Preenchidos pelos JOINs na leitura, só para exibição.
    private String servicoNome;
    private String profissionalNome;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getReservaId() { return reservaId; }
    public void setReservaId(long reservaId) { this.reservaId = reservaId; }

    public long getServicoId() { return servicoId; }
    public void setServicoId(long servicoId) { this.servicoId = servicoId; }

    public long getProfissionalId() { return profissionalId; }
    public void setProfissionalId(long profissionalId) { this.profissionalId = profissionalId; }

    public LocalDateTime getInicio() { return inicio; }
    public void setInicio(LocalDateTime inicio) { this.inicio = inicio; }

    public LocalDateTime getFim() { return fim; }
    public void setFim(LocalDateTime fim) { this.fim = fim; }

    public String getServicoNome() { return servicoNome; }
    public void setServicoNome(String servicoNome) { this.servicoNome = servicoNome; }

    public String getProfissionalNome() { return profissionalNome; }
    public void setProfissionalNome(String profissionalNome) { this.profissionalNome = profissionalNome; }

    /** "09:30" - usado na JSP (o fmt:formatDate do JSTL não entende java.time). */
    public String getInicioFormatado() { return inicio == null ? "" : inicio.format(HORA); }

    public String getFimFormatado() { return fim == null ? "" : fim.format(HORA); }
}
