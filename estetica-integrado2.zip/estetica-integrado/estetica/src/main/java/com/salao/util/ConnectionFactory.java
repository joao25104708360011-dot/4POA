package com.salao.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Conexão simples via DriverManager, configurada por variáveis de ambiente.
 * Se o projeto já tem uma fábrica de conexões (ou um DataSource/JNDI), use a existente:
 * basta trocar a chamada ConnectionFactory.getConnection() nos services.
 */
public final class ConnectionFactory {

    private static final String URL = env("SALAO_DB_URL",
            "jdbc:mysql://localhost:3306/salao?serverTimezone=America/Sao_Paulo&useSSL=false&allowPublicKeyRetrieval=true");
    private static final String USUARIO = env("SALAO_DB_USER", "root");
    private static final String SENHA = env("SALAO_DB_PASS", "");

    private ConnectionFactory() {
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }

    private static String env(String nome, String padrao) {
        String valor = System.getenv(nome);
        return valor == null || valor.isBlank() ? padrao : valor;
    }
}
