package com.salao.service;

import com.salao.model.Disponibilidade;
import com.salao.model.ItemReserva;
import com.salao.model.Servico;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Retrato de um dia: as janelas de atendimento e os intervalos já ocupados de cada profissional.
 * É lógica pura (sem banco), por isso é a peça usada tanto para mostrar os horários livres
 * quanto para conferir o conflito na hora de gravar a reserva.
 */
public class AgendaDoDia {

    private final Map<Long, List<Disponibilidade>> janelas = new HashMap<>();
    private final Map<Long, List<ItemReserva>> ocupados = new HashMap<>();

    public AgendaDoDia(List<Disponibilidade> janelas, List<ItemReserva> ocupados) {
        for (Disponibilidade d : janelas) {
            this.janelas.computeIfAbsent(d.getProfissionalId(), k -> new ArrayList<>()).add(d);
        }
        for (ItemReserva i : ocupados) {
            this.ocupados.computeIfAbsent(i.getProfissionalId(), k -> new ArrayList<>()).add(i);
        }
    }

    /**
     * O profissional pode atender em [inicio, fim)? Precisa caber inteiro dentro de uma janela
     * do dia e não sobrepor nenhum item já reservado. Encostar é permitido: um atendimento que
     * termina às 10:00 não impede outro que começa às 10:00.
     */
    public boolean livre(long profissionalId, LocalDateTime inicio, LocalDateTime fim) {
        LocalDate dia = inicio.toLocalDate();
        boolean dentroDeUmaJanela = janelas.getOrDefault(profissionalId, List.of()).stream().anyMatch(j ->
                j.getDia().equals(dia)
                        && !inicio.isBefore(LocalDateTime.of(dia, j.getHoraInicio()))
                        && !fim.isAfter(LocalDateTime.of(dia, j.getHoraFim())));
        if (!dentroDeUmaJanela) {
            return false;
        }
        return ocupados.getOrDefault(profissionalId, List.of()).stream()
                .noneMatch(o -> inicio.isBefore(o.getFim()) && fim.isAfter(o.getInicio()));
    }

    /**
     * Encadeia os serviços um depois do outro a partir de {@code inicio} e escolhe quem faz cada um.
     *
     * @param candidatos para cada serviço (por id), os profissionais aceitos, em ordem de prioridade.
     *                   No modo "profissional disponível" é a lista de quem realiza o serviço;
     *                   no modo "preferência" é só o profissional escolhido.
     * @return os itens da reserva, ou null se algum serviço não encontra profissional livre.
     */
    public List<ItemReserva> alocar(LocalDateTime inicio, List<Servico> servicos, Map<Long, List<Long>> candidatos) {
        List<ItemReserva> itens = new ArrayList<>();
        LocalDateTime cursor = inicio;
        Long anterior = null;

        for (Servico servico : servicos) {
            LocalDateTime fim = cursor.plusMinutes(servico.getDuracaoMinutos());
            List<Long> possiveis = candidatos.getOrDefault(servico.getId(), List.of());

            // Prefere manter o mesmo profissional do serviço anterior (cliente não troca de mãos à toa).
            Long escolhido = null;
            if (anterior != null && possiveis.contains(anterior) && livre(anterior, cursor, fim)) {
                escolhido = anterior;
            } else {
                for (Long candidato : possiveis) {
                    if (livre(candidato, cursor, fim)) {
                        escolhido = candidato;
                        break;
                    }
                }
            }
            if (escolhido == null) {
                return null;
            }

            ItemReserva item = new ItemReserva();
            item.setServicoId(servico.getId());
            item.setServicoNome(servico.getNome());
            item.setProfissionalId(escolhido);
            item.setInicio(cursor);
            item.setFim(fim);
            itens.add(item);

            anterior = escolhido;
            cursor = fim;
        }
        return itens;
    }
}
