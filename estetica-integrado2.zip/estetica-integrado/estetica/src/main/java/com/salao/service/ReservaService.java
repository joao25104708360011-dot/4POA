package com.salao.service;

import com.salao.dao.DaoException;
import com.salao.dao.DisponibilidadeDAO;
import com.salao.dao.ItemReservaDAO;
import com.salao.dao.PacoteDAO;
import com.salao.dao.ReservaDAO;
import com.salao.model.Disponibilidade;
import com.salao.model.ItemReserva;
import com.salao.model.Pacote;
import com.salao.model.Reserva;
import com.salao.model.Servico;
import com.salao.model.StatusReserva;
import com.salao.model.TipoEscolha;
import com.salao.util.ConnectionFactory;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ReservaService {

    /** Vários serviços avulsos, feitos em sequência no mesmo dia. */
    public Reserva criarComServicos(long clienteId, LocalDate dia, LocalTime hora, List<Long> servicoIds,
                                    TipoEscolha tipo, Long profissionalId) throws ReservaException {
        return criar(clienteId, dia, hora, servicoIds, null, tipo, profissionalId);
    }

    /** Pacote: os serviços dele em sequência, cobrados pelo preço do pacote. */
    public Reserva criarComPacote(long clienteId, LocalDate dia, LocalTime hora, long pacoteId,
                                  TipoEscolha tipo, Long profissionalId) throws ReservaException {
        return criar(clienteId, dia, hora, null, pacoteId, tipo, profissionalId);
    }

    private Reserva criar(long clienteId, LocalDate dia, LocalTime hora, List<Long> servicoIds, Long pacoteId,
                          TipoEscolha tipo, Long profissionalId) throws ReservaException {
        if (dia == null || hora == null) {
            throw new ReservaException("Escolha o dia e o horário.");
        }
        LocalDateTime inicio = LocalDateTime.of(dia, hora);
        if (!inicio.isAfter(LocalDateTime.now())) {
            throw new ReservaException("Escolha um horário no futuro.");
        }
        TipoEscolha escolha = tipo == null ? TipoEscolha.DISPONIVEL : tipo;

        try (Connection conn = ConnectionFactory.getConnection()) {
            // Leituras preliminares, ainda em autocommit (fora da transação).
            List<Servico> servicos;
            BigDecimal valorTotal;
            if (pacoteId != null) {
                Pacote pacote = new PacoteDAO(conn).buscarPorId(pacoteId);
                if (pacote == null || pacote.getServicos().isEmpty()) {
                    throw new ReservaException("Pacote indisponível.");
                }
                servicos = pacote.getServicos();
                valorTotal = pacote.getPreco();
            } else {
                servicos = DisponibilidadeService.carregarServicos(conn, servicoIds);
                valorTotal = servicos.stream().map(Servico::getPreco).reduce(BigDecimal.ZERO, BigDecimal::add);
            }
            Map<Long, List<Long>> candidatos =
                    DisponibilidadeService.candidatosPorServico(conn, servicos, escolha, profissionalId);
            Set<Long> profissionais = candidatos.values().stream()
                    .flatMap(List::stream)
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            // A partir daqui é uma transação. A PRIMEIRA instrução dela é o lock das janelas: assim as
            // leituras seguintes já enxergam qualquer reserva que outra pessoa tenha acabado de confirmar.
            conn.setAutoCommit(false);
            try {
                List<Disponibilidade> janelas = new DisponibilidadeDAO(conn).bloquearPorDia(dia, profissionais);
                ItemReservaDAO itemDAO = new ItemReservaDAO(conn);
                List<ItemReserva> ocupados = itemDAO.listarOcupadosPorDia(dia, profissionais);

                List<ItemReserva> itens = new AgendaDoDia(janelas, ocupados).alocar(inicio, servicos, candidatos);
                if (itens == null) {
                    throw new ReservaException("Esse horário não está mais disponível. Escolha outro.");
                }
                LocalDateTime fim = itens.get(itens.size() - 1).getFim();
                if (itemDAO.existeConflitoCliente(clienteId, inicio, fim)) {
                    throw new ReservaException("Você já tem uma reserva nesse horário.");
                }

                Reserva reserva = new Reserva();
                reserva.setClienteId(clienteId);
                reserva.setDataHora(inicio);
                reserva.setStatus(StatusReserva.AGUARDANDO_PAGAMENTO); // vira CONFIRMADA quando o pagamento for aprovado
                reserva.setValorTotal(valorTotal);
                reserva.setTipoEscolha(escolha);
                long reservaId = new ReservaDAO(conn).inserir(reserva);
                for (ItemReserva item : itens) {
                    item.setReservaId(reservaId);
                    itemDAO.inserir(item);
                }
                conn.commit();
                reserva.setItens(itens);
                return reserva;
            } catch (ReservaException | SQLException | RuntimeException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao criar a reserva", e);
        }
    }

    /** Cancela uma reserva do próprio cliente. Os horários ficam livres porque as consultas ignoram CANCELADA. */
    public void cancelar(long reservaId, long clienteId) throws ReservaException {
        try (Connection conn = ConnectionFactory.getConnection()) {
            ReservaDAO dao = new ReservaDAO(conn);
            Reserva reserva = dao.buscarPorId(reservaId);
            if (reserva == null || reserva.getClienteId() != clienteId) {
                throw new ReservaException("Reserva não encontrada.");
            }
            if (reserva.getStatus() != StatusReserva.CONFIRMADA
                    && reserva.getStatus() != StatusReserva.AGUARDANDO_PAGAMENTO) {
                throw new ReservaException("Essa reserva não pode mais ser cancelada.");
            }
            if (!reserva.getDataHora().isAfter(LocalDateTime.now())) {
                throw new ReservaException("Não é possível cancelar uma reserva que já começou.");
            }
            if (!dao.cancelar(reservaId, clienteId)) {
                throw new ReservaException("Essa reserva já foi cancelada.");
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao cancelar a reserva", e);
        }
    }

    /** Reservas do cliente (mais recentes primeiro), já com os itens. */
    public List<Reserva> listarMinhasReservas(long clienteId) {
        try (Connection conn = ConnectionFactory.getConnection()) {
            List<Reserva> reservas = new ReservaDAO(conn).listarPorCliente(clienteId);
            ItemReservaDAO itemDAO = new ItemReservaDAO(conn);
            for (Reserva r : reservas) {
                r.setItens(itemDAO.listarPorReserva(r.getId()));
            }
            return reservas;
        } catch (SQLException e) {
            throw new DaoException("Erro ao listar reservas", e);
        }
    }
}
