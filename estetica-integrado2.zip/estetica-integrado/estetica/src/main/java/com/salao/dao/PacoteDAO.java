package com.salao.dao;

import com.salao.model.Pacote;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Versão mínima para a agenda; adapte se o projeto já tiver um DAO de pacotes. */
public class PacoteDAO {
    private final Connection conn;
    private final ServicoDAO servicoDAO;

    public PacoteDAO(Connection conn) {
        this.conn = conn;
        this.servicoDAO = new ServicoDAO(conn);
    }

    /** Pacote já com a lista de serviços; null se não existir ou estiver inativo. */
    public Pacote buscarPorId(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, nome, preco FROM pacote WHERE id = ? AND ativo = TRUE")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    public List<Pacote> listarAtivos() throws SQLException {
        List<Pacote> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, nome, preco FROM pacote WHERE ativo = TRUE ORDER BY nome");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Pacote mapear(ResultSet rs) throws SQLException {
        Pacote p = new Pacote();
        p.setId(rs.getLong("id"));
        p.setNome(rs.getString("nome"));
        p.setPreco(rs.getBigDecimal("preco"));
        p.setServicos(servicoDAO.listarPorPacote(p.getId()));
        return p;
    }
}
