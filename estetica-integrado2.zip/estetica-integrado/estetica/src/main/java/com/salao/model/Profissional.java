package com.salao.model;

/** Versão mínima; troque pela classe do colega se já existir. */
public class Profissional {
    private long id;
    private String nome;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
}
