package com.salao.dao;

import com.salao.model.Disponibilidade;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Todos os DAOs recebem a Connection, assim o service controla a transação. */
public class DisponibilidadeDAO {
    private final Connection conn;

    public DisponibilidadeDAO(Connection conn) {
        this.conn = conn;
    }

    public long inserir(Disponibilidade d) throws SQLException {
        String sql = "INSERT INTO disponibilidade (profissional_id, dia, hora_inicio, hora_fim) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, d.getProfissionalId());
            ps.setObject(2, d.getDia());
            ps.setObject(3, d.getHoraInicio());
            ps.setObject(4, d.getHoraFim());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                d.setId(rs.getLong(1));
                return d.getId();
            }
        }
    }

    public void remover(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM disponibilidade WHERE id = ?")) {
            ps.setLong(1, id);
            ps.executeUpdate();
        }
    }

    /** Janelas dos profissionais informados em um dia (leitura comum, para listar horários). */
    public List<Disponibilidade> listarPorDia(LocalDate dia, Collection<Long> profissionalIds) throws SQLException {
        return buscar(dia, profissionalIds, false);
    }

    /**
     * Mesma consulta, mas com FOR UPDATE: trava as linhas na transação.
     * Duas reservas que disputam o mesmo profissional no mesmo dia passam a ser processadas
     * uma de cada vez, e a segunda enxerga a reserva que a primeira acabou de gravar.
     * A ordenação por id mantém a ordem das travas igual para todos, evitando deadlock.
     */
    public List<Disponibilidade> bloquearPorDia(LocalDate dia, Collection<Long> profissionalIds) throws SQLException {
        return buscar(dia, profissionalIds, true);
    }

    private List<Disponibilidade> buscar(LocalDate dia, Collection<Long> ids, boolean paraAtualizar) throws SQLException {
        List<Disponibilidade> lista = new ArrayList<>();
        if (ids.isEmpty()) {
            return lista;
        }
        String sql = "SELECT id, profissional_id, dia, hora_inicio, hora_fim FROM disponibilidade "
                + "WHERE dia = ? AND profissional_id IN (" + SqlUtil.placeholders(ids.size()) + ") "
                + "ORDER BY id" + (paraAtualizar ? " FOR UPDATE" : "");
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            int i = 1;
            ps.setObject(i++, dia);
            for (Long id : ids) {
                ps.setLong(i++, id);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Disponibilidade d = new Disponibilidade();
                    d.setId(rs.getLong("id"));
                    d.setProfissionalId(rs.getLong("profissional_id"));
                    d.setDia(rs.getObject("dia", LocalDate.class));
                    d.setHoraInicio(rs.getObject("hora_inicio", LocalTime.class));
                    d.setHoraFim(rs.getObject("hora_fim", LocalTime.class));
                    lista.add(d);
                }
            }
        }
        return lista;
    }
}
