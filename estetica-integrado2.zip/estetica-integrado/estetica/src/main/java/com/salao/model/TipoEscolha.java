package com.salao.model;

/** Como o cliente escolhe quem vai atendê-lo. */
public enum TipoEscolha {
    /** Qualquer profissional livre naquele momento. */
    DISPONIVEL("Profissional disponível"),
    /** Um profissional específico, escolhido pelo cliente. */
    PREFERENCIA("Profissional de preferência");

    private final String rotulo;

    TipoEscolha(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }

    /** Converte o texto vindo do formulário; qualquer valor desconhecido vira DISPONIVEL. */
    public static TipoEscolha deTexto(String texto) {
        return "PREFERENCIA".equals(texto) ? PREFERENCIA : DISPONIVEL;
    }
}
