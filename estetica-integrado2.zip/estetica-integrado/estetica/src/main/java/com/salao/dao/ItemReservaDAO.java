package com.salao.dao;

import com.salao.model.ItemReserva;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ItemReservaDAO {
    private final Connection conn;

    public ItemReservaDAO(Connection conn) {
        this.conn = conn;
    }

    public long inserir(ItemReserva item) throws SQLException {
        String sql = "INSERT INTO item_reserva (reserva_id, servico_id, profissional_id, inicio, fim) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, item.getReservaId());
            ps.setLong(2, item.getServicoId());
            ps.setLong(3, item.getProfissionalId());
            ps.setObject(4, item.getInicio());
            ps.setObject(5, item.getFim());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                item.setId(rs.getLong(1));
                return item.getId();
            }
        }
    }

    /** Itens de uma reserva, já com o nome do serviço e do profissional. */
    public List<ItemReserva> listarPorReserva(long reservaId) throws SQLException {
        String sql = "SELECT ir.id, ir.reserva_id, ir.servico_id, ir.profissional_id, ir.inicio, ir.fim, "
                + "s.nome AS servico_nome, p.nome AS profissional_nome "
                + "FROM item_reserva ir "
                + "JOIN servico s ON s.id = ir.servico_id "
                + "JOIN profissional p ON p.id = ir.profissional_id "
                + "WHERE ir.reserva_id = ? ORDER BY ir.inicio";
        List<ItemReserva> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, reservaId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ItemReserva item = mapear(rs);
                    item.setServicoNome(rs.getString("servico_nome"));
                    item.setProfissionalNome(rs.getString("profissional_nome"));
                    lista.add(item);
                }
            }
        }
        return lista;
    }

    /**
     * Intervalos já ocupados (em reservas NÃO canceladas) dos profissionais em um dia.
     * Pega qualquer item que encoste no dia, inclusive um que comece na véspera e termine hoje.
     */
    public List<ItemReserva> listarOcupadosPorDia(LocalDate dia, Collection<Long> profissionalIds) throws SQLException {
        List<ItemReserva> lista = new ArrayList<>();
        if (profissionalIds.isEmpty()) {
            return lista;
        }
        String sql = "SELECT ir.id, ir.reserva_id, ir.servico_id, ir.profissional_id, ir.inicio, ir.fim "
                + "FROM item_reserva ir JOIN reserva r ON r.id = ir.reserva_id "
                + "WHERE r.status <> 'CANCELADA' "
                + "AND ir.profissional_id IN (" + SqlUtil.placeholders(profissionalIds.size()) + ") "
                + "AND ir.inicio < ? AND ir.fim > ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            int i = 1;
            for (Long id : profissionalIds) {
                ps.setLong(i++, id);
            }
            ps.setObject(i++, dia.plusDays(1).atStartOfDay());
            ps.setObject(i, dia.atStartOfDay());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    /** O cliente já tem outra reserva ativa que se sobrepõe a este intervalo? */
    public boolean existeConflitoCliente(long clienteId, LocalDateTime inicio, LocalDateTime fim) throws SQLException {
        String sql = "SELECT 1 FROM item_reserva ir JOIN reserva r ON r.id = ir.reserva_id "
                + "WHERE r.cliente_id = ? AND r.status <> 'CANCELADA' AND ir.inicio < ? AND ir.fim > ? LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, clienteId);
            ps.setObject(2, fim);
            ps.setObject(3, inicio);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private ItemReserva mapear(ResultSet rs) throws SQLException {
        ItemReserva item = new ItemReserva();
        item.setId(rs.getLong("id"));
        item.setReservaId(rs.getLong("reserva_id"));
        item.setServicoId(rs.getLong("servico_id"));
        item.setProfissionalId(rs.getLong("profissional_id"));
        item.setInicio(rs.getObject("inicio", LocalDateTime.class));
        item.setFim(rs.getObject("fim", LocalDateTime.class));
        return item;
    }
}
