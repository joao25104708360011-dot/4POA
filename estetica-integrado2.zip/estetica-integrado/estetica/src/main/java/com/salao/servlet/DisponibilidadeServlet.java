package com.salao.servlet;

import com.salao.model.Profissional;
import com.salao.model.TipoEscolha;
import com.salao.service.DisponibilidadeService;
import com.salao.service.ReservaException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalTime;
import java.util.List;

/**
 * Endpoint JSON que a reservar.jsp chama via fetch.
 *
 * GET /disponibilidade?data=2026-11-10&servicoIds=1&servicoIds=2[&tipo=PREFERENCIA&profissionalId=3]
 *   -> {"horarios":["09:00","09:30"]}
 *
 * GET /disponibilidade?acao=profissionais&servicoIds=1&servicoIds=2
 *   -> {"profissionais":[{"id":1,"nome":"Ana"}]}   (quem realiza todos os serviços)
 *
 * Erro de validação -> HTTP 400 {"erro":"mensagem"}
 */
@WebServlet("/disponibilidade")
public class DisponibilidadeServlet extends HttpServlet {

    private final DisponibilidadeService service = new DisponibilidadeService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");

        try {
            List<Long> servicoIds = Parametros.ids(req.getParameterValues("servicoIds"));

            if ("profissionais".equals(req.getParameter("acao"))) {
                resp.getWriter().write(jsonProfissionais(service.profissionaisPara(servicoIds)));
                return;
            }

            List<LocalTime> horarios = service.horariosLivres(
                    Parametros.data(req.getParameter("data")),
                    servicoIds,
                    TipoEscolha.deTexto(req.getParameter("tipo")),
                    Parametros.longOuNulo(req.getParameter("profissionalId")));
            resp.getWriter().write(jsonHorarios(horarios));

        } catch (ReservaException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"erro\":\"" + Parametros.jsonTexto(e.getMessage()) + "\"}");
        }
    }

    private String jsonHorarios(List<LocalTime> horarios) {
        StringBuilder sb = new StringBuilder("{\"horarios\":[");
        for (int i = 0; i < horarios.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(horarios.get(i)).append('"'); // LocalTime.toString() -> "09:30"
        }
        return sb.append("]}").toString();
    }

    private String jsonProfissionais(List<Profissional> lista) {
        StringBuilder sb = new StringBuilder("{\"profissionais\":[");
        for (int i = 0; i < lista.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            Profissional p = lista.get(i);
            sb.append("{\"id\":").append(p.getId())
              .append(",\"nome\":\"").append(Parametros.jsonTexto(p.getNome())).append("\"}");
        }
        return sb.append("]}").toString();
    }
}
