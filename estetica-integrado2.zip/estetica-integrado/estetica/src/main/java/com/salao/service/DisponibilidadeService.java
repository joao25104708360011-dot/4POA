package com.salao.service;

import com.salao.dao.DaoException;
import com.salao.dao.DisponibilidadeDAO;
import com.salao.dao.ItemReservaDAO;
import com.salao.dao.ProfissionalDAO;
import com.salao.dao.ServicoDAO;
import com.salao.model.Disponibilidade;
import com.salao.model.ItemReserva;
import com.salao.model.Profissional;
import com.salao.model.Servico;
import com.salao.model.TipoEscolha;
import com.salao.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/** Regra "só mostrar horários disponíveis". */
public class DisponibilidadeService {

    /** De quanto em quanto tempo um horário de início é oferecido. */
    public static final int PASSO_MINUTOS = 30;

    /**
     * Horários de início em que TODOS os serviços escolhidos cabem em sequência, com profissional
     * livre em cada etapa. Já descarta horários passados e dias anteriores a hoje.
     */
    public List<LocalTime> horariosLivres(LocalDate dia, List<Long> servicoIds, TipoEscolha tipo, Long profissionalId)
            throws ReservaException {
        LocalDateTime agora = LocalDateTime.now();
        if (dia.isBefore(agora.toLocalDate())) {
            return List.of();
        }
        TipoEscolha escolha = tipo == null ? TipoEscolha.DISPONIVEL : tipo;

        try (Connection conn = ConnectionFactory.getConnection()) {
            List<Servico> servicos = carregarServicos(conn, servicoIds);
            Map<Long, List<Long>> candidatos = candidatosPorServico(conn, servicos, escolha, profissionalId);
            Set<Long> profissionais = candidatos.values().stream()
                    .flatMap(List::stream)
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            List<Disponibilidade> janelas = new DisponibilidadeDAO(conn).listarPorDia(dia, profissionais);
            if (janelas.isEmpty()) {
                return List.of();
            }
            List<ItemReserva> ocupados = new ItemReservaDAO(conn).listarOcupadosPorDia(dia, profissionais);
            AgendaDoDia agenda = new AgendaDoDia(janelas, ocupados);

            LocalTime primeiro = janelas.stream().map(Disponibilidade::getHoraInicio)
                    .min(Comparator.naturalOrder()).orElseThrow();
            LocalTime ultimo = janelas.stream().map(Disponibilidade::getHoraFim)
                    .max(Comparator.naturalOrder()).orElseThrow();

            List<LocalTime> livres = new ArrayList<>();
            LocalDateTime limite = LocalDateTime.of(dia, ultimo);
            for (LocalDateTime t = LocalDateTime.of(dia, primeiro); t.isBefore(limite); t = t.plusMinutes(PASSO_MINUTOS)) {
                if (!t.isAfter(agora)) {
                    continue;
                }
                if (agenda.alocar(t, servicos, candidatos) != null) {
                    livres.add(t.toLocalTime());
                }
            }
            return livres;
        } catch (SQLException e) {
            throw new DaoException("Erro ao calcular horários livres", e);
        }
    }

    /** Profissionais que realizam todos os serviços escolhidos (alimenta o seletor de preferência). */
    public List<Profissional> profissionaisPara(List<Long> servicoIds) throws ReservaException {
        if (servicoIds == null || servicoIds.isEmpty()) {
            throw new ReservaException("Selecione ao menos um serviço.");
        }
        try (Connection conn = ConnectionFactory.getConnection()) {
            return new ProfissionalDAO(conn).listarQueRealizamTodos(new LinkedHashSet<>(servicoIds));
        } catch (SQLException e) {
            throw new DaoException("Erro ao listar profissionais", e);
        }
    }

    // ---- Auxiliares compartilhados com o ReservaService ----

    /** Carrega os serviços na ordem escolhida, sem repetir, falhando se algum for inválido. */
    static List<Servico> carregarServicos(Connection conn, List<Long> ids) throws SQLException, ReservaException {
        if (ids == null || ids.isEmpty()) {
            throw new ReservaException("Selecione ao menos um serviço.");
        }
        ServicoDAO dao = new ServicoDAO(conn);
        List<Servico> servicos = new ArrayList<>();
        for (Long id : new LinkedHashSet<>(ids)) {
            Servico s = dao.buscarPorId(id);
            if (s == null) {
                throw new ReservaException("Um dos serviços escolhidos não está mais disponível.");
            }
            servicos.add(s);
        }
        return servicos;
    }

    /**
     * Define quem pode fazer cada serviço.
     * DISPONIVEL: qualquer profissional que realize o serviço.
     * PREFERENCIA: somente o profissional escolhido, que precisa realizar todos os serviços.
     */
    static Map<Long, List<Long>> candidatosPorServico(Connection conn, List<Servico> servicos,
                                                      TipoEscolha tipo, Long profissionalId)
            throws SQLException, ReservaException {
        ProfissionalDAO dao = new ProfissionalDAO(conn);
        Map<Long, List<Long>> mapa = new LinkedHashMap<>();

        if (tipo == TipoEscolha.PREFERENCIA) {
            if (profissionalId == null) {
                throw new ReservaException("Escolha o profissional de preferência.");
            }
            List<Long> ids = servicos.stream().map(Servico::getId).toList();
            boolean realizaTodos = dao.listarQueRealizamTodos(ids).stream()
                    .anyMatch(p -> p.getId() == profissionalId.longValue());
            if (!realizaTodos) {
                throw new ReservaException("Esse profissional não realiza todos os serviços escolhidos.");
            }
            for (Servico s : servicos) {
                mapa.put(s.getId(), List.of(profissionalId));
            }
        } else {
            for (Servico s : servicos) {
                List<Long> ids = dao.listarPorServico(s.getId()).stream().map(Profissional::getId).toList();
                if (ids.isEmpty()) {
                    throw new ReservaException("Nenhum profissional realiza o serviço " + s.getNome() + ".");
                }
                mapa.put(s.getId(), ids);
            }
        }
        return mapa;
    }
}
