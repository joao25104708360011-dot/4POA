package com.salao.dao;

import com.salao.model.Profissional;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Versão mínima para a agenda; adapte se o projeto já tiver um DAO de profissionais. */
public class ProfissionalDAO {
    private final Connection conn;

    public ProfissionalDAO(Connection conn) {
        this.conn = conn;
    }

    /** Profissionais ativos que realizam o serviço. */
    public List<Profissional> listarPorServico(long servicoId) throws SQLException {
        String sql = "SELECT p.id, p.nome FROM profissional p "
                + "JOIN profissional_servico ps ON ps.profissional_id = p.id "
                + "WHERE p.ativo = TRUE AND ps.servico_id = ? ORDER BY p.id";
        List<Profissional> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, servicoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    /** Profissionais ativos que realizam TODOS os serviços informados (interseção). */
    public List<Profissional> listarQueRealizamTodos(Collection<Long> servicoIds) throws SQLException {
        List<Profissional> lista = new ArrayList<>();
        if (servicoIds.isEmpty()) {
            return lista;
        }
        String sql = "SELECT p.id, p.nome FROM profissional p "
                + "JOIN profissional_servico ps ON ps.profissional_id = p.id "
                + "WHERE p.ativo = TRUE AND ps.servico_id IN (" + SqlUtil.placeholders(servicoIds.size()) + ") "
                + "GROUP BY p.id, p.nome HAVING COUNT(DISTINCT ps.servico_id) = ? ORDER BY p.nome";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            int i = 1;
            for (Long id : servicoIds) {
                ps.setLong(i++, id);
            }
            ps.setInt(i, servicoIds.size());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    private Profissional mapear(ResultSet rs) throws SQLException {
        Profissional p = new Profissional();
        p.setId(rs.getLong("id"));
        p.setNome(rs.getString("nome"));
        return p;
    }
}
