package com.salao.model;

import java.math.BigDecimal;

/**
 * Versão mínima, só com o que a agenda precisa.
 * Se o colega responsável pelos serviços já tem essa classe, use a dele
 * (precisa de id, nome, duração em minutos e preço).
 */
public class Servico {
    private long id;
    private String nome;
    private int duracaoMinutos;
    private BigDecimal preco;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getDuracaoMinutos() { return duracaoMinutos; }
    public void setDuracaoMinutos(int duracaoMinutos) { this.duracaoMinutos = duracaoMinutos; }

    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
}
