package com.salao.model;

public enum StatusReserva {
    /** Criada na agenda, esperando o pagamento por cartão (a reserva já segura o horário). */
    AGUARDANDO_PAGAMENTO("Aguardando pagamento"),
    CONFIRMADA("Confirmada"),
    CANCELADA("Cancelada"),
    CONCLUIDA("Concluída"),
    // Os três abaixo são gravados pelo módulo de pagamento/recepção (RecepcaoService, FaltaService).
    PRESENTE("Presente"),
    ATRASO_LIBERADO("Atraso - vaga liberada"),
    FALTA("Falta");

    private final String rotulo;

    StatusReserva(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }
}
