package com.salao.dao;

import com.salao.model.Reserva;
import com.salao.model.StatusReserva;
import com.salao.model.TipoEscolha;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {
    private final Connection conn;

    public ReservaDAO(Connection conn) {
        this.conn = conn;
    }

    /** Grava só a reserva; os itens são gravados pelo ItemReservaDAO. */
    public long inserir(Reserva r) throws SQLException {
        String sql = "INSERT INTO reserva (cliente_id, data_hora, status, valor_total, tipo_escolha) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, r.getClienteId());
            ps.setObject(2, r.getDataHora());
            ps.setString(3, r.getStatus().name());
            ps.setBigDecimal(4, r.getValorTotal());
            ps.setString(5, r.getTipoEscolha().name());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                r.setId(rs.getLong(1));
                return r.getId();
            }
        }
    }

    public Reserva buscarPorId(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, cliente_id, data_hora, status, valor_total, tipo_escolha FROM reserva WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    /** Mais recentes primeiro. */
    public List<Reserva> listarPorCliente(long clienteId) throws SQLException {
        List<Reserva> lista = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, cliente_id, data_hora, status, valor_total, tipo_escolha FROM reserva "
                        + "WHERE cliente_id = ? ORDER BY data_hora DESC")) {
            ps.setLong(1, clienteId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    /**
     * Cancela apenas se a reserva é do cliente e ainda está CONFIRMADA ou AGUARDANDO_PAGAMENTO.
     * O UPDATE condicional evita cancelar duas vezes se o cliente clicar em duas abas.
     *
     * @return true se alguma linha foi alterada
     */
    public boolean cancelar(long reservaId, long clienteId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE reserva SET status = 'CANCELADA' WHERE id = ? AND cliente_id = ? "
                        + "AND status IN ('CONFIRMADA', 'AGUARDANDO_PAGAMENTO')")) {
            ps.setLong(1, reservaId);
            ps.setLong(2, clienteId);
            return ps.executeUpdate() > 0;
        }
    }

    private Reserva mapear(ResultSet rs) throws SQLException {
        Reserva r = new Reserva();
        r.setId(rs.getLong("id"));
        r.setClienteId(rs.getLong("cliente_id"));
        r.setDataHora(rs.getObject("data_hora", LocalDateTime.class));
        r.setStatus(StatusReserva.valueOf(rs.getString("status")));
        r.setValorTotal(rs.getBigDecimal("valor_total"));
        r.setTipoEscolha(TipoEscolha.valueOf(rs.getString("tipo_escolha")));
        return r;
    }
}
