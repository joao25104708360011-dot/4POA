package br.com.salao.service;

import br.com.salao.dao.ProfissionalDAO;
import br.com.salao.model.Profissional;

import java.util.List;

public class ProfissionalService {

    private final ProfissionalDAO dao = new ProfissionalDAO();

    public void salvar(Profissional profissional) {
        if (profissional.getNome() == null || profissional.getNome().isBlank()) {
            throw new IllegalArgumentException("Informe o nome do profissional");
        }
        if (profissional.getEspecialidade() == null) {
            throw new IllegalArgumentException("Informe a especialidade do profissional");
        }
        dao.salvar(profissional);
    }

    public void excluir(Long id) {
        dao.excluir(id);
    }

    public Profissional buscarPorId(Long id) {
        return dao.buscarPorId(id);
    }

    public List<Profissional> listar() {
        return dao.listar();
    }

    public List<Profissional> listarPorEspecialidade(Long especialidadeId) {
        return dao.listarPorEspecialidade(especialidadeId);
    }
}
