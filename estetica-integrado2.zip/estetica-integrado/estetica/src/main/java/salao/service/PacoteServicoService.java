package br.com.salao.service;

import br.com.salao.dao.PacoteServicoDAO;
import br.com.salao.model.PacoteServico;

import java.util.List;

public class PacoteServicoService {

    private final PacoteServicoDAO dao = new PacoteServicoDAO();

    public void salvar(PacoteServico pacoteServico) {
        dao.salvar(pacoteServico);
    }

    public void excluir(Long id) {
        dao.excluir(id);
    }

    public List<PacoteServico> listarPorPacote(Long pacoteId) {
        return dao.listarPorPacote(pacoteId);
    }
}
