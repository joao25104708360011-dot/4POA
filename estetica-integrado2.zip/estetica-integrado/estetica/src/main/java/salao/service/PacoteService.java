package br.com.salao.service;

import br.com.salao.dao.PacoteDAO;
import br.com.salao.model.Pacote;
import br.com.salao.model.PacoteServico;
import br.com.salao.model.Servico;

import java.math.BigDecimal;
import java.util.List;

public class PacoteService {

    private final PacoteDAO dao = new PacoteDAO();
    private final ServicoService servicoService = new ServicoService();

    public void salvar(Pacote pacote, String[] servicosIds) {
        if (pacote.getNome() == null || pacote.getNome().isBlank()) {
            throw new IllegalArgumentException("Informe o nome do pacote");
        }
        if (pacote.getPreco() == null || pacote.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Preço inválido");
        }
        if (servicosIds == null || servicosIds.length < 2) {
            throw new IllegalArgumentException("O pacote precisa de pelo menos 2 serviços");
        }

        pacote.getItens().clear();
        for (String id : servicosIds) {
            Servico servico = servicoService.buscarPorId(Long.parseLong(id));
            PacoteServico item = new PacoteServico();
            item.setPacote(pacote);
            item.setServico(servico);
            pacote.getItens().add(item);
        }
        dao.salvar(pacote);
    }

    public void excluir(Long id) {
        dao.excluir(id);
    }

    public Pacote buscarPorId(Long id) {
        return dao.buscarPorId(id);
    }

    public List<Pacote> listar() {
        return dao.listar();
    }
}
