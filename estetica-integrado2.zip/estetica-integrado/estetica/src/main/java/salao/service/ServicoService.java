package br.com.salao.service;

import br.com.salao.dao.ServicoDAO;
import br.com.salao.model.Profissional;
import br.com.salao.model.Servico;

import java.math.BigDecimal;
import java.util.List;

public class ServicoService {

    private final ServicoDAO dao = new ServicoDAO();
    private final ProfissionalService profissionalService = new ProfissionalService();

    public void salvar(Servico servico) {
        if (servico.getNome() == null || servico.getNome().isBlank()) {
            throw new IllegalArgumentException("Informe o nome do serviço");
        }
        if (servico.getPreco() == null || servico.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Preço inválido");
        }
        if (servico.getDuracaoMinutos() <= 0) {
            throw new IllegalArgumentException("Duração inválida");
        }
        if (servico.getEspecialidade() == null) {
            throw new IllegalArgumentException("Informe a especialidade do serviço");
        }
        dao.salvar(servico);
    }

    public void excluir(Long id) {
        dao.excluir(id);
    }

    public Servico buscarPorId(Long id) {
        return dao.buscarPorId(id);
    }

    public List<Servico> listar() {
        return dao.listar();
    }

    public List<Servico> filtrar(Long especialidadeId, Long profissionalId) {
        if (profissionalId != null) {
            Profissional profissional = profissionalService.buscarPorId(profissionalId);
            if (profissional != null) {
                return dao.listarPorEspecialidade(profissional.getEspecialidade().getId());
            }
        }
        if (especialidadeId != null) {
            return dao.listarPorEspecialidade(especialidadeId);
        }
        return dao.listar();
    }
}
