package br.com.salao.service;

import br.com.salao.dao.EspecialidadeDAO;
import br.com.salao.model.Especialidade;

import java.util.List;

public class EspecialidadeService {

    private final EspecialidadeDAO dao = new EspecialidadeDAO();

    public void salvar(Especialidade especialidade) {
        if (especialidade.getNome() == null || especialidade.getNome().isBlank()) {
            throw new IllegalArgumentException("Informe o nome da especialidade");
        }
        dao.salvar(especialidade);
    }

    public void excluir(Long id) {
        dao.excluir(id);
    }

    public Especialidade buscarPorId(Long id) {
        return dao.buscarPorId(id);
    }

    public List<Especialidade> listar() {
        return dao.listar();
    }
}
