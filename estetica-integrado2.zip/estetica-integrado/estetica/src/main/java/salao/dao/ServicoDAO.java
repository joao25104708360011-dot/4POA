package br.com.salao.dao;

import br.com.salao.model.Servico;
import br.com.salao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class ServicoDAO {

    public void salvar(Servico obj) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public void excluir(Long id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Servico obj = session.get(Servico.class, id);
            if (obj != null) session.remove(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public Servico buscarPorId(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Servico.class, id);
        }
    }

    public List<Servico> listar() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Servico order by nome", Servico.class).list();
        }
    }

    public List<Servico> listarPorEspecialidade(Long especialidadeId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Servico s where s.especialidade.id = :id order by s.nome", Servico.class)
                    .setParameter("id", especialidadeId)
                    .list();
        }
    }
}
