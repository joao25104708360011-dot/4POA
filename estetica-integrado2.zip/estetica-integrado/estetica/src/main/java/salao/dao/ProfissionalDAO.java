package br.com.salao.dao;

import br.com.salao.model.Profissional;
import br.com.salao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class ProfissionalDAO {

    public void salvar(Profissional obj) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public void excluir(Long id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Profissional obj = session.get(Profissional.class, id);
            if (obj != null) session.remove(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public Profissional buscarPorId(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Profissional.class, id);
        }
    }

    public List<Profissional> listar() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Profissional order by nome", Profissional.class).list();
        }
    }

    public List<Profissional> listarPorEspecialidade(Long especialidadeId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Profissional p where p.especialidade.id = :id order by p.nome", Profissional.class)
                    .setParameter("id", especialidadeId)
                    .list();
        }
    }
}
