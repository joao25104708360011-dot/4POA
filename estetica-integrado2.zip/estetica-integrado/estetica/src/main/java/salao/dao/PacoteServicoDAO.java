package br.com.salao.dao;

import br.com.salao.model.PacoteServico;
import br.com.salao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class PacoteServicoDAO {

    public void salvar(PacoteServico obj) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public void excluir(Long id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            PacoteServico obj = session.get(PacoteServico.class, id);
            if (obj != null) session.remove(obj);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    public PacoteServico buscarPorId(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(PacoteServico.class, id);
        }
    }

    public List<PacoteServico> listar() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from PacoteServico", PacoteServico.class).list();
        }
    }

    public List<PacoteServico> listarPorPacote(Long pacoteId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from PacoteServico ps where ps.pacote.id = :id", PacoteServico.class)
                    .setParameter("id", pacoteId)
                    .list();
        }
    }
}
