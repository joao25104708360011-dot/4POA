package br.com.salao.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pacote")
public class Pacote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false)
    private BigDecimal preco;

    @OneToMany(mappedBy = "pacote", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PacoteServico> itens = new ArrayList<>();

    public int getDuracaoTotal() {
        int total = 0;
        for (PacoteServico item : itens) {
            total += item.getServico().getDuracaoMinutos();
        }
        return total;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
    public List<PacoteServico> getItens() { return itens; }
    public void setItens(List<PacoteServico> itens) { this.itens = itens; }
}
