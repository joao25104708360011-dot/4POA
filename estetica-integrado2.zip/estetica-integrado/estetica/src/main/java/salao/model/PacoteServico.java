package br.com.salao.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pacote_servico")
public class PacoteServico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pacote_id", nullable = false)
    private Pacote pacote;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "servico_id", nullable = false)
    private Servico servico;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Pacote getPacote() { return pacote; }
    public void setPacote(Pacote pacote) { this.pacote = pacote; }
    public Servico getServico() { return servico; }
    public void setServico(Servico servico) { this.servico = servico; }
}
