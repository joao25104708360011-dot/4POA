package br.com.salao.servlet;

import br.com.salao.model.Especialidade;
import br.com.salao.service.EspecialidadeService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/especialidades")
public class EspecialidadeServlet extends HttpServlet {

    private final EspecialidadeService service = new EspecialidadeService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String acao = req.getParameter("acao");

        try {
            if ("excluir".equals(acao)) {
                service.excluir(Long.parseLong(req.getParameter("id")));
            } else {
                Especialidade especialidade = new Especialidade();
                String id = req.getParameter("id");
                if (id != null && !id.isBlank()) especialidade.setId(Long.parseLong(id));
                especialidade.setNome(req.getParameter("nome"));
                service.salvar(especialidade);
            }
            resp.sendRedirect("servicos?acao=admin");
        } catch (Exception e) {
            req.getSession().setAttribute("erro", e.getMessage());
            resp.sendRedirect("servicos?acao=admin");
        }
    }
}
