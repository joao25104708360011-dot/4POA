package br.com.salao.servlet;

import br.com.salao.model.Pacote;
import br.com.salao.service.PacoteService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/pacotes")
public class PacoteServlet extends HttpServlet {

    private final PacoteService service = new PacoteService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String acao = req.getParameter("acao");

        try {
            if ("excluir".equals(acao)) {
                service.excluir(Long.parseLong(req.getParameter("id")));
            } else {
                String id = req.getParameter("id");
                Pacote pacote = (id != null && !id.isBlank()) ? service.buscarPorId(Long.parseLong(id)) : new Pacote();
                pacote.setNome(req.getParameter("nome"));
                pacote.setPreco(new BigDecimal(req.getParameter("preco").replace(",", ".")));
                service.salvar(pacote, req.getParameterValues("servicosIds"));
            }
        } catch (Exception e) {
            req.getSession().setAttribute("erro", e.getMessage());
        }
        resp.sendRedirect("servicos?acao=admin");
    }
}
