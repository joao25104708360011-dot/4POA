package br.com.salao.servlet;

import br.com.salao.model.Profissional;
import br.com.salao.service.EspecialidadeService;
import br.com.salao.service.ProfissionalService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/profissionais")
public class ProfissionalServlet extends HttpServlet {

    private final ProfissionalService service = new ProfissionalService();
    private final EspecialidadeService especialidadeService = new EspecialidadeService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String acao = req.getParameter("acao");

        try {
            if ("excluir".equals(acao)) {
                service.excluir(Long.parseLong(req.getParameter("id")));
            } else {
                Profissional profissional = new Profissional();
                String id = req.getParameter("id");
                if (id != null && !id.isBlank()) profissional.setId(Long.parseLong(id));
                profissional.setNome(req.getParameter("nome"));
                profissional.setTelefone(req.getParameter("telefone"));
                profissional.setEspecialidade(especialidadeService.buscarPorId(Long.parseLong(req.getParameter("especialidadeId"))));
                service.salvar(profissional);
            }
        } catch (Exception e) {
            req.getSession().setAttribute("erro", e.getMessage());
        }
        resp.sendRedirect("servicos?acao=admin");
    }
}
