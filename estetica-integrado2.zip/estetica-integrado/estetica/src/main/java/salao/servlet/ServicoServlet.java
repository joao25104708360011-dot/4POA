package br.com.salao.servlet;

import br.com.salao.model.Servico;
import br.com.salao.service.EspecialidadeService;
import br.com.salao.service.PacoteService;
import br.com.salao.service.ProfissionalService;
import br.com.salao.service.ServicoService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/servicos")
public class ServicoServlet extends HttpServlet {

    private final ServicoService service = new ServicoService();
    private final EspecialidadeService especialidadeService = new EspecialidadeService();
    private final ProfissionalService profissionalService = new ProfissionalService();
    private final PacoteService pacoteService = new PacoteService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("especialidades", especialidadeService.listar());
        req.setAttribute("profissionais", profissionalService.listar());
        req.setAttribute("pacotes", pacoteService.listar());

        if ("admin".equals(req.getParameter("acao"))) {
            req.setAttribute("servicos", service.listar());
            carregarEdicao(req);
            req.getRequestDispatcher("admin-catalogo.jsp").forward(req, resp);
            return;
        }

        Long especialidadeId = paraLong(req.getParameter("especialidadeId"));
        Long profissionalId = paraLong(req.getParameter("profissionalId"));
        req.setAttribute("servicos", service.filtrar(especialidadeId, profissionalId));
        req.setAttribute("especialidadeId", especialidadeId);
        req.setAttribute("profissionalId", profissionalId);
        req.getRequestDispatcher("servicos.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String acao = req.getParameter("acao");

        try {
            if ("excluir".equals(acao)) {
                service.excluir(Long.parseLong(req.getParameter("id")));
            } else {
                Servico servico = new Servico();
                servico.setId(paraLong(req.getParameter("id")));
                servico.setNome(req.getParameter("nome"));
                servico.setPreco(new BigDecimal(req.getParameter("preco").replace(",", ".")));
                servico.setDuracaoMinutos(Integer.parseInt(req.getParameter("duracaoMinutos")));
                servico.setEspecialidade(especialidadeService.buscarPorId(Long.parseLong(req.getParameter("especialidadeId"))));
                service.salvar(servico);
            }
        } catch (Exception e) {
            req.getSession().setAttribute("erro", e.getMessage());
        }
        resp.sendRedirect("servicos?acao=admin");
    }

    private void carregarEdicao(HttpServletRequest req) {
        Long id = paraLong(req.getParameter("editarEspecialidade"));
        if (id != null) req.setAttribute("especialidade", especialidadeService.buscarPorId(id));

        id = paraLong(req.getParameter("editarProfissional"));
        if (id != null) req.setAttribute("profissional", profissionalService.buscarPorId(id));

        id = paraLong(req.getParameter("editarServico"));
        if (id != null) req.setAttribute("servico", service.buscarPorId(id));

        id = paraLong(req.getParameter("editarPacote"));
        if (id != null) req.setAttribute("pacote", pacoteService.buscarPorId(id));
    }

    private Long paraLong(String valor) {
        if (valor == null || valor.isBlank()) return null;
        return Long.parseLong(valor);
    }
}
